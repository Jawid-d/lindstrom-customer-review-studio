import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/review/Dashboard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Customer Value & Sustainability Review | Lindström KAM Studio" },
      { name: "description", content: "Multi-site customer value, sustainability savings and steering-committee actions for key account managers." },
      { property: "og:title", content: "Customer Value & Sustainability Review" },
      { property: "og:description", content: "Evidence of value delivered, site drill-down and next-year actions in one review." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});
