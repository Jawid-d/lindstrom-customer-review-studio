import { useState } from "react";
import { ArrowRight, Database, Lock, Radio, Receipt, Wrench, Gauge } from "lucide-react";
import { SCENARIO, SCENARIO_LABEL, type Baseline, type Customer, type Scenario, type Site, type Status, valueBridge } from "@/lib/review";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { SectionTitle, StatusTag, n } from "./parts";

type Audience = "CFO" | "VP Operations" | "Sustainability";
const AUDIENCES: Audience[] = ["CFO", "VP Operations", "Sustainability"];

interface Row {
  signal: string;
  source: string;
  raw: string;
  value: string;
  status: Status;
  formula: string;
  impact: Record<Audience, string>;
}

export function ValueBridge({
  customer,
  sites,
  baseline,
  scenario,
}: {
  customer: Customer;
  sites: Site[];
  baseline: Baseline;
  scenario: Scenario;
}) {
  const [mode, setMode] = useState<"matrix" | "pipeline">("matrix");
  const [view, setView] = useState<"ops" | "exec">("exec");
  const [aud, setAud] = useState<Audience>("CFO");
  const v = valueBridge(customer, sites, baseline, scenario);
  const eur = (x: number) => `€${n(Math.round(x / 100) * 100)}`;

  const rows: Row[] = [
    {
      signal: "Repair logs",
      source: "Repair DB / Tableau export",
      raw: `${n(v.t.repairs)} repair tickets (zips, seams, buttons…)`,
      value: `${n(Math.round(v.sv.replacementsPostponed))} replacements postponed · ${eur(v.repairCapexAvoided)} purchase cost avoided`,
      status: "ESTIMATE",
      formula: `repairs × ${SCENARIO[scenario].repairFactor} repair factor × avg synthetic garment cost €${v.garmentCost.toFixed(2)}. Scenario: ${SCENARIO_LABEL[scenario]}.`,
      impact: {
        CFO: "Garment replacement spend that a buy-and-own model would have carried.",
        "VP Operations": "Fewer garment changeovers for wearers; stock stays in service longer.",
        Sustainability: `${n(v.sv.avoidedProductCo2 / 1000, 1)} tCO₂e of new-product footprint postponed (separate from service emissions).`,
      },
    },
    {
      signal: "RFID scan counts",
      source: "RFID laundry antennas",
      raw: `${n(v.t.scanned)} of ${n(v.t.allocated)} garments scanned in Dec`,
      value: `${(v.t.utilisation * 100).toFixed(1)}% utilisation · ${n(v.idle)} garments with no scan activity (${eur(v.idleCapital)} stock — signal to investigate)`,
      status: "CALCULATED",
      formula: "no scan activity = allocated − scanned × 1.1 buffer, per site; stock value = idle × avg garment cost (estimate)",
      impact: {
        CFO: "Right-sizing allocation can lower the rental base without reducing service.",
        "VP Operations": "Shows which sites hold more garments than wearers actively use.",
        Sustainability: "Fewer garments in circulation means less textile produced for the same work.",
      },
    },
    {
      signal: "Wash weights",
      source: "Laundry production system",
      raw: `${n(Math.round(v.t.washedKg))} kg washed · ${n(v.t.washedPieces)} pieces`,
      value: `${n(Math.round(v.washesPerWearer))} washes per wearer per year`,
      status: "MEASURED",
      formula: "washed pieces ÷ December wearers",
      impact: {
        CFO: "Volume basis for the contract — what the fee actually bought.",
        "VP Operations": "Confirms service intensity per worker across all sites.",
        Sustainability: "Activity basis for every footprint and handprint figure.",
      },
    },
    {
      signal: "Route tracking",
      source: "Logistics / delivery system",
      raw: `${n(v.t.cycles)} service cycles · ${n(v.t.late)} late`,
      value: `${(v.t.onTimeRate * 100).toFixed(1)}% on-time service cycles`,
      status: "CALCULATED",
      formula: "(cycles − late cycles) ÷ cycles",
      impact: {
        CFO: "Service reliability delivered against the agreement.",
        "VP Operations": "Clean garments arrive when shifts need them — no production stops.",
        Sustainability: "Shared routes spread delivery emissions across many customers.",
      },
    },
    {
      signal: "Unseen RFID tags",
      source: "RFID vs ERP allocation",
      raw: `${n(v.unseen)} allocated garments with no scan`,
      value: `${(v.unseenShare * 100).toFixed(1)}% of fleet not seen in laundry`,
      status: "CALCULATED",
      formula: "(allocated − scanned) ÷ allocated",
      impact: {
        CFO: "Possible lost or hoarded garments — a cost and accountability question.",
        "VP Operations": "Garments that may not be washed on schedule (hygiene audit risk).",
        Sustainability: "Unused garments are textile with no service value.",
      },
    },
    {
      signal: "Home / local wash baseline",
      source: "Baseline registry (assumption)",
      raw: `Compared with: ${baseline.baseline_name}`,
      value: `${n(v.sv.water / 1000)} m³ water · ${n(v.sv.co2 / 1000, 1)} tCO₂e vs baseline`,
      status: "ESTIMATE",
      formula: "baseline intensity × washed kg − allocated Lindström footprint",
      impact: {
        CFO: "Avoided utility and in-house laundry cost the customer did not carry.",
        "VP Operations": "No on-site laundry equipment, staff time or chemicals to manage.",
        Sustainability: "Reportable estimate for Scope 3 discussions — not an audited claim.",
      },
    },
  ];

  return (
    <section className="print-break">
      <SectionTitle eyebrow="05 · Value bridge" title="From operational data to boardroom value" />
      <div className="mb-4 flex flex-wrap gap-2 print:hidden">
        <Toggle on={mode === "matrix"} onClick={() => setMode("matrix")}>Executive translation matrix</Toggle>
        <Toggle on={mode === "pipeline"} onClick={() => setMode("pipeline")}>Enterprise data pipeline</Toggle>
      </div>

      {mode === "matrix" ? (
        <div className="rounded-lg border bg-card">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b p-4">
            <div className="flex gap-1 rounded-md bg-muted p-1">
              <Toggle small on={view === "ops"} onClick={() => setView("ops")}>eLindström operational view</Toggle>
              <Toggle small on={view === "exec"} onClick={() => setView("exec")}>Executive studio view</Toggle>
            </div>
            {view === "exec" && (
              <div className="flex items-center gap-1 text-xs">
                <span className="mr-1 text-muted-foreground">Speaking to:</span>
                {AUDIENCES.map((a) => (
                  <Toggle small key={a} on={aud === a} onClick={() => setAud(a)}>{a}</Toggle>
                ))}
              </div>
            )}
          </div>
          <div className="divide-y">
            {rows.map((r) => (
              <div key={r.signal} className="grid gap-5 p-5 lg:grid-cols-[180px_1fr]">
                <div>
                  <p className="font-medium">{r.signal}</p>
                  <p className="font-mono text-[11px] text-muted-foreground">{r.source}</p>
                </div>
                {view === "ops" ? (
                  <p className="font-mono text-sm text-muted-foreground">{r.raw}</p>
                ) : (
                  <div className="grid gap-4 xl:grid-cols-[1fr_auto_1fr] xl:items-start">
                    <div title={r.formula} className="cursor-help">
                      <p className="font-display text-lg leading-snug">{r.value}</p>
                    </div>
                    <ArrowRight className="hidden h-4 w-4 text-primary xl:mt-1.5 xl:block" />
                    <div>
                      <StatusTag status={r.status} />
                      <p className="mt-1 text-sm">{r.impact[aud]}</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          <p className="border-t p-4 text-xs text-muted-foreground">
            All values are synthetic hackathon data. Garment cost and repair factor are assumptions; euro figures are
            indicative estimates, not invoiced savings. Change “Compare with” or “Sensitivity scenario” in the header to see ranges.
          </p>
        </div>
      ) : (
        <Pipeline />
      )}
    </section>
  );
}

const SYSTEMS = [
  { icon: Radio, name: "RFID laundry antennas", fields: "asset scans in/out, wash counts, last-seen date", cadence: "Daily batch" },
  { icon: Receipt, name: "ERP contract tables", fields: "customer → site hierarchy, wearers, allocated garments, products", cadence: "Weekly sync" },
  { icon: Wrench, name: "Tableau repair exports", fields: "repairs by Account Top Level, Delivery Customer, Product Code, Laundry, Repair Name", cadence: "Monthly sync" },
  { icon: Gauge, name: "Laundry resource meters", fields: "water, energy, process & delivery CO₂ per laundry", cadence: "Monthly sync" },
];

function Pipeline() {
  const [active, setActive] = useState<number | null>(null);
  return (
    <div className="rounded-xl border bg-card p-5">
      <div className="grid gap-4 lg:grid-cols-[1fr_auto_1fr_auto_1fr] lg:items-center">
        <div className="space-y-2">
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">1 · Lindström sources</p>
          {SYSTEMS.map((s, i) => (
            <Button variant="outline"
              key={s.name}
              onMouseEnter={() => setActive(i)}
              onFocus={() => setActive(i)}
              onClick={() => setActive(i)}
              className={cn(
                "flex h-auto w-full items-start justify-start gap-3 whitespace-normal rounded-lg border p-3 text-left transition-colors",
                active === i ? "border-primary bg-primary/5" : "hover:border-primary/40",
              )}
            >
              <s.icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <span>
                <span className="block text-sm font-medium">{s.name}</span>
                <span className="font-mono text-[11px] text-muted-foreground">{s.cadence}</span>
              </span>
            </Button>
          ))}
        </div>
        <ArrowRight className="mx-auto hidden h-5 w-5 text-primary lg:block" />
        <div className="rounded-lg border-2 border-dashed border-primary/50 p-4">
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">2 · Semantic model</p>
          <Database className="my-2 h-5 w-5 text-primary" />
          <p className="font-display text-lg">Customer → Site → Product → Month</p>
          <p className="mt-2 text-xs text-muted-foreground">
            Every source is joined on these four keys. Unmapped records are counted and shown, never silently dropped.
          </p>
          <div className="mt-3 flex items-start gap-2 rounded-md bg-muted p-2 text-xs">
            <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span>
              Privacy boundary: RFID scans are aggregated to site × product × month here. No wearer names or person-level
              histories leave this layer (GDPR data minimisation).
            </span>
          </div>
        </div>
        <ArrowRight className="mx-auto hidden h-5 w-5 text-primary lg:block" />
        <div className="space-y-2">
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">3 · Review studio</p>
          {["Tested calculation rules (same as this dashboard)", "KAM review dashboard + PDF", "Future: eLindström customer view", "Future: Copilot in Teams"].map((x) => (
            <div key={x} className="rounded-lg border p-3 text-sm">{x}</div>
          ))}
        </div>
      </div>
      <div className="mt-4 min-h-14 rounded-lg bg-muted p-3 text-sm">
        {active === null ? (
          <span className="text-muted-foreground">Select a source to see what it contributes.</span>
        ) : (
          <>
            <span className="font-medium">{SYSTEMS[active]?.name}:</span> {SYSTEMS[active]?.fields}.{" "}
            <span className="font-mono text-xs text-muted-foreground">Refresh: {SYSTEMS[active]?.cadence.toLowerCase()}</span>
          </>
        )}
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Proposed architecture for discussion — source names and cadences are assumptions to confirm with Lindström IT.
        Only the repair-export dimensions are confirmed in the challenge brief. Today this prototype reads a monthly
        extract of the synthetic data pack in the same shape.
      </p>
    </div>
  );
}

function Toggle({ on, onClick, children, small }: { on: boolean; onClick: () => void; children: React.ReactNode; small?: boolean }) {
  return (
    <Button variant={on ? "default" : "outline"} size="sm" aria-pressed={on}
      onClick={onClick}
      className={cn(
        "rounded-md border font-medium transition-colors",
        small ? "px-2 py-1 text-xs" : "px-3 py-1.5 text-sm",
        on ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:border-primary/40",
      )}
    >
      {children}
    </Button>
  );
}
