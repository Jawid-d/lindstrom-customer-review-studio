import type { ReactNode } from "react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { Status, PerformanceGrade } from "@/lib/review";
import { PerformanceBadge } from "./Performance";
import { cn } from "@/lib/utils";

const STATUS_STYLE: Record<Status, string> = {
  MEASURED: "border-status-measured/40 bg-status-measured/10 text-status-measured",
  CALCULATED: "border-status-calculated/40 bg-status-calculated/10 text-status-calculated",
  ALLOCATED: "border-status-estimate/40 bg-status-estimate/10 text-status-estimate",
  ESTIMATE: "border-status-estimate/40 bg-status-estimate/10 text-status-estimate",
  SYNTHETIC: "border-status-synthetic/40 bg-status-synthetic/10 text-status-synthetic",
};

const STATUS_HELP: Record<Status, string> = {
  MEASURED: "Recorded directly in an operational source (synthetic here).",
  CALCULATED: "Computed deterministically from recorded values.",
  ALLOCATED: "Laundry-level figure shared to the customer by washed kg.",
  ESTIMATE: "Depends on an assumption or baseline. Use with care.",
  SYNTHETIC: "Illustrative hackathon data, not real Lindström data.",
};

export function StatusTag({ status, className }: { status: Status; className?: string }) {
  return (
    <span
      title={STATUS_HELP[status]}
      className={cn(
        "inline-flex items-center rounded-sm border px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider",
        STATUS_STYLE[status],
        className,
      )}
    >
      {status === "ALLOCATED" ? "Allocated est." : status.toLowerCase()}
    </span>
  );
}

const FILL: Record<Tone, string> = {
  water: "bg-pillar-water/[0.07] border-pillar-water/20 border-l-[3px] border-l-pillar-water",
  carbon: "bg-pillar-carbon/[0.07] border-pillar-carbon/20 border-l-[3px] border-l-pillar-carbon",
  energy: "bg-pillar-energy/[0.07] border-pillar-energy/20 border-l-[3px] border-l-pillar-energy",
  circular: "bg-pillar-circular/[0.07] border-pillar-circular/20 border-l-[3px] border-l-pillar-circular",
  service: "bg-pillar-service/[0.07] border-pillar-service/20 border-l-[3px] border-l-pillar-service",
  cost: "bg-pillar-cost/[0.07] border-pillar-cost/20 border-l-[3px] border-l-pillar-cost",
  neutral: "bg-pillar-neutral/[0.07] border-pillar-neutral/20 border-l-[3px] border-l-pillar-neutral",
};
export const toneFill = (t: Tone) => FILL[t];

export type Tone = "water" | "carbon" | "energy" | "circular" | "service" | "cost" | "neutral";
export const TONE: Record<Tone, { bar: string; text: string; ring: string; soft: string; label: string }> = {
  water: { bar: "bg-pillar-water", text: "text-pillar-water", ring: "ring-pillar-water/40", soft: "bg-pillar-water/10 text-pillar-water border-pillar-water/30", label: "Water" },
  carbon: { bar: "bg-pillar-carbon", text: "text-pillar-carbon", ring: "ring-pillar-carbon/40", soft: "bg-pillar-carbon/10 text-pillar-carbon border-pillar-carbon/30", label: "Emissions" },
  energy: { bar: "bg-pillar-energy", text: "text-pillar-energy", ring: "ring-pillar-energy/40", soft: "bg-pillar-energy/10 text-pillar-energy border-pillar-energy/30", label: "Energy" },
  circular: { bar: "bg-pillar-circular", text: "text-pillar-circular", ring: "ring-pillar-circular/40", soft: "bg-pillar-circular/10 text-pillar-circular border-pillar-circular/30", label: "Circularity" },
  service: { bar: "bg-pillar-service", text: "text-pillar-service", ring: "ring-pillar-service/40", soft: "bg-pillar-service/10 text-pillar-service border-pillar-service/30", label: "Service & hygiene" },
  cost: { bar: "bg-pillar-cost", text: "text-pillar-cost", ring: "ring-pillar-cost/40", soft: "bg-pillar-cost/10 text-pillar-cost border-pillar-cost/30", label: "Cost (€)" },
  neutral: { bar: "bg-pillar-neutral", text: "text-foreground", ring: "ring-primary/30", soft: "bg-secondary text-secondary-foreground border-border", label: "Scale" },
};

export function ToneLegend() {
  const tones: Tone[] = ["water", "carbon", "energy", "circular", "service", "cost", "neutral"];
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px]">
      <span className="font-mono uppercase tracking-widest text-muted-foreground">Colour key</span>
      {tones.map((t) => (
        <span key={t} className="inline-flex items-center gap-1.5 text-foreground">
          <span className={cn("h-2.5 w-2.5 rounded-full", TONE[t].bar)} />
          {TONE[t].label}
        </span>
      ))}
      <span className="mx-1 h-3 w-px bg-border" />
      <span className="text-muted-foreground">Tags show how sure a number is:</span>
      {(["MEASURED", "CALCULATED", "ESTIMATE", "SYNTHETIC"] as Status[]).map((s) => <StatusTag key={s} status={s} />)}
    </div>
  );
}

export function Kpi({
  label,
  value,
  unit,
  status,
  formula,
  sub,
  emphasis,
  tone = "neutral",
  jumpTo,
  grade,
  highlight,
}: {
  highlight?: boolean;
  grade?: PerformanceGrade | null;
  jumpTo?: string;
  tone?: Tone;
  label: string;
  value: string;
  unit?: string | undefined;
  status: Status;
  formula: string;
  sub?: ReactNode;
  emphasis?: boolean;
}) {
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <div
            role={jumpTo ? "link" : undefined}
            tabIndex={jumpTo ? 0 : undefined}
            onClick={jumpTo ? () => document.getElementById(jumpTo)?.scrollIntoView({ behavior: "smooth", block: "start" }) : undefined}
            onKeyDown={jumpTo ? (e) => { if (e.key === "Enter") document.getElementById(jumpTo)?.scrollIntoView({ behavior: "smooth", block: "start" }); } : undefined}
            className={cn(
              jumpTo ? "cursor-pointer" : "cursor-help",
              "review-kpi group relative min-w-0 rounded-xl border p-4 text-left transition-shadow hover:shadow-card focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              highlight && "review-kpi-highlight",
              `kpi-fill-${tone}`,
              TONE[tone].ring,
              emphasis && "review-kpi-focused",
            )}
          >
            <div className="flex flex-wrap items-start justify-between gap-2">
              <p className="flex min-w-0 flex-1 items-start gap-2 text-xs font-semibold leading-relaxed text-foreground/80">
                <span className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", TONE[tone].bar)} />
                {label}
              </p>
              <StatusTag status={status} />
            </div>
            <p className={cn("mt-3 flex flex-wrap items-baseline gap-y-1 font-display text-2xl leading-tight tabular", TONE[tone].text, highlight && "text-3xl")}>
              {value}
              {unit && <span className="ml-1 font-sans text-sm text-muted-foreground">{unit}</span>}
            </p>
            {sub && <div className="mt-3 text-xs leading-relaxed text-muted-foreground">{sub}</div>}
            {grade !== undefined && <div className="mt-3"><PerformanceBadge grade={grade} /></div>}
            {jumpTo && <span className="mt-4 block text-[11px] font-medium text-muted-foreground group-hover:text-primary print:hidden">See details ↓</span>}
          </div>
        </TooltipTrigger>
        <TooltipContent className="max-w-xs font-mono text-xs">{formula}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function SectionTitle({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return (
    <div className="review-section-title mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-primary">
          {eyebrow}
        </p>
        <h2 className="mt-3 max-w-3xl font-display text-2xl font-medium leading-snug text-foreground md:text-3xl">{title}</h2>
      </div>
      {children}
    </div>
  );
}

export const n = (v: number, d = 0) =>
  v.toLocaleString("en-GB", { maximumFractionDigits: d, minimumFractionDigits: d });
