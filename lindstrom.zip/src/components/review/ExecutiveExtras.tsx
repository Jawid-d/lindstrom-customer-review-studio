import {
  benchmarkSites, repairIntensity, workforceElasticity,
  type Customer, type Site, type Totals,
} from "@/lib/review";
import { Kpi, n } from "./parts";

export function ExecutiveExtras({ customer, sites, t, floor, part }: { customer: Customer; sites: Site[]; t: Totals; floor: number; part: "circular" | "service" }) {
  const ri = repairIntensity(t);
  const wf = workforceElasticity(customer);
  const bm = sites.length > 1 ? benchmarkSites(sites, floor, customer.sites) : null;
  if (part === "circular") return (
      <Kpi
        tone="circular"
        jumpTo="review-circularity" label="Repairs per 100 garments"
        value={n(ri.per100, 1)}
        status="CALCULATED"
        formula={`${n(t.repairs)} repairs ÷ ${n(t.allocated)} allocated garments × 100. Shows how much of the fleet repair kept in use; it is not a lifespan figure — the data pack has no garment age.`}
        sub={`About 1 repair for every ${n(ri.per100 ? 100 / ri.per100 : 0, 1)} garments in 2025, each one kept in use`}
      />
  );
  return (
    <>
            {bm ? (
        <Kpi
          jumpTo="review-sites"
          tone="service"
          label="Benchmark vs improvement site"
          value={`${bm.bestScore} / ${bm.worstScore}`}
          status="CALCULATED"
          formula={`Highest and lowest proposed site health score (wash 35, rightsizing 25, requests 20, delivery 20). Gap = ${bm.gap} points. Weights are a proposal for Lindström to confirm.`}
          sub={<><b className="text-foreground">{bm.best.name}</b> leads · <b className="text-foreground">{bm.worst.name}</b> has the most room to improve</>}
        />
      ) : (
        <Kpi tone="service" label="Benchmark vs improvement site" value="—" status="CALCULATED" formula="Needs 2+ sites; clear the site filter." sub="Select the whole account to compare sites" />
      )}
      <Kpi
        tone="cost"
        jumpTo="review-cost" label="Seasonal workforce swing"
        value={n(wf.swing)}
        unit="wearers"
        status="ESTIMATE"
        formula={`Peak ${n(wf.peak)} (${wf.peakMonth}) − trough ${n(wf.trough)} (${wf.troughMonth}) monthly wearers. Garments an owner would hold for the peak = swing × ${n(wf.perWearer, 2)} garments per wearer = ${n(wf.strandedGarments)}; × average garment cost = €${n(wf.strandedEur)}. Account-wide, not affected by site filter.`}
        sub={`${n(wf.swingShare * 100, 1)}% swing · ~€${n(wf.strandedEur)} capital not tied up in peak stock`}
      />
    </>
  );
}
