import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowRight, Copy, Loader2, RefreshCw, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import type { Fact } from "@/lib/review";
import { generateTalkingPoints, type TalkingPoints } from "@/lib/talking-points.functions";
import { StatusTag } from "./parts";

const TOPICS = [
  { id: "steering", label: "Steering committee", brief: "Executive steering committee: overall results, main risk and the decision for today" },
  { id: "cfo", label: "Cost & value", brief: "CFO and procurement: cost avoided, total cost of ownership, return and value for the service fee" },
  { id: "esg", label: "Sustainability", brief: "Sustainability lead: emissions, water, energy, textile avoided and circularity" },
  { id: "hygiene", label: "Hygiene & operations", brief: "Operations and quality: wash compliance, site risk and hygiene follow-up" },
] as const;

export function AiTalkingPoints({ facts, customerName }: { facts: Fact[]; customerName: string }) {
  const run = useServerFn(generateTalkingPoints);
  const [topic, setTopic] = useState<(typeof TOPICS)[number]["id"]>("steering");
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [out, setOut] = useState<TalkingPoints | null>(null);
  const cache = useRef(new Map<string, TalkingPoints>());
  const factsRef = useRef(facts);
  factsRef.current = facts;
  const factsKey = JSON.stringify(facts);
  const requestId = useRef(0);

  async function go(t: typeof topic, q = "") {
    const id = ++requestId.current;
    const key = `${customerName}|${t}|${factsKey}`;
    const cached = !q ? cache.current.get(key) : undefined;
    if (cached) { setOut(cached); setError(null); setLoading(false); return; }
    setOut(null);
    setLoading(true);
    setError(null);
    try {
      const brief = TOPICS.find((x) => x.id === t)?.brief ?? TOPICS[0].brief;
      const r = await run({ data: { audience: brief, context: q, facts: factsRef.current } });
      if (id !== requestId.current) return;
      if (r.ok) { setOut(r.result); if (!q) cache.current.set(key, r.result); }
      else setError(r.error);
    } catch {
      if (id === requestId.current) setError("Could not prepare the briefing. Please try again.");
    } finally {
      if (id === requestId.current) setLoading(false);
    }
  }

  useEffect(() => { void go(topic); return () => { requestId.current += 1; }; }, [customerName, topic, factsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  function copy() {
    if (!out) return;
    const txt = [
      `${customerName} — ${TOPICS.find((x) => x.id === topic)?.label ?? "Meeting"} briefing`, "",
      `Opening: ${out.hook}`, "", "Results delivered:",
      ...out.outcomes.map((p, i) => `${i + 1}. ${p.text}`), "",
      `Watch: ${out.watch?.text ?? ""}`, `Proposed decision: ${out.decision}`,
      ...(out.answer ? ["", `Q: ${question}`, `A: ${out.answer}`] : []),
    ].join("\n");
    navigator.clipboard.writeText(txt).then(() => toast.success("Copied"));
  }

  return (
    <section className="space-y-5">
      <div>
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-primary">Meeting briefing</p>
        <h2 className="mt-1 font-display text-2xl">{customerName}</h2>
      </div>

      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Briefing topic">
        {TOPICS.map((t) => (
          <Button variant="outline" size="sm"
            key={t.id}
            role="tab"
            aria-selected={topic === t.id}
            onClick={() => setTopic(t.id)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
              topic === t.id ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-muted",
            )}
          >
            {t.label}
          </Button>
        ))}
      </div>

      <div className="rounded-lg border bg-card p-5">
        {error && (
          <div className="space-y-3">
            <p className="text-sm text-destructive">{error}</p>
            <Button variant="outline" size="sm" onClick={() => go(topic)}><RefreshCw className="mr-1 h-3 w-3" />Try again</Button>
          </div>
        )}
        {loading && !out && (
          <p className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />Preparing your briefing…</p>
        )}
        {out && (
          <div className={cn("space-y-5", loading && "opacity-50")}>
            <div>
              <div className="flex items-center justify-between gap-3">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">1 · Opening line</p>
                <Button variant="ghost" size="sm" onClick={copy}><Copy className="mr-1 h-3 w-3" />Copy</Button>
              </div>
              <p className="mt-1 font-display text-lg leading-snug">“{out.hook}”</p>
            </div>
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">2 · Results delivered</p>
              <ol className="mt-2 list-decimal space-y-2 pl-5 text-sm">
                {out.outcomes?.map((p) => (
                  <li key={p.text}>{p.text}
                    {p.figures?.length > 0 && <span className="mt-0.5 block text-[11px] text-muted-foreground">Uses: {p.figures.join(" · ")}</span>}
                  </li>
                ))}
              </ol>
            </div>
            {out.watch?.text && (
              <div className="rounded-md border border-warning/40 bg-warning/10 p-3 text-sm">
                <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider">3 · Worth raising early</p>
                {out.watch.text}
              </div>
            )}
            <div className="rounded-md bg-muted p-3 text-sm">
              <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-primary">4 · Decision to propose</p>
              <p className="flex gap-2"><ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{out.decision}</p>
            </div>
            {out.answer && (
              <div className="rounded-md border p-3 text-sm">
                <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Your question</p>
                {out.answer}
              </div>
            )}
          </div>
        )}
      </div>

      <form
        className="flex gap-2"
        onSubmit={(e) => { e.preventDefault(); if (question.trim()) void go(topic, question.trim()); }}
      >
        <Input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          maxLength={800}
          placeholder="Ask about this customer, e.g. “What if they push back on price?”"
          className="text-sm"
        />
        <Button type="submit" size="icon" disabled={loading || !question.trim()} aria-label="Ask">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </form>

      <details className="text-[11px] text-muted-foreground">
        <summary className="cursor-pointer">AI-written draft — it only uses the {facts.length} figures shown on the dashboard</summary>
        {out?.caveats?.length ? <ul className="mt-2 list-disc space-y-1 pl-4">{out.caveats.map((c) => <li key={c}>{c}</li>)}</ul> : null}
        <ul className="mt-2 space-y-1">
          {facts.map((f) => (
            <li key={f.label} className="flex items-center justify-between gap-2">
              <span>{f.label}: <span className="text-foreground">{f.value}</span></span>
              <StatusTag status={f.status} />
            </li>
          ))}
        </ul>
      </details>
    </section>
  );
}
