import { ChevronDown, FileDown, FileSpreadsheet, FileText, Table } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  cfoValue,
  hiddenCosts,
  healthTable,
  siteHygiene,
  siteMetrics,
  templateCsv,
  totals,
  DEFAULT_WASH_FLOOR,
  textileImpact,
  type CostInputs,
  type Customer,
} from "@/lib/review";

type Props = {
  customer: Customer;
  sites: Customer["sites"];
  sv: { water: number; energy: number; co2: number; replacementsPostponed: number };
  costs: CostInputs;
  baselineName: string;
  scenarioLabel: string;
  washFloor?: number;
};

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

const r = (v: number | null, d = 0) => (v === null ? "" : Number(v.toFixed(d)));

export function ExportMenu({ customer, sites, sv, costs, baselineName, scenarioLabel, washFloor = DEFAULT_WASH_FLOOR }: Props) {
  const slug = customer.name.toLowerCase().replace(/[^a-z0-9]+/g, "-");

  async function excel() {
    const XLSX = await import("xlsx");
    const t = totals(sites);
    const cfo = cfoValue(t, sv, costs);
    const hc = hiddenCosts(costs);
    const health = healthTable(sites, washFloor, customer.sites);
    const summary = [
      ["Customer", customer.name, ""],
      ["Comparison", baselineName, ""],
      ["Sensitivity scenario", scenarioLabel, ""],
      ["Proposed wash floor", washFloor, "washes / garment / month"],
      ["Data status", "Synthetic hackathon data — savings are estimates, not audited claims", ""],
      [],
      ["KPI", "Value", "Unit"],
      ["Delivery sites", t.sites, "sites"],
      ["Washed", r(t.washedKg, 1), "kg"],
      ["Repairs", t.repairs, "repairs"],
      ["Service requests", t.requests, "requests"],
      ["Wearers (Dec)", t.wearers, "people"],
      ["Garments allocated", t.allocated, "pieces"],
      ["Water saved", r(sv.water), "L"],
      ["Energy saved", r(sv.energy), "kWh"],
      ["CO₂e saved", r(sv.co2), "kgCO₂e"],
      ["Replacements postponed", r(sv.replacementsPostponed), "garments"],
      ["New textile production avoided", r(textileImpact(customer, sv.replacementsPostponed).kg / 1000, 1), "t (estimate)"],
    ];
    const cost = [
      ["Category", "€ / year", "Share of annual cash benefit %", "Note"],
      ["Water", r(cfo.water), r(cfo.shares.water, 1), "Annual cash benefit"],
      ["Energy", r(cfo.energy), r(cfo.shares.energy, 1), "Annual cash benefit"],
      ["Replacements postponed", r(cfo.replacements), r(cfo.shares.replacements, 1), "Annual cash benefit"],
      ["Annual cash benefit (subtotal)", r(cfo.annualCashBenefit), 100, ""],
      ["Carbon (shadow price)", r(cfo.carbon), "", "Non-cash, kept separate"],
      ["Owned fleet buffer (upfront)", r(cfo.fleet), "", `${cfo.extraGarments} extra garments, upfront capital`],
      [],
      ["Lindström service fee (entered)", r(cfo.fee), "", cfo.fee === null ? "Not entered" : ""],
      ["Alternative annual cost (entered)", r(cfo.alternative), "", cfo.alternative === null ? "Not entered" : ""],
      ["Annual difference", r(cfo.annualDifference), "", ""],
      ["ROI %", r(cfo.roiPct, 1), "", ""],
      ["Saving vs alternative %", r(cfo.savingsPct, 1), "", ""],
      [],
      ["Invisible costs — customer-entered, account-wide", "€ / year", "", "Not added to TCO or benefit shares"],
      ["Alternative administration", r(hc.admin), "", "Annual admin hours × loaded hourly rate"],
      ["Customer administration with Lindström", r(hc.serviceAdmin), "", "Service-side hours × same loaded hourly rate"],
      ["Administration difference", r(hc.adminDifference), "", "Alternative − service administration; not guaranteed savings"],
      ["Alternative garment losses", r(hc.loss), "", "Annual lost garments × garment price"],
      ["Alternative audit preparation", r(hc.audit), "", "Separate annual hours × loaded hourly rate; no penalties"],
      ["Entered hidden-cost subtotal (partial)", r(hc.total), "", "Missing entries excluded, not zero; not complete TCO"],
      ["Customer cost source", costs.hiddenCostSource ?? "Not supplied", "", ""],
    ];
    const siteRows = sites.map((s) => {
      const m = siteMetrics(s);
      const h = siteHygiene(s, washFloor);
      return {
        Site: s.name,
        City: s.city,
        Country: s.country,
        Type: s.type,
        "Washed kg": r(s.washedKg, 1),
        Repairs: s.repairs,
        "Service requests": s.requests,
        "Utilisation %": r(m.utilisation * 100, 1),
        "Garments with no scan activity": m.idle,
        "Late delivery %": r(m.lateRate * 100, 1),
        "Wash risk (proposed)": h.risk,
        "Site health (proposed)": health.get(s.id)?.score ?? "",
        Flags: m.flags.join("; "),
      };
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summary), "Executive summary");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(siteRows), "Sites");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(cost), "Cost comparison");
    const out = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    downloadBlob(
      new Blob([out], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }),
      `${slug}-review-2025.xlsx`,
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="secondary" size="sm">
          <FileDown className="mr-1 h-4 w-4" /> Export review <ChevronDown className="ml-1 h-3.5 w-3.5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel>{customer.name}</DropdownMenuLabel>
        <DropdownMenuItem onSelect={() => setTimeout(() => window.print(), 50)}>
          <FileText className="mr-2 h-4 w-4" />
          <div><p>PDF review</p><p className="text-xs text-muted-foreground">Print → Save as PDF</p></div>
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => void excel()}>
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          <div><p>Excel data pack (.xlsx)</p><p className="text-xs text-muted-foreground">Summary, sites, cost comparison</p></div>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={() => downloadBlob(new Blob([templateCsv()], { type: "text/csv;charset=utf-8" }), "lindstrom-review-import-template.csv")}>
          <Table className="mr-2 h-4 w-4" />
          <div><p>Data import template (.csv)</p><p className="text-xs text-muted-foreground">For IT / site managers</p></div>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
