import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DEFAULT_WASH_FLOOR,
  HIGH_RISK_MONTHS,
  HYGIENE_CRITICAL,
  UNSEEN_FLAG,
  WASH_FLOORS,
  portfolioHygiene,
  performanceGrade,
  type PerformanceRules,
  type HygieneRisk,
  type Site,
} from "@/lib/review";
import { cn } from "@/lib/utils";
import { Kpi, SectionTitle, StatusTag, n } from "./parts";

const RISK_STYLE: Record<HygieneRisk, string> = {
  High: "bg-destructive/15 text-destructive",
  Medium: "bg-warning/20 text-warning-foreground",
  Low: "bg-secondary text-secondary-foreground",
};
const ORDER: Record<HygieneRisk, number> = { High: 0, Medium: 1, Low: 2 };

export function HygieneSection({ sites, industry, shortName, rules, floor, setFloor }: { sites: Site[]; industry: string; shortName: (n: string) => string; rules: PerformanceRules; floor: number; setFloor: (f: number) => void }) {
  const p = portfolioHygiene(sites, floor);
  const rows = [...p.rows].sort((a, b) => ORDER[a.h.risk] - ORDER[b.h.risk] || b.h.critUnderMonths - a.h.critUnderMonths || b.h.underMonths - a.h.underMonths);
  const hasCritical = p.critLineMonths > 0;
  const pct = (v: number) => `${n(v * 100, 1)}%`;

  return (
    <section className="print-break">
      <SectionTitle eyebrow="04 · Hygiene" title="Wash compliance & garment activity">
        <div className="flex flex-wrap items-center gap-2 text-xs print:hidden">
          <span className="text-muted-foreground">Wash floor</span>
          {WASH_FLOORS.map((f) => (
            <Button variant="outline" size="sm"
              key={f}
              onClick={() => setFloor(f)}
              className={cn("rounded border px-2 py-1 tabular", floor === f ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:border-primary/50")}
            >
              {n(f, 1)} / month
            </Button>
          ))}
        </div>
      </SectionTitle>

      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi tone="service"
          label="Wash compliance"
          grade={performanceGrade(p.lineMonths ? p.compliantShare * 100 : null, "compliance", rules)}
          value={pct(p.compliantShare)}
          status="CALCULATED"
          formula={`Share of product-line months where washed_pieces ÷ allocated_pieces ≥ ${n(floor, 1)}. ${n(p.lineMonths - p.underMonths)} of ${n(p.lineMonths)} line-months meet the floor.`}
          sub={`${n(p.underMonths)} line-months under ${n(floor, 1)} washes/garment`}
          emphasis
        />
        <Kpi tone="service"
          label="Washes per garment"
          value={n(p.washRate, 2)}
          unit="/ month"
          status="CALCULATED"
          formula="Σ washed_pieces ÷ Σ allocated_pieces over all months and product lines (Service_Activity)."
          sub={`Floor set at ${n(floor, 1)}`}
        />
        <Kpi tone="service"
          label="Hygiene-critical lines under floor"
          value={hasCritical ? n(p.critUnderMonths) : "—"}
          unit={hasCritical ? `of ${n(p.critLineMonths)}` : undefined}
          status="CALCULATED"
          formula="Line-months for Food Industry Coat (P1004) and Healthcare Tunic (P1005) where washes per garment fall under the floor."
          sub={hasCritical ? "Food coat / healthcare tunic months" : `No food or healthcare garments for ${industry}`}
        />
        <Kpi tone="service"
          label="Garments not seen"
          grade={performanceGrade(p.lineMonths && sites.some(s => s.lines.some(l => l.alloc > 0)) ? (1 - p.unseen) * 100 : null, "scan", rules)}
          value={pct(p.unseen)}
          status="MEASURED"
          formula="1 − Σ active_assets_scanned ÷ Σ allocated_pieces. Allocated garments with no RFID scan in the month — possibly in lockers, not in the wash loop."
          sub={`${p.high} high · ${p.medium} medium risk sites`}
        />
      </div>

      <div className="mt-8 grid min-w-0 gap-6 xl:grid-cols-[1.5fr_1fr]">
        <div className="min-w-0 overflow-x-auto rounded-lg border bg-card">
          <table className="w-full text-sm">
            <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-3 py-2">Site</th>
                <th className="px-3 py-2">Risk</th>
                <th className="px-3 py-2 text-right">Washes / garment</th>
                <th className="px-3 py-2 text-right">Months under floor</th>
                <th className="px-3 py-2 text-right">Critical months under</th>
                <th className="px-3 py-2 text-right">Not seen</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ site, h }) => (
                <tr key={site.id} className="border-t">
                  <td className="px-3 py-2">{shortName(site.name)}<span className="ml-1 text-xs text-muted-foreground">{site.country}</span></td>
                  <td className="px-3 py-2"><span className={cn("rounded px-1.5 py-0.5 text-[11px] font-medium", RISK_STYLE[h.risk])}>{h.risk}</span></td>
                  <td className={cn("px-3 py-2 text-right tabular", h.washRate < floor && "text-destructive")}>{n(h.washRate, 2)}</td>
                  <td className="px-3 py-2 text-right tabular">{h.underMonths} / {h.lineMonths}</td>
                  <td className="px-3 py-2 text-right tabular">{h.critLineMonths ? `${h.critUnderMonths} / ${h.critLineMonths}` : "—"}</td>
                  <td className={cn("px-3 py-2 text-right tabular", h.unseen > UNSEEN_FLAG && "text-destructive")}>{pct(h.unseen)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="space-y-4">
          <div className="rounded-lg border bg-card p-4 text-sm">
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-primary" />
              <p className="font-medium">What "overdue" means here</p>
              <StatusTag status="ESTIMATE" />
            </div>
            <dl className="mt-3 space-y-2 text-xs text-muted-foreground">
              <div><dt className="font-medium text-foreground">Line-month</dt><dd>One product line at one site in one month — the level the data is recorded at.</dd></div>
              <div><dt className="font-medium text-foreground">Under the wash floor (overdue)</dt><dd>Washed pieces ÷ allocated pieces &lt; {n(floor, 1)} that month. On average each garment came back fewer than {n(floor, 1)} times.</dd></div>
              <div><dt className="font-medium text-foreground">Not seen</dt><dd>Allocated garments with no RFID scan in the month (&gt; {n(UNSEEN_FLAG * 100)}% flags the site).</dd></div>
              <div><dt className="font-medium text-foreground">Hygiene-critical</dt><dd>{HYGIENE_CRITICAL.length} product lines: Food Industry Coat and Healthcare Tunic.</dd></div>
              <div>
                <dt className="font-medium text-foreground">Risk level</dt>
                <dd><strong>High</strong>: a critical line under the floor in {HIGH_RISK_MONTHS}+ months. <strong>Medium</strong>: any critical month under, over 25% of line-months under, or over {n(UNSEEN_FLAG * 100)}% not seen. <strong>Low</strong>: otherwise.</dd>
              </div>
            </dl>
          </div>
          <div className="rounded-lg border border-dashed bg-muted/40 p-4 text-xs text-muted-foreground">
            <p className="font-medium text-foreground">Proposed KPIs — for Lindström to confirm</p>
            <p className="mt-1">
              The wash floor and flags are placeholders, not Lindström policy. Each customer's agreed wash rhythm (for example the
              "four times a month" example from the kick-off call) and audit standards (BRCGS, IFS, hospital hygiene rules) should replace them.
              Data is per product line, so it shows site patterns, not named people. Garment-level RFID gaps would come from eLindström scans;
              the cycle sheet in this pack is only a sample and isn't used for flags.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
