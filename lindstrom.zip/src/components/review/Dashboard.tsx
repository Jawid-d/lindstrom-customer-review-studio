import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowDownUp, Info, Presentation, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { ExportMenu } from "./ExportMenu";
import { DataUpload } from "./DataUpload";
import { MethodologyDetails } from "./MethodologyDetails";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  FOCUS_LABEL,
  defaultCostsFor,
  DEFAULT_PERFORMANCE,
  DEFAULT_WASH_FLOOR,
  performanceGrade,
  resourceReduction,
  type PerformanceRules,
  applyOverride,
  avgGarmentCost,
  equivalents,
  textileImpact,
  EU_TEXTILE_WASTE_KG_PER_PERSON,
  SCENARIO,
  SCENARIO_LABEL,
  type BaselineOverride,
  type CostInputs,
  buildInsights,
  data,
  defaultFocus,
  savings,
  siteMetrics,
  steeringQuestions,
  talkingPointFacts,
  totals,
  type Focus,
  type Scenario,
} from "@/lib/review";
import { cn } from "@/lib/utils";
import { healthTable, repairMix, HEALTH_WEIGHTS, type Customer } from "@/lib/review";
import { ExecutiveExtras } from "./ExecutiveExtras";
import { PerformanceBadge, PerformanceCriteria } from "./Performance";
import { Kpi, SectionTitle, StatusTag, ToneLegend, n, toneFill } from "./parts";
import { HygieneSection } from "./HygieneSection";
import { ValueBridge } from "./ValueBridge";
import { AiTalkingPoints } from "./AiTalkingPoints";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { AssumptionPanel, CfoSection, EQUIV_SOURCES, EquivNote } from "./ClientValue";

const AGENDAS: { id: string; label: string; focus: Focus[]; target: string }[] = [
  { id: "all", label: "All pillars", focus: [], target: "review-value" },
  { id: "environment", label: "Water & emissions", focus: ["water", "emissions"], target: "review-value" },
  { id: "hygiene", label: "Hygiene & food safety", focus: ["service"], target: "review-hygiene" },
  { id: "cost", label: "Cost & rightsizing", focus: ["cost"], target: "review-cost" },
  { id: "circularity", label: "Circularity", focus: ["circularity"], target: "review-circularity" },
];
type SortKey = "name" | "washedKg" | "utilisation" | "idle" | "lateRate" | "repairs";

export function Dashboard() {
  const [customerId, setCustomerId] = useState("CUST001");
  const [uploaded, setUploaded] = useState<Customer[]>([]);
  const allCustomers = [...data.customers, ...uploaded];
  const customer = allCustomers.find((c) => c.id === customerId) ?? data.customers[0];
  const [baselineId, setBaselineId] = useState("B_LOCAL");
  const rawBaseline = data.baselines.find((b) => b.baseline_id === baselineId) ?? data.baselines[0];
  if (!customer || !rawBaseline) throw new Error("Review data is missing a customer or baseline");
  const customerIndustry = customer.industry;
  const [override, setOverride] = useState<BaselineOverride>({});
  const baseline = applyOverride(rawBaseline, override);
  const [costs, setCosts] = useState<CostInputs>(() => defaultCostsFor(customer.id, avgGarmentCost(customer)));
  const [presenting, setPresenting] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [assumptionsOpen, setAssumptionsOpen] = useState(false);
  const [rules, setRules] = useState<PerformanceRules>(DEFAULT_PERFORMANCE);
  const [washFloor, setWashFloor] = useState<number>(DEFAULT_WASH_FLOOR);
  const [scenario, setScenario] = useState<Scenario>("base");
  const [focus, setFocus] = useState<Focus[]>(defaultFocus(customer.industry));
  const [country, setCountry] = useState("all");
  const [selectedSite, setSelectedSite] = useState<string | null>(null);
  const [agenda, setAgenda] = useState("all");
  const [sort, setSort] = useState<{ key: SortKey; dir: 1 | -1 }>({ key: "idle", dir: -1 });

  const countries = Array.from(new Set(customer.sites.map((s) => s.country)));
  const sites = useMemo(
    () =>
      customer.sites.filter(
        (s) => (country === "all" || s.country === country) && (!selectedSite || s.id === selectedSite),
      ),
    [customer, country, selectedSite],
  );
  const t = totals(sites);
  const sv = savings(t, baseline, scenario);
  const svLow = savings(t, baseline, "low");
  const svHigh = savings(t, baseline, "high");
  const eq = equivalents(sv);
  const tx = textileImpact(customer, sv.replacementsPostponed);
  const insights = buildInsights(customer, sites, baseline, scenario, focus);
  const questions = steeringQuestions(customer, insights);
  const industryRules = data.industryPriorities.filter((p) => p.industry === customer.industry);

  const health = healthTable(customer.sites, washFloor);
  const tableRows = customer.sites
    .filter((s) => country === "all" || s.country === country)
    .map((s) => ({ s, m: siteMetrics(s) }))
    .sort((a, b) => {
      const v = (r: typeof a) =>
        sort.key === "name"
          ? r.s.name
          : sort.key === "washedKg" || sort.key === "repairs"
            ? r.s[sort.key]
            : r.m[sort.key];
      const x = v(a);
      const y = v(b);
      return (x > y ? 1 : x < y ? -1 : 0) * sort.dir;
    });

  function switchCustomer(id: string, list: Customer[] = allCustomers) {
    const c = list.find((x) => x.id === id);
    if (!c) return;
    setCustomerId(id);
    setFocus(defaultFocus(c.industry));
    setCountry("all");
    setSelectedSite(null);
    setAgenda("all");
    setOverride({});
    setCosts(defaultCostsFor(c.id, avgGarmentCost(c)));
    setRules(DEFAULT_PERFORMANCE);
    setWashFloor(DEFAULT_WASH_FLOOR);
  }
  function selectAgenda(id: string) {
    const selected = AGENDAS.find((item) => item.id === id);
    if (!selected) return;
    setAgenda(id);
    setFocus(selected.focus.length ? selected.focus : defaultFocus(customerIndustry));
    if (id === "cost") setSort({ key: "idle", dir: -1 });
    document.getElementById(selected.target)?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth", block: "start" });
  }
  const sortBy = (key: SortKey) => setSort((s) => ({ key, dir: s.key === key ? ((s.dir * -1) as 1 | -1) : -1 }));
  const isOn = (f: Focus) => focus.includes(f);
  const shortName = (name: string) => name.replace(`${customer.name.split(" ")[0]} `, "");

  return (
    <div className="min-h-screen bg-background">
      <header className="review-header border-b bg-card">
        <div className="review-topbar mx-auto max-w-7xl px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="font-display text-2xl font-semibold text-primary">Lindström</span>
            <span className="h-6 w-px bg-border" />
            <span className="text-xs font-medium text-muted-foreground">Customer Review Studio</span>
          </div>
            <div className="review-actions flex flex-wrap items-center gap-2 print:hidden">
              <Button variant={presenting ? "default" : "secondary"} size="sm" onClick={() => setPresenting((x) => !x)}>
                <Presentation className="mr-1 h-4 w-4" /> {presenting ? "Exit client mode" : "Present review"}
              </Button>
          <Sheet>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label={`AI briefing for ${customer.name}`}
                className="fixed bottom-5 right-5 z-40 flex max-w-[calc(100vw-2.5rem)] items-center gap-2.5 rounded-full bg-primary py-2 pl-2 pr-4 text-left text-primary-foreground shadow-lift transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 print:hidden"
              >
                <span className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                  <Sparkles className="h-4 w-4" />
                  <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 animate-pulse rounded-full border-2 border-primary bg-gold" />
                </span>
                <span className="min-w-0 leading-tight">
                  <span className="block text-sm font-medium">AI briefing</span>
                  <span className="block truncate text-[11px] opacity-80">{customer.name}</span>
                </span>
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-2xl">
              <SheetHeader className="sr-only"><SheetTitle>AI briefing</SheetTitle><SheetDescription>Talking points from this customer's figures</SheetDescription></SheetHeader>
              <div className="ai-drawer pt-2"><AiTalkingPoints facts={talkingPointFacts(customer, sites, baseline, scenario, { floor: washFloor, costs })} customerName={customer.name} /></div>
            </SheetContent>
          </Sheet>
              <MethodologyDialog rules={rules} washFloor={washFloor} customer={customer} sites={sites} baseline={baseline} override={override} costs={costs} scenario={scenario} />
              {!presenting && (
                <DataUpload
                  onImport={(c) => {
                    const next = [...uploaded.filter((x) => x.id !== c.id), c];
                    setUploaded(next);
                    switchCustomer(c.id, [...data.customers, ...next]);
                  }}
                />
              )}
              {!presenting && (
                <AssumptionPanel
                  open={assumptionsOpen}
                  setOpen={setAssumptionsOpen}
                  base={rawBaseline}
                  override={override}
                  setOverride={setOverride}
                  costs={costs}
                  setCosts={setCosts}
                  customerName={customer.name}
                  t={t}
                  sv={sv}
                  accountAllocated={totals(customer.sites).allocated}
                  filtered={sites.length !== customer.sites.length}
                  rules={rules}
                  setRules={setRules}
                  onReset={() => {
                    setOverride({});
                    setCosts(defaultCostsFor(customer.id, avgGarmentCost(customer)));
                    setRules(DEFAULT_PERFORMANCE);
                  }}
                />
              )}
              <ExportMenu
                customer={customer}
                sites={sites}
                sv={sv}
                costs={costs}
                baselineName={baseline.baseline_name}
                scenarioLabel={SCENARIO_LABEL[scenario]}
                washFloor={washFloor}
              />
            </div>
        </div>
      </header>
      <div className="review-cover bg-hero text-hero-foreground">
        <div className="mx-auto max-w-7xl px-6 py-9 sm:py-10">
          <div className="mb-4 flex flex-wrap items-center gap-3 text-xs text-hero-foreground/85">
            <span className="font-medium text-hero-accent">Customer value &amp; sustainability</span>
            <span className="h-3 w-px bg-hero-foreground/35" />
            <span>2025 annual review</span>
          </div>
          <h1 className="max-w-4xl break-words font-display text-3xl font-medium leading-tight sm:text-4xl lg:text-5xl">{customer.name}</h1>
          <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-hero-foreground/90">
            <span>{customer.industry} · {customer.segment}</span>
            <span>{customer.sites.length} customer delivery sites · {countries.length} countries</span>
          </div>
          <p className="mt-3 hidden text-xs text-hero-foreground/70 print:block">Comparison: {baseline.baseline_name} · {SCENARIO_LABEL[scenario]} · Synthetic hackathon data; savings are estimates.</p>
        </div>
      </div>
      <div className="review-utility border-y bg-card print:hidden">
        <div className="mx-auto max-w-7xl px-6 py-5">
          <div className="mb-3 flex items-center justify-between lg:hidden">
            <span className="text-xs font-medium text-muted-foreground">Review settings</span>
            <Button variant="ghost" size="sm" aria-expanded={filtersOpen} onClick={() => setFiltersOpen(value => !value)}><SlidersHorizontal className="mr-1 h-4 w-4" /> {filtersOpen ? "Hide filters" : "Filters"}</Button>
          </div>
            <div className={cn("review-filters grid min-w-0 grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4", !filtersOpen && "review-filters-collapsed")}>
              {!presenting && <Control label="Customer">
                <Select value={customerId} onValueChange={switchCustomer}>
                  <SelectTrigger className="w-full min-w-0 bg-card text-foreground"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {allCustomers.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}{c.id.startsWith("UPLOAD-") ? " (uploaded)" : ""}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Control>}
              <Control label="Compare with">
                <Select value={baselineId} onValueChange={setBaselineId}>
                  <SelectTrigger className="w-full min-w-0 bg-card text-foreground"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {data.baselines.map((b) => (
                      <SelectItem key={b.baseline_id} value={b.baseline_id}>{b.baseline_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Control>
              <Control label="Sensitivity scenario">
                <Select value={scenario} onValueChange={(v) => setScenario(v as Scenario)}>
                  <SelectTrigger className="w-full min-w-0 bg-card text-foreground"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="base">{SCENARIO_LABEL.base}</SelectItem>
                    <SelectItem value="low">{SCENARIO_LABEL.low}</SelectItem>
                    <SelectItem value="high">{SCENARIO_LABEL.high}</SelectItem>
                  </SelectContent>
                </Select>

              </Control>
              <Control label="Customer site country">
                <Select value={country} onValueChange={(v) => { setCountry(v); setSelectedSite(null); }}>
                  <SelectTrigger className="w-full min-w-0 bg-card text-foreground"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All countries</SelectItem>
                    {countries.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Control>
            </div>
          <nav aria-label="Meeting focus" className="mt-5 flex flex-wrap items-center gap-3 border-t pt-4">
            <span className="text-xs font-medium text-muted-foreground">Meeting focus</span>
            <Select value={agenda} onValueChange={selectAgenda}>
              <SelectTrigger aria-label="Meeting focus" className="w-full sm:w-56"><SelectValue /></SelectTrigger>
              <SelectContent>{AGENDAS.map(item => <SelectItem key={item.id} value={item.id}>{item.label}</SelectItem>)}</SelectContent>
            </Select>
            <p className="ml-auto flex items-center gap-1.5 text-[11px] text-muted-foreground"><Info className="h-3.5 w-3.5" /> {customer.id.startsWith("UPLOAD-") ? "Uploaded customer data · resource estimates" : "Demo data · savings are estimates"}</p>
          </nav>
        </div>
      </div>
      <main className="review-main">
        {selectedSite && (
          <div className="flex items-center justify-between rounded-md border border-primary bg-secondary px-4 py-2 text-sm">
            <span>Showing one site: <strong>{sites[0]?.name}</strong> ({sites[0]?.city}, {sites[0]?.type})</span>
            <Button variant="ghost" size="sm" onClick={() => setSelectedSite(null)} className="print:hidden">
              <X className="mr-1 h-4 w-4" /> Back to all sites
            </Button>
          </div>
        )}

        {/* Value summary */}
        <section id="review-value" className="scroll-mt-6">
          <SectionTitle eyebrow="01 · Look back" title="Value delivered in 2025" />
          <div className="value-kpi-grid grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <p className="col-span-full mt-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground first:mt-0">Environment</p>
            <Kpi
              tone="carbon"
              jumpTo="review-footprint" label="Emissions avoided"
              value={n(sv.co2 / 1000, 1)}
              unit="tCO₂e"
              status="ESTIMATE"
              emphasis={isOn("emissions")}
              grade={performanceGrade(resourceReduction(sv.co2, sv.baseCo2), "resource", rules)}
              formula={`washed kg × (${baseline.process_kgco2e_per_kg} + ${baseline.delivery_kgco2e_per_kg}) kgCO₂e/kg × ${SCENARIO[scenario].baselineFactor} comparison intensity factor − allocated process & delivery emissions. Scenario: ${SCENARIO_LABEL[scenario]}.`}
              sub={<>Range {n(svLow.co2 / 1000, 1)}–{n(svHigh.co2 / 1000, 1)} t<EquivNote text={`${n(eq.carKm / 1e6, 1)} million car km · yearly footprint of ${n(eq.peopleCo2)} Finns`} source="EEA 0.17 kg/km · Sitra 10 t/person" formula={EQUIV_SOURCES} /></>}
            />
            <Kpi
              tone="water"
              jumpTo="review-footprint" label={`Water saved vs ${baseline.baseline_name.toLowerCase()}`}
              value={n(sv.water / 1000, 0)}
              unit="m³"
              status="ALLOCATED"
              emphasis={isOn("water")}
              grade={performanceGrade(resourceReduction(sv.water, sv.baseWater), "resource", rules)}
              formula={`washed kg × ${baseline.water_l_per_kg} L/kg × ${SCENARIO[scenario].baselineFactor} comparison intensity factor − allocated laundry water. Scenario: ${SCENARIO_LABEL[scenario]}. Range ${n(svLow.water / 1000)}–${n(svHigh.water / 1000)} m³.`}
              sub={<>Range {n(svLow.water / 1000)}–{n(svHigh.water / 1000)} m³<EquivNote text={`yearly water of ${n(eq.residentsWater)} Helsinki residents`} source="HSY · 130 L/person/day" formula={EQUIV_SOURCES} /></>}
            />
            <Kpi
              tone="energy"
              jumpTo="review-footprint" label="Energy saved"
              value={n(sv.energy / 1000, 1)}
              unit="MWh"
              status="ALLOCATED"
              formula={`washed kg × ${baseline.energy_kwh_per_kg} kWh/kg × ${SCENARIO[scenario].baselineFactor} comparison intensity factor − allocated laundry energy. Scenario: ${SCENARIO_LABEL[scenario]}.`}
              grade={performanceGrade(resourceReduction(sv.energy, sv.baseEnergy), "resource", rules)}
              sub={<>Range {n(svLow.energy / 1000, 1)}–{n(svHigh.energy / 1000, 1)} MWh<EquivNote text={`yearly electricity of ${n(eq.apartmentsEnergy)} apartments`} source="Motiva · 2,000 kWh/apartment" formula={EQUIV_SOURCES} /></>}
            />

            <p className="col-span-full mt-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground first:mt-0">Circularity</p>            <Kpi
              tone="circular"
              jumpTo="review-circularity" label="Repairs → replacements postponed"
              value={n(sv.replacementsPostponed)}
              status="ESTIMATE"
              emphasis={isOn("circularity")}
              formula={`${n(t.repairs)} repairs × ${SCENARIO[scenario].repairFactor} postponed replacement per repair (assumption A002). Scenario: ${SCENARIO_LABEL[scenario]}.`}
              sub={`${n(t.repairs)} repairs · ~${n(sv.avoidedProductCo2 / 1000, 1)} tCO₂e new garments avoided`}
            />
            <Kpi
              tone="circular"
              jumpTo="review-circularity" label="New textile production avoided"
              value={n(tx.kg / 1000, 1)}
              unit="t"
              status="ESTIMATE"
              emphasis={isOn("circularity")}
              formula={`${n(t.repairs)} repairs × ${SCENARIO[scenario].repairFactor} replacement factor × ${n(tx.avgWeight, 2)} kg allocation-weighted garment weight = ${n(tx.kg)} kg physical textile. The legacy avoided_product_kg field is manufacturing kgCO₂e, not textile mass. EU comparison: textile kg ÷ ${EU_TEXTILE_WASTE_KG_PER_PERSON}. Estimated production postponed, not measured waste diversion.`}
              sub={<>≈ {n(tx.garments)} replacement equivalents<EquivNote text={`yearly textile waste of ${n(tx.euResidents)} EU residents`} source={`EEA · ${EU_TEXTILE_WASTE_KG_PER_PERSON} kg/person/year`} formula={`Avoided textile kg ÷ ${EU_TEXTILE_WASTE_KG_PER_PERSON} kg textile waste per EU resident per year (EEA estimate, external). An illustrative comparison, not measured waste diverted.`} /></>}
            />

            <ExecutiveExtras customer={customer} sites={sites} t={t} floor={washFloor} part="circular" />
            <p className="col-span-full mt-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground first:mt-0">Service &amp; operations</p>            <Kpi
              tone="service"
              jumpTo="review-sites" label="On-time service cycles"
              value={t.cycles ? n(t.onTimeRate * 100, 1) : "—"}
              grade={performanceGrade(t.cycles ? t.onTimeRate * 100 : null, "delivery", rules)}
              unit="%"
              status="CALCULATED"
              emphasis={isOn("service")}
              formula="(tracked cycles − LATE cycles) ÷ tracked cycles, from RFID scan timestamps."
              sub={`${n(t.late)} late of ${n(t.cycles)} · ${n(t.requests)} service requests`}
            />

            <ExecutiveExtras customer={customer} sites={sites} t={t} floor={washFloor} part="service" />
            <p className="col-span-full mt-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground first:mt-0">Account scale</p>
            <Kpi tone="neutral" jumpTo="review-sites" label="Delivery sites" value={n(t.sites)} status="SYNTHETIC" formula="Count of sites in the customer hierarchy (Sites sheet)." />
            <Kpi tone="neutral" jumpTo="review-sites" label="Active wearers" value={n(t.wearers)} status="SYNTHETIC" formula="Sum of active_wearers in December 2025, all products. May double-count people with several garment types." sub="December 2025" />
            <Kpi tone="neutral" jumpTo="review-hygiene" label="Workwear washed in 2025" value={n(t.washedKg / 1000, 1)} unit="tonnes" status="MEASURED" formula="Σ customer_washed_kg, Jan–Dec 2025 ÷ 1,000 = tonnes. Washed pieces are washing events; a garment may be washed many times. Volume is not a performance grade." sub={`${n(t.washedKg)} kg · ${n(t.washedPieces)} piece-washes`} />

          </div>
          <div id="review-circularity" className="scroll-mt-6"><RepairMix customer={customer} /></div>

          <div id="review-footprint" className="mt-8 grid scroll-mt-6 gap-6 lg:grid-cols-2">
            <div className="rounded-lg border bg-card p-5">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-sm font-medium">Monthly washed kg and repairs</p>
                <StatusTag status="SYNTHETIC" />
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={customer.monthly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" tickFormatter={(m: string) => m.slice(5)} fontSize={11} stroke="var(--muted-foreground)" />
                  <YAxis yAxisId="l" fontSize={11} stroke="var(--muted-foreground)" />
                  <YAxis yAxisId="r" orientation="right" fontSize={11} stroke="var(--muted-foreground)" />
                  <Tooltip />
                  <Line yAxisId="l" dataKey="washedKg" name="Washed kg" stroke="var(--chart-1)" strokeWidth={2} dot={false} />
                  <Line yAxisId="r" dataKey="repairs" name="Repairs" stroke="var(--chart-2)" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
              <p className="text-xs text-muted-foreground">Whole account; not affected by the site filter.</p>
            </div>
            <div className="rounded-lg border bg-card p-5">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-sm font-medium">Footprint: Lindström service vs {baseline.baseline_name.toLowerCase()}</p>
                <StatusTag status="ESTIMATE" />
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart
                  layout="vertical"
                  data={[
                    { k: "Water (m³)", Lindström: t.water / 1000, Comparison: sv.baseWater / 1000 },
                    { k: "Energy (MWh)", Lindström: t.energy / 1000, Comparison: sv.baseEnergy / 1000 },
                    { k: "CO₂e (t)", Lindström: t.emissions / 1000, Comparison: sv.baseCo2 / 1000 },
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis type="number" fontSize={11} stroke="var(--muted-foreground)" />
                  <YAxis type="category" dataKey="k" width={90} fontSize={11} stroke="var(--muted-foreground)" />
                  <Tooltip formatter={(v: number) => n(v, 1)} />
                  <Bar dataKey="Lindström" fill="var(--chart-1)" />
                  <Bar dataKey="Comparison" fill="var(--chart-4)" />
                </BarChart>
              </ResponsiveContainer>
              <p className="text-xs text-muted-foreground">{baseline.assumption_note}</p>
            </div>
          </div>
        </section>

        <div id="review-cost" className="scroll-mt-6"><CfoSection t={t} sv={sv} costs={costs} onAdjust={presenting ? undefined : () => setAssumptionsOpen(true)} /></div>

        {/* Site drill-down */}
        <section id="review-sites" className="print-break scroll-mt-6">
          <SectionTitle eyebrow="03 · Site network" title={`${tableRows.length} sites — where to look`}>
            <p className="max-w-md text-xs text-muted-foreground">
              Click a site to filter the whole review to it. “No scan activity” = allocated garments beyond scanned use plus a
              10% buffer (December).
            </p>
          </SectionTitle>
          <div className="overflow-x-auto rounded-lg border bg-card">
            <table className="w-full text-sm tabular">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  {([
                    ["name", "Site"],
                    ["washedKg", "Washed kg"],
                    ["utilisation", "Garments in use"],
                    ["idle", "No scan activity"],
                    ["lateRate", "Late cycles"],
                    ["repairs", "Repairs"],
                  ] as [SortKey, string][]).map(([k, l]) => (
                    <th key={k} className="px-3 py-2">
                      <Button variant="ghost" size="sm" onClick={() => sortBy(k)} className="h-auto justify-start gap-1 px-0 text-xs hover:bg-transparent hover:text-foreground">
                        {l} <ArrowDownUp className={cn("h-3 w-3", sort.key === k ? "opacity-100" : "opacity-30")} />
                      </Button>
                    </th>
                  ))}
                  <th className="px-3 py-2" title="Proposed composite 0–100: wash compliance 35, garments in use 25, service requests 20, on-time delivery 20.">Site health</th>
                  <th className="px-3 py-2">Signals</th>
                </tr>
              </thead>
              <tbody>
                {tableRows.map(({ s, m }) => (
                  <tr
                    key={s.id}
                    onClick={() => setSelectedSite(selectedSite === s.id ? null : s.id)}
                    className={cn(
                      "cursor-pointer border-t transition-colors hover:bg-muted/60",
                      selectedSite === s.id && "bg-secondary",
                    )}
                  >
                    <td className="px-3 py-2">
                      <div className="font-medium">{shortName(s.name)}</div>
                      <div className="text-xs text-muted-foreground">{s.country} · {s.type}</div>
                    </td>
                    <td className="px-3 py-2">{n(s.washedKg)}</td>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-16 rounded-full bg-muted">
                          <div
                            className={cn("h-1.5 rounded-full", m.utilisation < 0.85 ? "bg-warning" : "bg-success")}
                            style={{ width: `${Math.min(100, m.utilisation * 100)}%` }}
                          />
                        </div>
                        {n(m.utilisation * 100)}%
                      </div>
                      <div className="mt-1"><PerformanceBadge grade={performanceGrade(s.allocated > 0 ? m.utilisation * 100 : null, "scan", rules)} /></div>
                    </td>
                    <td className="px-3 py-2">{n(m.idle)}</td>
                    <td className="px-3 py-2">{s.cycles ? `${n(m.lateRate * 100, 1)}%` : "—"}</td>
                    <td className="px-3 py-2">{n(s.repairs)}</td>
                    <td className="px-3 py-2"><HealthBadge h={health.get(s.id)} /><div className="mt-1"><PerformanceBadge grade={performanceGrade(s.allocated > 0 && s.wearers > 0 && s.cycles > 0 && s.lines.some(l => l.alloc > 0) ? health.get(s.id)?.score ?? null : null, "health", rules)} /></div></td>
                    <td className="px-3 py-2">
                      <div className="flex flex-wrap gap-1">
                        {m.flags.map((f) => (
                          <span key={f} className="rounded bg-warning/20 px-1.5 py-0.5 text-[11px] text-warning-foreground">{f === "Idle garments" ? "No scan activity" : f}</span>
                        ))}
                        {!s.cycles && <span className="rounded bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground">No cycle data</span>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <div id="review-hygiene" className="scroll-mt-6"><HygieneSection sites={sites} industry={customer.industry} shortName={shortName} rules={rules} floor={washFloor} setFloor={setWashFloor} /></div>
        <ValueBridge customer={customer} sites={sites} baseline={baseline} scenario={scenario} />

        {/* Look ahead */}
        <section className="print-break">
          <SectionTitle eyebrow="06 · Look ahead" title="What to discuss and improve next" />
          <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
            <ol className="space-y-3">
              {insights.map((i, idx) => (
                <li
                  key={i.id}
                  className={cn(
                    "rounded-lg border bg-card p-5",
                    idx === 0 && focus.includes(i.focus) && "border-primary ring-1 ring-primary/20",
                  )}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs text-muted-foreground">{String(idx + 1).padStart(2, "0")}</span>
                    <span className="rounded bg-secondary px-1.5 py-0.5 text-[11px] text-secondary-foreground">{FOCUS_LABEL[i.focus]}</span>
                    <StatusTag status={i.status} />
                    <span className="text-[11px] text-muted-foreground">Confidence: {i.confidence}</span>
                  </div>
                  <h3 className="mt-2 font-display text-lg">{i.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{i.evidence}</p>
                  <p className="mt-2 text-sm"><span className="font-medium text-primary">Next step → </span>{i.action}</p>
                </li>
              ))}
            </ol>
            <div className="space-y-4">
              <div className="rounded-lg bg-hero p-5 text-hero-foreground">
                <p className="font-mono text-[11px] uppercase tracking-[0.2em] opacity-90">Steering committee</p>
                <h3 className="mt-1 font-display text-xl">Questions to ask the customer</h3>
                <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm">
                  {questions.map((q) => <li key={q}>{q}</li>)}
                </ol>
              </div>
              <div className="rounded-lg border bg-card p-5">
                <p className="text-sm font-medium">Why this order — {customer.industry}</p>
                <ul className="mt-2 space-y-2 text-xs text-muted-foreground">
                  {industryRules.map((r) => (
                    <li key={r.priority_rank}><strong className="text-foreground">{r.priority_rank}. {r.priority_theme}:</strong> {r.dashboard_emphasis}</li>
                  ))}
                  <li><strong className="text-foreground">Customer's stated topics:</strong> {customer.priorities.join(", ")}</li>
                </ul>
                <p className="mt-3 text-[11px] text-muted-foreground">Rules guide emphasis only; they are not compliance advice.</p>
              </div>
            </div>
          </div>
        </section>


        {/* Data readiness */}
        {<section className="print-break">
          <SectionTitle eyebrow="07 · Trust" title="Data sources, confidence and gaps" />
          <div className="overflow-x-auto rounded-lg border bg-card">
            <table className="w-full text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr><th className="px-3 py-2">Dataset</th><th className="px-3 py-2">Status</th><th className="px-3 py-2">Confidence</th><th className="px-3 py-2">Future Lindström source</th><th className="px-3 py-2">Note</th></tr>
              </thead>
              <tbody>
                {data.dataQuality.map((d) => (
                  <tr key={d.dataset} className="border-t">
                    <td className="px-3 py-2 font-medium">{d.dataset}</td>
                    <td className="px-3 py-2 font-mono text-xs">{d.status}</td>
                    <td className="px-3 py-2">{d.confidence}</td>
                    <td className="px-3 py-2 text-muted-foreground">{FUTURE_SOURCE[d.dataset] ?? "To be agreed"}</td>
                    <td className="px-3 py-2 text-muted-foreground">{d.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            {GAPS.map((g) => (
              <div key={g.t} className="rounded-lg border border-dashed bg-card p-4">
                <p className="text-sm font-medium">{g.t}</p>
                <p className="mt-1 text-xs text-muted-foreground">{g.d}</p>
              </div>
            ))}
          </div>
        </section>}
      </main>
      <footer className="border-t px-6 py-8 text-center text-xs text-muted-foreground">
        Hackathon prototype · Synthetic data · Not an audited sustainability report
        <a href="https://lindstromgroup.com/what-we-do/" target="_blank" rel="noreferrer" className="mt-2 block">Lindström Group · Operating in 24 countries</a>
      </footer>
    </div>
  );
}

const FUTURE_SOURCE: Record<string, string> = {
  Customers: "CRM / customer master data",
  Service_Activity: "eLindström & Tableau service reports",
  Service_Cycles: "RFID scan events",
  Repairs: "Tableau repair report (monthly by delivery customer, product, laundry)",
  Laundry_Resources: "Laundry utility meters / WWS calculator",
  Waste_Circularity: "Laundry waste-handler reports",
  Customer_Impacts: "Calculated in this tool from the above",
};

const GAPS = [
  { t: "Customer hierarchy", d: "Real parent account → delivery site mapping is needed to roll up large customers reliably." },
  { t: "Unique wearers", d: "Wearers are counted per garment type; a person ID-free headcount by site would avoid double counting." },
  { t: "Approved factors", d: "Product footprints and baseline intensities are illustrative and must be replaced with approved values." },
];

function HealthBadge({ h }: { h?: { score: number; parts: { wash: number; rightsizing: number; requests: number; delivery: number } } | undefined }) {
  if (!h) return <span>—</span>;
  const cls = "bg-muted text-foreground border-border";
  const p = h.parts;
  return (
    <span
      className={cn("inline-flex min-w-10 justify-center rounded-md border px-2 py-0.5 font-mono text-xs font-medium", cls)}
      title={`Proposed score, not Lindström policy.\nWash ${n((p.wash ?? 0) * HEALTH_WEIGHTS.wash, 1)}/${HEALTH_WEIGHTS.wash} · In use ${n((p.rightsizing ?? 0) * HEALTH_WEIGHTS.rightsizing, 1)}/${HEALTH_WEIGHTS.rightsizing} · Requests ${n((p.requests ?? 0) * HEALTH_WEIGHTS.requests, 1)}/${HEALTH_WEIGHTS.requests} · On time ${n((p.delivery ?? 0) * HEALTH_WEIGHTS.delivery, 1)}/${HEALTH_WEIGHTS.delivery}`}
    >
      {h.score}
    </span>
  );
}

function RepairMix({ customer }: { customer: Customer }) {
  const mix = repairMix(customer);
  const total = mix.reduce((a, r) => a + r.count, 0);
  return (
    <div className={cn("mt-8 border-y py-6", toneFill("circular"))}>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm font-medium">What gets repaired — {n(total)} repairs kept garments in use</p>
        <StatusTag status="SYNTHETIC" />
      </div>
      <div className="flex h-3 overflow-hidden rounded-full bg-card">
        {mix.map((r, i) => (
          <div key={r.type} className="h-full bg-pillar-circular" style={{ width: `${r.share * 100}%`, opacity: 1 - i * 0.15 }} title={`${r.type}: ${n(r.count)}`} />
        ))}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 text-xs md:grid-cols-5">
        {mix.map((r) => (
          <div key={r.type} className="rounded-md bg-card/70 px-2 py-1.5">
            <p className="truncate text-muted-foreground capitalize">{r.type.toLowerCase()}</p>
            <p className="font-mono tabular text-foreground">{n(r.count)} · {n(r.share * 100)}%</p>
          </div>
        ))}
      </div>
      <p className="mt-2 text-xs text-muted-foreground">Small fixes (buttons, zips, seams) that would otherwise mean a whole garment is thrown away and rebought.</p>
    </div>
  );
}

function Control({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className={cn("flex flex-col gap-1", label === "Customer" && "review-customer-control")}>
      <span className="text-[11px] uppercase tracking-wide opacity-70">{label}</span>
      {children}
    </label>
  );
}

function MethodologyDialog({ rules, washFloor, customer, sites, baseline, override, costs, scenario }: {
  rules: PerformanceRules; washFloor: number; customer: Customer; sites: Customer["sites"];
  baseline: ReturnType<typeof applyOverride>; override: BaselineOverride; costs: CostInputs; scenario: Scenario;
}) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="text-muted-foreground">
          Methodology
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] w-[calc(100%-2rem)] max-w-3xl min-w-0 overflow-y-auto">
        <DialogHeader className="min-w-0 pr-5"><DialogTitle className="break-words font-display text-2xl">How the numbers are made</DialogTitle></DialogHeader>
        <div className="min-w-0 space-y-4 text-sm">
          <div className="rounded-lg border bg-secondary/40 p-3">
            <p className="mb-2 font-medium">How to read the dashboard</p>
            <ToneLegend />
          </div>
          <MethodologyDetails customer={customer} sites={sites} baseline={baseline} override={override} costs={costs} scenario={scenario} washFloor={washFloor} />
          <BenchmarkSources />
          <p className="text-xs text-muted-foreground">Current proposed wash floor: {n(washFloor, 1)} washed pieces per allocated garment per month. Change it in Wash compliance; it also updates site health.</p>
          <PerformanceCriteria rules={rules} />
          <PeerEmissions />
          <p>
            <strong>Savings</strong> = washed kg × comparison intensity − Lindström footprint allocated to the customer
            by its share of each laundry's washed kg. <strong>Sensitivity scenario</strong>: Standard uses the selected baseline unchanged; Conservative lowers comparison intensities by 15% and counts half a postponed replacement per repair; Aggressive raises intensities by 15% and, like Standard, counts one postponed replacement per repair. Lindström’s allocated footprint is unchanged. These are proposed sensitivity assumptions, not Lindström policy; −15% / +15% changes the comparison intensity, not the resulting savings percentage.
          </p>
          <div>
            <p className="mb-2 font-medium">Original data-pack comparison baselines — before customer edits</p>
            <table className="w-full text-xs">
              <thead className="text-left text-muted-foreground"><tr><th>Baseline</th><th>L/kg</th><th>kWh/kg</th><th>Process + delivery kgCO₂e/kg</th></tr></thead>
              <tbody>
                {data.baselines.map((b) => (
                  <tr key={b.baseline_id} className="border-t"><td className="py-1">{b.baseline_name}</td><td>{b.water_l_per_kg}</td><td>{b.energy_kwh_per_kg}</td><td>{b.process_kgco2e_per_kg + b.delivery_kgco2e_per_kg}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
          <div>
            <p className="mb-2 font-medium">Original data-pack assumption registry</p>
            <ul className="space-y-2">
              {data.assumptions.map((a) => (
                <li key={a.assumption_id} className="rounded border p-2">
                  <span className="font-mono text-xs text-muted-foreground">{a.assumption_id}</span> <strong>{a.assumption}:</strong> {a.value_or_rule}
                  <div className="text-xs text-muted-foreground">{a.rationale} · Confidence {a.confidence} · {a.treatment}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

const BENCHMARKS = [
  { what: "Water", ref: "Helsinki resident household water", value: "130 L/day ≈ 47.5 m³/year", source: "HSY (Helsinki Region Environmental Services)", math: "water saved m³ ÷ 47.45" },
  { what: "Emissions", ref: "Average passenger car", value: "0.17 kgCO₂e/km", source: "EEA, CO₂ from new passenger cars (fleet order of magnitude)", math: "kgCO₂e avoided ÷ 0.17" },
  { what: "Emissions", ref: "Finnish per-capita footprint", value: "10 tCO₂e/person/year", source: "Sitra lifestyle footprint study (order of magnitude)", math: "tCO₂e avoided ÷ 10" },
  { what: "Energy", ref: "Typical apartment electricity", value: "2,000 kWh/year", source: "Motiva household electricity guidance", math: "kWh saved ÷ 2,000" },
  { what: "Textile", ref: "Textile waste per EU resident", value: "16 kg/person/year", source: "EEA, Textiles in Europe's circular economy", math: "avoided kg ÷ 16" },
  { what: "Garments", ref: "Average garment weight", value: "From customer allocation", source: "Data pack product weights × December allocation", math: "avoided kg ÷ avg kg/garment" },
];

const PEERS = [
  { name: "Lindström Group", v: 0.28 },
  { name: "Cintas", v: 0.2 },
  { name: "Salesianer", v: 0.31 },
  { name: "Johnson Service Group", v: 0.38 },
  { name: "Elis", v: 0.4 },
];

function PeerEmissions() {
  const peers = PEERS.filter((p) => p.name !== "Lindström Group");
  const avg = peers.reduce((a, p) => a + p.v, 0) / peers.length;
  const max = Math.max(...PEERS.map((p) => p.v));
  return (
    <div className="rounded-lg border p-3">
      <p className="font-medium">Company emissions intensity vs rental peers</p>
      <p className="mb-2 text-xs text-muted-foreground">kgCO₂e per € turnover, company level (figures shared by the Lindström mentor). Unweighted average of the four listed peers: {avg.toFixed(2)}; (1 − 0.28 ÷ peer average) × 100 gives about {Math.round((1 - 0.28 / avg) * 100)}% lower. Lindström’s separate stated industry-average claim is 13% lower; its comparison set is not established here. Reporting years, emissions boundaries and comparability are unverified. Context only, not a customer saving or independently verified competitor ranking.</p>
      <div className="space-y-1">
        {PEERS.map((p) => (
          <div key={p.name} className="flex items-center gap-2 text-xs">
            <span className={`w-24 shrink-0 sm:w-40 ${p.name === "Lindström Group" ? "font-semibold text-primary" : ""}`}>{p.name}</span>
            <span className="h-2 rounded bg-pillar-carbon" style={{ width: `${(p.v / max) * 60}%`, opacity: p.name === "Lindström Group" ? 1 : 0.45 }} />
            <span className="tabular">{p.v.toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function BenchmarkSources() {
  return (
    <div>
      <p className="mb-1 font-medium">Public sources & human-scale benchmarks</p>
      <p className="mb-2 text-xs text-muted-foreground">Rounded public reference values, used only to make figures tangible. They are illustrative comparisons, not extra savings; replace with Lindström-approved references if preferred.</p>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="text-left text-muted-foreground"><tr><th className="pr-2">Topic</th><th className="pr-2">Reference</th><th className="pr-2">Value</th><th className="pr-2">Source</th><th>Math</th></tr></thead>
          <tbody>
            {BENCHMARKS.map((b) => (
              <tr key={b.ref} className="border-t align-top"><td className="py-1 pr-2 font-medium">{b.what}</td><td className="pr-2">{b.ref}</td><td className="pr-2 tabular">{b.value}</td><td className="pr-2">{b.source}</td><td className="font-mono">{b.math}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
