import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  data, SCENARIO, SCENARIO_LABEL, HIGH_RISK_MONTHS, UNSEEN_FLAG,
  UTILISATION_TARGET, RIGHTSIZE_BUFFER, LATE_RATE_FLAG, HEALTH_WEIGHTS, HEALTH_LATE_ZERO,
  type Baseline, type BaselineOverride, type CostInputs, type Customer, type Scenario, type Site,
} from "@/lib/review";
import { n } from "./parts";

type Props = {
  customer: Customer;
  sites: Site[];
  baseline: Baseline;
  override: BaselineOverride;
  costs: CostInputs;
  scenario: Scenario;
  washFloor: number;
};

function Definition({ title, children }: { title: string; children: React.ReactNode }) {
  return <div><dt className="font-medium text-foreground">{title}</dt><dd className="mt-1 leading-relaxed text-muted-foreground">{children}</dd></div>;
}

export function MethodologyDetails({ customer, sites, baseline, override, costs, scenario, washFloor }: Props) {
  const months = customer.monthly.map(m => m.month).sort();
  const uploaded = customer.id.startsWith("UPLOAD-");
  const factor = SCENARIO[scenario];
  const priceRows = [
    ["Water", `${n(costs.waterEurPerM3, 2)} €/m³`],
    ["Energy", `${n(costs.energyEurPerKwh, 3)} €/kWh`],
    ["Shadow carbon", `${n(costs.carbonEurPerT, 2)} €/tCO₂e`],
    ["Garment purchase price", `${n(costs.garmentEur, 2)} €/garment`],
    ["Extra owned-fleet buffer", `${n(costs.ownedFleetExtra * 100, 1)}%`],
    ["Annual Lindström fee", costs.lindstromFeeEur > 0 ? `€${n(costs.lindstromFeeEur, 2)}` : "Not entered"],
    ["Alternative annual TCO", costs.alternativeAnnualEur === undefined ? "Not entered" : `€${n(costs.alternativeAnnualEur, 2)}`],
  ];
  return <>
    <div className="border-l-2 border-primary bg-muted/40 p-3 text-xs leading-relaxed">
      <p className="font-medium">Current review — {customer.name}</p>
      <p className="mt-1">{sites.length} of {customer.sites.length} sites selected · data period {months[0] ?? "unknown"} to {months.at(-1) ?? "unknown"} ({months.length} recorded months).</p>
      <p>{baseline.baseline_name} · {SCENARIO_LABEL[scenario]} · wash floor {n(washFloor, 1)} / garment / month.</p>
      <p className="mt-1 text-muted-foreground">{uploaded ? "Customer-uploaded activity; resource and avoided-production figures use data-pack estimates. Year-labelled figures cover the uploaded period only; they are not annualised." : "Fictional hackathon account. Measured describes a field’s intended origin, not independently verified real customer evidence."}</p>
    </div>
    <Accordion type="multiple" className="w-full">
      <AccordionItem value="scope">
        <AccordionTrigger>Reporting scope, quantities & data status</AccordionTrigger>
        <AccordionContent><dl className="space-y-3 text-xs">
          <Definition title="What “value delivered” means">Recorded service activity and estimated resource differences against a selected alternative, for the available reporting period. It is not audited financial savings, a certified sustainability disclosure or a causal assessment.</Definition>
          <Definition title="Sites and wearers">Sites = selected delivery locations, not Lindström’s company footprint. Wearers, allocated garments and scanned garments use the December snapshot in demo data, or the latest month in an upload. Wearers are summed by product and may count the same person more than once.</Definition>
          <Definition title="Washed volume, repairs and requests">Tonnes = sum of washed kg ÷ 1,000. Piece-washes count washing events, not unique garments. Repairs and service requests are event totals over the recorded period; requests per 1,000 wearers = requests ÷ snapshot wearers × 1,000. These are volumes, not grades or unique people.</Definition>
          <Definition title="Filter boundaries">Summary activity, footprint, hygiene and value-bridge figures use selected sites. Monthly trends and repair-type mix remain whole-account. Site-table health compares all account sites; the benchmark card compares selected sites. Seasonal peak, trough and capital estimates use whole-account allocation and wearers, regardless of site filters. Entered annual fees, alternative costs and hidden costs remain whole-account and are not automatically prorated.</Definition>
          <Definition title="Status and confidence">MEASURED = source activity field; CALCULATED = arithmetic from source fields; ALLOCATED = laundry totals attributed by washed-kg share; ESTIMATE = assumptions or comparisons; SYNTHETIC = fictional prototype input. A calculated or measured label does not remove synthetic provenance. Confidence describes source quality and assumption dependence, not a statistical confidence interval.</Definition>
          <Definition title="Precision and missing evidence">Calculations use unrounded values; displayed figures are rounded. Missing input must not be treated as confirmed zero. Some underlying ratios use zero when their denominator is zero; absence of evidence is not good performance. Grades require the evidence checks described below, but an ungraded score or a Low risk label is not proof of compliance.</Definition>
        </dl></AccordionContent>
      </AccordionItem>
      <AccordionItem value="resources">
        <AccordionTrigger>Resource footprint, savings & sensitivity scenarios</AccordionTrigger>
        <AccordionContent><dl className="space-y-3 text-xs">
          <Definition title="Footprint allocation">Demo customer water, energy, process emissions, delivery emissions and waste are pre-allocated from laundry totals using the customer’s share of washed kg. Process + delivery emissions define the service footprint; new-garment production is separate. No garment-level meter reading or verified customer Scope 3 claim is implied.</Definition>
          <Definition title="Savings equations">Comparison water (L) = washed kg × water L/kg × scenario factor; energy (kWh) = washed kg × energy kWh/kg × factor; emissions (kgCO₂e) = washed kg × (process + delivery kgCO₂e/kg) × factor. Savings = comparison − allocated Lindström footprint. Divide L by 1,000 for m³, kWh by 1,000 for MWh, and kgCO₂e by 1,000 for tonnes. Negative savings mean higher use than the comparison.</Definition>
          <Definition title="Current effective baseline">
            Water {n(baseline.water_l_per_kg, 2)} L/kg · energy {n(baseline.energy_kwh_per_kg, 3)} kWh/kg · process {n(baseline.process_kgco2e_per_kg, 3)} + delivery {n(baseline.delivery_kgco2e_per_kg, 3)} kgCO₂e/kg, before scenario scaling.
            {override.source ? ` Customer baseline source: ${override.source}.` : " No customer baseline source supplied."} {baseline.assumption_note}
          </Definition>
          <Definition title="Scenarios, not quality levels">{SCENARIO_LABEL.base}: intensity × {SCENARIO.base.baselineFactor}, repair benefit × {SCENARIO.base.repairFactor}; {SCENARIO_LABEL.low}: intensity × {SCENARIO.low.baselineFactor}, repair benefit × {SCENARIO.low.repairFactor}; {SCENARIO_LABEL.high}: intensity × {SCENARIO.high.baselineFactor}, repair benefit × {SCENARIO.high.repairFactor}. Current factors: ×{factor.baselineFactor} and ×{factor.repairFactor}. Lindström footprint is unchanged. Displayed ranges are the Conservative–Aggressive sensitivity endpoints, not probabilities or confidence intervals.</Definition>
          <Definition title="Savings grades">Resource reduction (%) = savings ÷ comparison footprint × 100 for each resource. The grade evaluates this scenario estimate, not service quality. A zero comparison denominator is Not assessed.</Definition>
        </dl></AccordionContent>
      </AccordionItem>
      <AccordionItem value="hygiene">
        <AccordionTrigger>Wash compliance, “overdue”, no scans & risk levels</AccordionTrigger>
        <AccordionContent><dl className="space-y-3 text-xs">
          <Definition title="Line-month and wash floor">One product at one site in one month is one line-month. Washes per garment = washed pieces ÷ allocated pieces. Under floor (“overdue” in this prototype) means strictly below {n(washFloor, 1)}; equality meets the floor. This is an aggregate rhythm flag, not a garment-specific overdue date or proof that a person wore unwashed clothing.</Definition>
          <Definition title="Compliance and weighted wash rhythm">Compliance (%) = line-months meeting the floor ÷ all recorded line-months × 100; each row has equal weight. Overall wash rhythm = sum of washed pieces ÷ sum of monthly allocations, so larger allocations carry more weight. Current calculation includes zero-allocation rows and treats their wash rate as zero; incomplete rows need validation before an audit interpretation.</Definition>
          <Definition title="High, Medium and Low — proposed risk rules">High: at least {HIGH_RISK_MONTHS} critical line-months under floor across Food Industry Coat (P1004) and Healthcare Tunic (P1005), combined. These need not be consecutive or on a single product. Otherwise Medium: any critical line-month under, more than 25% of all line-months under, or more than {n(UNSEEN_FLAG * 100)}% not seen. Otherwise Low. Exactly 25% under or exactly {n(UNSEEN_FLAG * 100)}% not seen does not by itself trigger Medium. No critical products means a dash, not zero breaches. General workwear cannot trigger High in this rule.</Definition>
          <Definition title="Not seen versus the rightsizing estimate">Monthly not-seen share = 1 − sum of scans ÷ sum of allocations; its performance badge grades the complementary scanned share. This is not proof of idle or lost stock. The site table’s “No scan activity” count is a different, buffered rightsizing estimate: max(0, round(allocated − scanned × {RIGHTSIZE_BUFFER})), using the snapshot. The value bridge also shows the unbuffered gap max(0, allocated − scanned). Do not treat these different counts as interchangeable.</Definition>
          <Definition title="Site-table signals and actual lateness">Allocation-review signal: scanned ÷ allocated &lt; {n(UTILISATION_TARGET * 100)}%. Late-cycle signal: late ÷ tracked cycles &gt; {n(LATE_RATE_FLAG * 100, 1)}%. On-time (%) = (tracked − late) ÷ tracked × 100. Late uses the source cycle classification; no agreed delivery-window duration is encoded here. The RFID cycle sample and median visit gaps do not set hygiene risk flags.</Definition>
          <Definition title="Role-specific agreement">The wash floor can be selected in Wash compliance. Risk thresholds and critical product mapping are prototype rules, not Lindström policy; they are not currently editable in the assumptions dialog. Agree role-specific wash rhythms, actual delivery SLAs and audit criteria with Lindström before using these labels operationally.</Definition>
        </dl></AccordionContent>
      </AccordionItem>
      <AccordionItem value="health">
        <AccordionTrigger>Site health & benchmark ranking</AccordionTrigger>
        <AccordionContent><dl className="space-y-3 text-xs">
          <Definition title="Proposed composite, rounded to a whole point">{HEALTH_WEIGHTS.wash} × compliant share + {HEALTH_WEIGHTS.rightsizing} × min(1, scanned share ÷ {UTILISATION_TARGET}) + {HEALTH_WEIGHTS.requests} × (1 − requests per 1,000 wearers ÷ highest full-account site rate) + {HEALTH_WEIGHTS.delivery} × max(0, 1 − late rate ÷ {HEALTH_LATE_ZERO}). If all request rates are zero, that part earns full weight. With no cycles the underlying delivery part also defaults to full weight, so a numeric score alone is not evidence of delivery quality.</Definition>
          <Definition title="Score versus performance grade">The grade is withheld without positive allocation, wearers, tracked cycles and at least one positive-allocation line. The raw score may still appear. Adjusting grade thresholds changes labels, not score weights, the fixed 85% scan target or the 5% late-rate zero point. Changing the wash floor changes compliance and the health score.</Definition>
          <Definition title="Best, improvement site and gap">Sites are ranked by the proposed score; gap = highest − lowest score. The card requires two or more selected sites, uses the full-account request-rate reference so a site’s score does not change merely because the selection changes. The best and weakest selected sites can still change. Missing-data sites are not automatically removed from ranking; review their evidence before treating them as benchmarks. Ties retain source order; “best” does not certify absolute service quality.</Definition>
        </dl></AccordionContent>
      </AccordionItem>
      <AccordionItem value="circularity">
        <AccordionTrigger>Circularity, repair value & seasonal workforce</AccordionTrigger>
        <AccordionContent><dl className="space-y-3 text-xs">
          <Definition title="Repairs and replacements postponed">Postponed replacements = repair events × selected scenario repair factor. Production emissions avoided = source avoided-product CO₂e × repair factor. The one-repair/one-replacement link is an assumption, not evidence of an avoided purchase; repeated repairs may affect one garment. Repairs per 100 garments = annual repair events ÷ snapshot allocated garments × 100. It can exceed 100 and is not lifespan extension or a unique share of garments repaired.</Definition>
          <Definition title="Avoided textile production and repair mix">Avoided textile tonnes = postponed replacements × allocation-weighted garment weight ÷ 1,000, scaled by the repair scenario. The legacy avoidedProductKg field is manufacturing emissions in kgCO₂e, not physical fabric mass. Garment equivalents equal postponed replacements; neither is a count of unique garments. Repair-type share = events of that type ÷ all typed repair events. Typed repair mix remains whole-account and is unavailable in the current upload template. Neither textile equivalents nor repair counts prove measured waste diversion or verified CSRD reporting.</Definition>
          <Definition title="Garment cost and weight">Average price or weight = sum of product snapshot allocation × product price or weight ÷ sum of recognised-product allocation. Demo snapshot is December; uploaded snapshot is the latest month. Prices and product footprints are synthetic. Unknown product IDs are excluded from these weighted averages; no customer-specific price or weight can be inferred for them.</Definition>
          <Definition title="Seasonal workforce swing and capital estimate">Swing = highest − lowest whole-account monthly wearer count; swing share = swing ÷ peak × 100. Garments per wearer = whole-account snapshot allocation ÷ whole-account snapshot wearers. Peak-stock garments = round(swing × garments per wearer); capital = unrounded swing × garments per wearer × allocation-weighted garment price. This is potential capital exposure, not cash proven saved, and is separate from the extra-fleet buffer estimate. Wearer totals may contain duplicate people; short uploads do not establish a full annual seasonality pattern.</Definition>
          <Definition title="Executive value bridge">Repair purchase value = postponed replacements × allocation-weighted synthetic garment price. Rightsizing capital = sum of site buffered rightsizing counts × that price. Washes per wearer = period piece-washes ÷ snapshot wearers, not washes per unique person or per garment. These translations do not increase TCO savings or ROI.</Definition>
        </dl></AccordionContent>
      </AccordionItem>
      <AccordionItem value="money">
        <AccordionTrigger>Annual TCO, ROI, benefit shares & invisible costs</AccordionTrigger>
        <AccordionContent><dl className="space-y-3 text-xs">
          <Definition title="Current money assumptions"><ul className="mt-1 space-y-1">{priceRows.map(([label, value]) => <li key={label}>{label}: <span className="font-mono">{value}</span></li>)}</ul>These are editable working values, not verified tariffs or Lindström internal costs. Default utility, carbon and buffer values are illustrative; the default garment price is data-pack weighted. Carbon is a non-cash shadow valuation, not guaranteed EU ETS revenue or expense.</Definition>
          <Definition title="Avoided-cost equations">Water = max(0, water saved L ÷ 1,000) × €/m³; energy = max(0, energy saved kWh) × €/kWh; carbon = max(0, emissions avoided kg ÷ 1,000) × €/t; replacements = repairs × scenario repair factor × garment price. Negative physical savings remain visible, but this benefit-only money view floors their monetary contribution at zero rather than showing an extra cost.</Definition>
          <Definition title="Annual estimate versus capital">Annual cash benefit estimate = water + energy + postponed replacements, before any fee. Postponed purchases are not confirmed annual cash savings. Extra-fleet capital = round(allocated × extra-owned-fleet share) × garment price; upfront, not recurring annual cost. Shadow carbon and extra-fleet capital are excluded from annual benefit and category shares. Repair and fleet estimates can overlap; do not add them as independent confirmed savings.</Definition>
          <Definition title="Full annual TCO and ROI">Enter the alternative total and customer-paid Lindström fee separately for the same sites, period and service scope. Annual difference = alternative TCO − fee. Net ROI (%) = difference ÷ fee × 100; cost reduction (%) = difference ÷ alternative TCO × 100. A negative difference means Lindström is more expensive in that comparison. A blank alternative is unknown; zero is allowed. A zero or missing fee is treated as not entered; a zero alternative cannot produce a cost-reduction percentage. No internal Lindström cost or category fee split is available.</Definition>
          <Definition title="Benefit shares">Each water, energy or replacement estimate ÷ annual cash-benefit subtotal × 100. These shares describe the subtotal’s composition, not savings percentages against alternative category costs. With a zero subtotal shares are unavailable. Fee-by-category remains “Not itemised” until contract evidence exists.</Definition>
          <Definition title="Invisible customer costs">Alternative administration = entered annual hours × loaded labour €/hour. Customer administration with Lindström uses separate hours at the same rate; difference = alternative − service administration and may be negative. Alternative loss = lost garments/year × garment price. Audit preparation = distinct annual hours × loaded rate; not fines avoided. Partial subtotal = entered alternative administration + losses + audit preparation only; blanks are unknown, zero means none. Service administration is not subtracted from that subtotal. These account-wide diagnostics never automatically increase TCO, benefit shares or ROI; avoid duplicate hours and costs already in the annual alternative.</Definition>
          <Definition title="Customer cost evidence">{costs.hiddenCostSource || "No source supplied."} No labour saving, RFID loss reduction, audit saving or risk-liability amount is presumed. Upfront buffer stock shown under invisible costs uses whole-account allocation even when sites are filtered.</Definition>
        </dl></AccordionContent>
      </AccordionItem>
      <AccordionItem value="assumptions">
        <AccordionTrigger>Customer adjustments, uploads, AI & exports</AccordionTrigger>
        <AccordionContent><dl className="space-y-3 text-xs">
          <Definition title="What can be adjusted">Adjust assumptions accepts customer water, energy and process-emission intensities, source notes, prices, extra fleet share, annual costs, hidden-cost inputs and grade boundaries. Only finite non-negative baseline overrides replace defaults; blank restores the selected baseline field. Delivery-emission intensity stays from the selected baseline. Saved overrides also apply if a different comparison is selected. The default registry below records data-pack assumptions, not a list of all current edits.</Definition>
          <Definition title="Saving and resetting">Inputs recalculate the review while editing; Save changes retains them for the current browser session, whereas Cancel or dismissing the dialog restores the opening values. Clear all restores baseline, cost and grade defaults, but not the wash floor or selected scenario. Switching customers clears customer adjustments and resets grades and wash floor. Reloading clears session adjustments and uploaded accounts; nothing is saved to a shared customer record.</Definition>
          <Definition title="Upload structure and estimates">CSV/Excel template: one customer, one row per site × product × month. Activity is summed over uploaded months; allocation, wearers and scanned stock use the latest month. Supply non-negative numbers and late cycles no greater than tracked cycles. Avoid duplicate rows and repeated site totals across products: they are summed, not deduplicated. Water, energy, process/delivery CO₂e and waste = uploaded washed kg × pack-wide per-kg average; manufacturing emissions postponed = uploaded repairs × pack-wide manufacturing kgCO₂e per repair; physical textile uses postponed replacements × recognised-product average garment weight. These are proxies, not customer meters or approved factors. The template has no repair-type detail or RFID cycle-gap evidence.</Definition>
          <Definition title="Meeting focus and recommendations">Industry priorities set the initial order; Meeting focus changes the order and highlighted topics, not calculations. All pillars restores industry emphasis; Circularity prioritises repair and textile topics and moves to that evidence. Suggested actions are deterministic interpretations for account-manager review, not audit or legal advice.</Definition>
          <Definition title="AI briefing boundaries">The model receives the current customer name, audience description and a restricted list of activity, footprint, scenario, repair and proposed hygiene facts with status labels, not the raw customer file. The fact list includes the current wash floor, scenario-adjusted circularity, annual TCO, fee, difference and ROI when available, with account-wide cost scope explicit. It does not include hidden costs or edited grading criteria. Units follow the dashboard. Changing facts invalidates the cached briefing; demo costs remain synthetic, not real contract prices. The output is a draft, not a new data source; verify every claim before presenting.</Definition>
          <Definition title="PDF and Excel scope">PDF uses the browser’s printed review; Methodology is a separate dialog and is not an automatic PDF annex. Excel includes summary, selected sites and cost comparison, not a complete raw upload or this full explanation. Excel site risk and health use the current wash floor and the same full-account health reference as the review; the summary includes the scenario-adjusted physical textile estimate. Entered costs remain account-wide even in a site-filtered export.</Definition>
        </dl></AccordionContent>
      </AccordionItem>
      <AccordionItem value="sources">
        <AccordionTrigger>Data sources, confidence & remaining gaps</AccordionTrigger>
        <AccordionContent>
          <div className="overflow-x-auto"><table className="w-full min-w-[500px] text-left text-xs"><thead><tr><th className="py-2 pr-3">Dataset</th><th className="pr-3">Fields / status</th><th>Confidence / limitations</th></tr></thead><tbody>{data.dataQuality.map(d => <tr key={d.dataset} className="border-t align-top"><th className="py-2 pr-3 font-medium">{d.dataset}</th><td className="py-2 pr-3">{d.fields}<br />{d.status}</td><td className="py-2">{d.confidence} · {d.note}</td></tr>)}</tbody></table></div>
          <p className="mt-3 text-xs leading-relaxed text-muted-foreground">Production evidence still needs approved parent-account/site mapping, person-ID-free unique headcounts, approved product footprints and prices, customer-specific comparison intensities, agreed role-specific wash rules, delivery SLAs and comparable annual cost evidence. Waste-allocation and mixed-waste baseline entries in the original registry are background assumptions; they do not establish a displayed verified waste-treatment saving. No personal RFID identifiers are available in the demo.</p>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  </>;
}