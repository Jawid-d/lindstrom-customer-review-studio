import { useState } from "react";
import { Upload, CheckCircle2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { buildCustomer, type ImportResult, type ImportRow } from "@/lib/import";
import { templateCsv, type Customer } from "@/lib/review";

const INDUSTRIES = ["Food & Beverage", "Manufacturing", "Healthcare"];

async function readRows(file: File): Promise<ImportRow[]> {
  const XLSX = await import("xlsx");
  const wb = XLSX.read(await file.arrayBuffer(), { type: "array", raw: /\.csv$/i.test(file.name), cellDates: true });
  const sheet = wb.Sheets[wb.SheetNames[0]!]!;
  return XLSX.utils.sheet_to_json<ImportRow>(sheet, { defval: "", raw: true });
}

export function DataUpload({ onImport }: { onImport: (c: Customer) => void }) {
  const [open, setOpen] = useState(false);
  const [industry, setIndustry] = useState(INDUSTRIES[0]!);
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [busy, setBusy] = useState(false);

  async function check(f: File | null, ind = industry) {
    setFile(f);
    setResult(null);
    if (!f) return;
    setBusy(true);
    try {
      setResult(buildCustomer(await readRows(f), ind));
    } catch {
      setResult({ ok: false, errors: ["The file could not be read. Upload a .csv or .xlsx based on the template."] });
    } finally {
      setBusy(false);
    }
  }

  function downloadTemplate() {
    const url = URL.createObjectURL(new Blob([templateCsv()], { type: "text/csv;charset=utf-8" }));
    const a = Object.assign(document.createElement("a"), { href: url, download: "lindstrom-review-import-template.csv" });
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setFile(null); setResult(null); } }}>
      <DialogTrigger asChild>
        <Button variant="secondary" size="sm"><Upload className="mr-1 h-4 w-4" /> Upload customer data</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Upload customer data</DialogTitle>
          <DialogDescription>
            Fill in the import template (one row per site, product and month) and upload it as .csv or .xlsx. The whole review is then built from that company's own figures.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 text-sm">
          <Button variant="link" className="h-auto p-0" onClick={downloadTemplate}>Download the import template (.csv)</Button>
          <label className="block space-y-1">
            <span className="text-xs font-medium text-muted-foreground">Industry (sets the review focus and priorities)</span>
            <Select value={industry} onValueChange={(v) => { setIndustry(v); if (file) void check(file, v); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{INDUSTRIES.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
            </Select>
          </label>
          <label className="block space-y-1">
            <span className="text-xs font-medium text-muted-foreground">Data file</span>
            <input
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={(e) => void check(e.target.files?.[0] ?? null)}
              className="block w-full rounded-md border bg-card p-2 text-sm file:mr-3 file:rounded file:border-0 file:bg-muted file:px-3 file:py-1"
            />
          </label>

          {busy && <p className="text-muted-foreground">Checking the file…</p>}
          {result && !result.ok && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3">
              <p className="flex items-center gap-2 font-medium text-destructive"><AlertTriangle className="h-4 w-4" /> Please fix the file and upload again</p>
              <ul className="mt-2 list-disc space-y-0.5 pl-5 text-xs">{result.errors.map((e) => <li key={e}>{e}</li>)}</ul>
            </div>
          )}
          {result?.ok && (
            <div className="rounded-md border bg-muted/50 p-3">
              <p className="flex items-center gap-2 font-medium"><CheckCircle2 className="h-4 w-4 text-primary" /> {result.customer.name} is ready</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {result.rows} rows · {result.customer.sites.length} sites · {new Set(result.customer.sites.map((s) => s.country)).size} countries · {result.customer.monthly.length} months
              </p>
              <ul className="mt-2 list-disc space-y-0.5 pl-5 text-xs text-muted-foreground">{result.warnings.map((w) => <li key={w}>{w}</li>)}</ul>
            </div>
          )}
          <p className="text-xs text-muted-foreground">The file stays in this browser and is not saved; reload the page to remove it.</p>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          <Button disabled={!result?.ok} onClick={() => { if (result?.ok) { onImport(result.customer); setOpen(false); } }}>Open review</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
