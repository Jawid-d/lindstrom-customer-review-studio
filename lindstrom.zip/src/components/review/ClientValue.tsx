import { useEffect, useRef } from "react";
import { RotateCcw, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  EQUIV,
  cfoValue,
  hiddenCosts,
  type Baseline,
  type BaselineOverride,
  type CostInputs,
  type PerformanceRules,
} from "@/lib/review";
import { PerformanceCriteria } from "./Performance";
import { Kpi, SectionTitle, StatusTag, n } from "./parts";

function NumField({
  label,
  value,
  onChange,
  step = 0.01,
  placeholder,
  hint,
}: {
  label: string;
  value: number | undefined;
  onChange: (v: number | undefined) => void;
  step?: number;
  placeholder?: string;
  hint?: string;
}) {
  return (
    <label className="block text-xs">
      <span className="font-medium text-foreground">{label}</span>
      <input
        aria-label={label}
        type="number"
        min={0}
        step={step}
        value={value ?? ""}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value === "" ? undefined : Number(e.target.value))}
        className="mt-1 h-9 w-full rounded-md border bg-background px-2 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
      />
      {hint && <span className="mt-0.5 block text-[11px] text-muted-foreground">{hint}</span>}
    </label>
  );
}

export function AssumptionPanel({
  open,
  setOpen,
  base,
  override,
  setOverride,
  costs,
  setCosts,
  customerName,
  onReset,
  rules,
  setRules,
  t,
  sv,
  accountAllocated,
  filtered,
}: {
  t: { allocated: number };
  sv: { water: number; energy: number; co2: number; replacementsPostponed: number };
  accountAllocated: number;
  filtered: boolean;
  open: boolean;
  setOpen: (open: boolean) => void;
  rules: PerformanceRules;
  setRules: (r: PerformanceRules) => void;
  base: Baseline;
  override: BaselineOverride;
  setOverride: (o: BaselineOverride) => void;
  costs: CostInputs;
  setCosts: (c: CostInputs) => void;
  customerName: string;
  onReset: () => void;
}) {
  const snapshot = useRef<{ override: BaselineOverride; costs: CostInputs; rules: PerformanceRules } | null>(null);
  useEffect(() => {
    if (open && snapshot.current === null) snapshot.current = { override, costs, rules };
    if (!open) snapshot.current = null;
  }, [open, override, costs, rules]);
  const active = Object.entries(override).some(([k, v]) => k !== "source" && v !== undefined);

  const openDialog = (next: boolean) => {
    if (next) snapshot.current = { override, costs, rules };
    if (!next && snapshot.current) {
      setOverride(snapshot.current.override);
      setCosts(snapshot.current.costs);
      setRules(snapshot.current.rules);
    }
    setOpen(next);
  };
  const cancel = () => {
    if (snapshot.current) {
      setOverride(snapshot.current.override);
      setCosts(snapshot.current.costs);
      setRules(snapshot.current.rules);
    }
    setOpen(false);
  };
  const clearAll = () => {
    onReset();
  };

  const eff = {
    water: override.water_l_per_kg ?? base.water_l_per_kg,
    energy: override.energy_kwh_per_kg ?? base.energy_kwh_per_kg,
    co2: override.process_kgco2e_per_kg ?? base.process_kgco2e_per_kg,
  };

  return (
    <Dialog open={open} onOpenChange={openDialog}>
      <DialogTrigger asChild>
        <Button variant="secondary" size="sm" className="print:hidden">
          <SlidersHorizontal className="mr-1 h-4 w-4" /> {active ? "Assumptions · adjusted" : "Adjust assumptions"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Assumptions for {customerName}</DialogTitle>
          <DialogDescription>
            Customer-supplied values replace the proposed defaults and recalculate every figure on this review live. Annual costs must cover the same sites, service scope and year.
          </DialogDescription>
        </DialogHeader>
        <div className="rounded-lg border bg-muted/40 px-3 py-2 text-xs">
          <span className="font-medium">Baseline currently in use:</span>{" "}
          <span className="font-mono">{n(eff.water, 1)} L/kg · {n(eff.energy, 2)} kWh/kg · {n(eff.co2, 3)} kgCO₂e/kg</span>{" "}
          <span className="text-muted-foreground">({active ? "customer-supplied" : `data-pack default · ${base.baseline_name}`}{override.source ? ` · source: ${override.source}` : ""})</span>
        </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Their current way of washing ({base.baseline_name})</p>
          <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <NumField label="Water L / kg" value={override.water_l_per_kg} placeholder={String(base.water_l_per_kg)} onChange={(v) => setOverride({ ...override, water_l_per_kg: v })} />
            <NumField label="Energy kWh / kg" value={override.energy_kwh_per_kg} placeholder={String(base.energy_kwh_per_kg)} onChange={(v) => setOverride({ ...override, energy_kwh_per_kg: v })} />
            <NumField label="Process kgCO₂e / kg" value={override.process_kgco2e_per_kg} placeholder={String(base.process_kgco2e_per_kg)} onChange={(v) => setOverride({ ...override, process_kgco2e_per_kg: v })} />
          </div>
          <label className="mt-3 block text-xs">
            <span className="font-medium">Where the numbers come from</span>
            <input
              value={override.source ?? ""}
              onChange={(e) => setOverride({ ...override, source: e.target.value })}
              placeholder="e.g. Customer's in-house laundry meter, 2025"
              className="mt-1 h-9 w-full rounded-md border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </label>
        </div>
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Prices for the money view (proposed defaults)</p>
          <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <NumField label="Water € / m³" value={costs.waterEurPerM3} onChange={(v) => setCosts({ ...costs, waterEurPerM3: v ?? 0 })} hint="Nordic tap + wastewater ≈ €4.5" />
            <NumField label="Energy € / kWh" value={costs.energyEurPerKwh} onChange={(v) => setCosts({ ...costs, energyEurPerKwh: v ?? 0 })} />
            <NumField label="Carbon € / t" value={costs.carbonEurPerT} step={1} onChange={(v) => setCosts({ ...costs, carbonEurPerT: v ?? 0 })} hint="Shadow price, ≈ EU ETS" />
            <NumField label="Garment € each" value={costs.garmentEur} onChange={(v) => setCosts({ ...costs, garmentEur: v ?? 0 })} hint="Data-pack average" />
            <NumField label="Extra garments if owned %" value={Math.round(costs.ownedFleetExtra * 100)} step={1} onChange={(v) => setCosts({ ...costs, ownedFleetExtra: (v ?? 0) / 100 })} />
            <NumField label="Lindström fee € / yr" value={costs.lindstromFeeEur || undefined} step={100} placeholder="optional" onChange={(v) => setCosts({ ...costs, lindstromFeeEur: v ?? 0 })} />
            <NumField label="Alternative total cost € / yr" value={costs.alternativeAnnualEur} step={100} placeholder="Customer estimate" onChange={(v) => setCosts({ ...costs, alternativeAnnualEur: v })} hint="Same sites and year; include garments annualised, washing, repairs, delivery and administration." />
          </div>
        </div>
      </div>
      <div className="mt-5 border-t pt-4">
        <p className="font-medium">Customer costs that may not appear on a laundry invoice</p>
        <p className="mt-1 text-xs text-muted-foreground">Enter annual totals for the whole customer account. Blank means unknown; zero means confirmed none. These costs are not assumed to disappear under Lindström.</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <NumField label="Alternative admin hours / yr" value={costs.alternativeAdminHours} step={1} onChange={v => setCosts({ ...costs, alternativeAdminHours: v })} hint="Sizing, sorting, ordering and tracking" />
          <NumField label="Admin hours with Lindström / yr" value={costs.serviceAdminHours} step={1} onChange={v => setCosts({ ...costs, serviceAdminHours: v })} />
          <NumField label="Loaded labour € / hour" value={costs.loadedHourlyEur} onChange={v => setCosts({ ...costs, loadedHourlyEur: v })} hint="Pay plus employer overhead" />
          <NumField label="Alternative lost garments / yr" value={costs.annualLostGarments} step={1} onChange={v => setCosts({ ...costs, annualLostGarments: v })} hint="Exclude losses already counted in repairs" />
          <NumField label="Alternative audit prep hours / yr" value={costs.alternativeAuditHours} step={1} onChange={v => setCosts({ ...costs, alternativeAuditHours: v })} hint="Separate from admin hours; no fines assumed" />
          <label className="block text-xs"><span className="font-medium">Cost evidence / source</span><input className="mt-1 h-9 w-full rounded-md border bg-background px-2" placeholder="Customer payroll / stock records" value={costs.hiddenCostSource ?? ""} onChange={e => setCosts({ ...costs, hiddenCostSource: e.target.value })} /></label>
        </div>
      </div>
      <CostDetails t={t} sv={sv} costs={costs} accountAllocated={accountAllocated} filtered={filtered} />
      <div className="mt-5 border-t pt-4"><PerformanceCriteria rules={rules} setRules={setRules} /></div>
      <div className="mt-6 flex flex-wrap items-center justify-between gap-2 border-t pt-4">
        <Button variant="ghost" size="sm" onClick={clearAll}>
          <RotateCcw className="mr-1 h-4 w-4" /> Clear all — back to data-pack defaults
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={cancel}>Cancel</Button>
          <Button size="sm" onClick={() => { snapshot.current = null; setOpen(false); }}>Save changes</Button>
        </div>
      </div>
      </DialogContent>
    </Dialog>
  );
}

export function CfoSection({
  t,
  sv,
  costs,
  onAdjust,
}: {
  onAdjust?: (() => void) | undefined;
  t: { allocated: number };
  sv: { water: number; energy: number; co2: number; replacementsPostponed: number };
  costs: CostInputs;
}) {
  const v = cfoValue(t, sv, costs);
  const eur = (x: number) => `€${n(x / 1000, 1)}k`;
  return (
    <section className="print-break">
      <SectionTitle eyebrow="02 · Money view" title="Cost comparison & customer value">
        <p className="max-w-md text-xs text-muted-foreground">
          Customer-paid service fee versus a customer-supplied annual alternative. Estimates, not audited savings or Lindström’s internal operating costs.
        </p>
      </SectionTitle>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <Kpi tone="cost" label="Water bill avoided" value={eur(v.water)} status="ESTIMATE" formula={`water saved m³ × €${costs.waterEurPerM3}/m³`} />
        <Kpi tone="cost" label="Energy bill avoided" value={eur(v.energy)} status="ESTIMATE" formula={`energy saved kWh × €${costs.energyEurPerKwh}/kWh`} />
        <Kpi tone="cost" label="Carbon value" value={eur(v.carbon)} status="ESTIMATE" formula={`tCO₂e avoided × €${costs.carbonEurPerT}/t shadow carbon price`} />
        <Kpi tone="cost" label="Replacements avoided" value={eur(v.replacements)} status="ESTIMATE" formula={`${n(sv.replacementsPostponed)} replacements postponed by repair × €${costs.garmentEur}/garment`} />
        <Kpi tone="cost" label="Smaller garment fleet" value={eur(v.fleet)} status="ESTIMATE" formula={`allocated ${n(t.allocated)} × ${n(costs.ownedFleetExtra * 100)}% extra garments if owned = ${n(v.extraGarments)} × €${costs.garmentEur}`} sub={`${n(v.extraGarments)} garments not bought`} />
        <Kpi tone="cost"
          label="Annual cash benefit estimate"
          value={eur(v.annualCashBenefit)}
          status="ESTIMATE"
          emphasis
          formula="Water + energy + replacements postponed. Excludes shadow carbon value and upfront extra-fleet capital. Not a complete alternative TCO."
          sub="Before fee · excludes carbon & upfront fleet"
        />
      </div>
      {(v.alternative === null || v.fee === null) && (
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-y py-4">
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-medium">Annual cost comparison awaits customer figures</h3>
            <p className="mt-1 text-xs text-muted-foreground">{v.alternative === null && v.fee === null ? "The alternative annual total and Lindström service fee have not been supplied." : v.alternative === null ? "The alternative annual total has not been supplied." : "The Lindström annual service fee has not been supplied."} Both must cover the same sites, service scope and year before cost difference and ROI can be shown.</p>
          </div>
          {onAdjust && <Button variant="outline" size="sm" onClick={onAdjust} className="print:hidden"><SlidersHorizontal className="mr-1 h-4 w-4" /> Adjust assumptions</Button>}
        </div>
      )}
      {(v.alternative !== null || v.fee !== null) && <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        {v.alternative !== null && <Kpi tone="neutral" label="Alternative annual TCO" value={eur(v.alternative)} status="ESTIMATE" formula="Customer-supplied annual total for owning and operating workwear, for the same sites, service scope and year." sub="Customer’s own / local service estimate" />}
        {v.fee !== null && <Kpi tone="cost" label="Lindström annual fee" value={eur(v.fee)} status="ESTIMATE" formula="Annual customer-paid Lindström contract fee entered by the KAM; not Lindström’s internal cost." sub="Customer-paid service investment" />}
        {v.annualDifference !== null && <Kpi tone="cost" label="Annual cost difference" value={eur(v.annualDifference)} status="ESTIMATE" formula="Alternative annual TCO − Lindström annual contract fee. Negative means Lindström costs more in this comparison." sub={v.savingsPct === null ? "Percentage unavailable for a zero alternative cost" : `${n(v.savingsPct, 1)}% of alternative cost`} />}
        {v.roiPct !== null && <Kpi tone="cost" label="Net ROI" value={`${n(v.roiPct, 1)}%`} status="ESTIMATE" formula="(Alternative annual TCO − Lindström annual fee) ÷ Lindström annual fee × 100. Cost reduction uses alternative TCO as denominator instead." sub="Annual cost difference / service fee" />}
      </div>}

    </section>
  );
}

function CostDetails({ t, sv, costs, accountAllocated, filtered }: {
  t: { allocated: number };
  sv: { water: number; energy: number; co2: number; replacementsPostponed: number };
  costs: CostInputs;
  accountAllocated: number;
  filtered: boolean;
}) {
  const v = cfoValue(t, sv, costs);
  const hc = hiddenCosts(costs);
  const accountFleet = cfoValue({ allocated: accountAllocated }, sv, costs).fleet;
  const eur = (x: number) => `€${n(x / 1000, 1)}k`;
  return (
    <div>
      <div className="mt-8 border-y py-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h3 className="font-display text-xl">Invisible customer costs — beyond the invoice</h3><StatusTag status="ESTIMATE" /></div>
        <p className="mb-4 text-xs text-muted-foreground">Whole customer account, annual estimates. {costs.hiddenCostSource ? `Source: ${costs.hiddenCostSource}.` : "No customer source supplied."} {filtered ? "These entered totals do not change with site filters." : ""} They may already be included in the alternative TCO; do not add them again.</p>
        {hc.total === null ? <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-muted-foreground">No alternative administration, garment-loss or audit-preparation costs are available yet. Missing amounts are unknown, not zero.</p>
        </div> : <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {hc.admin !== null && <Kpi tone="cost" label="Alternative administration" value={eur(hc.admin)} status="ESTIMATE" formula={`${costs.alternativeAdminHours ?? "unknown"} annual admin hours × €${costs.loadedHourlyEur ?? "unknown"}/hour. Account-wide.`} sub={hc.adminDifference === null ? "Service administration not yet comparable" : `Difference vs service admin: ${eur(hc.adminDifference)} / yr`} />}
          {hc.loss !== null && <Kpi tone="cost" label="Alternative garment losses" value={eur(hc.loss)} status="ESTIMATE" formula={`${costs.annualLostGarments ?? "unknown"} lost garments per year × €${costs.garmentEur} each. No assumed RFID saving; account-wide.`} />}
          {hc.audit !== null && <Kpi tone="cost" label="Alternative audit preparation" value={eur(hc.audit)} status="ESTIMATE" formula={`${costs.alternativeAuditHours ?? "unknown"} annual audit preparation hours × €${costs.loadedHourlyEur ?? "unknown"}/hour. Exclude hours already in administration; not fines avoided.`} />}
          <Kpi tone="cost" label="Entered hidden-cost subtotal" value={eur(hc.total)} status="ESTIMATE" formula="Sum of entered alternative administration, loss and audit preparation estimates. Missing categories excluded, not zero; separate from TCO, ROI and benefit shares." sub="Partial annual costs · not extra savings" />
        </div>}
        <p className="mt-3 text-xs text-muted-foreground" title={`Account allocated garments × ${costs.ownedFleetExtra * 100}% extra buffer (rounded) × €${costs.garmentEur}.`}>Upfront buffer stock estimate (whole account): {eur(accountFleet)} <StatusTag status="ESTIMATE" /> · separate capital, not an annual expense.</p>
        <p className="mt-2 text-xs text-muted-foreground">Customer administration with Lindström: <span title="Entered annual service-side customer administration hours × loaded hourly cost.">{hc.serviceAdmin === null ? "Not entered" : `${eur(hc.serviceAdmin)} / yr`} <StatusTag status="ESTIMATE" /></span>. No labour, loss or compliance savings are guaranteed. Enter comparable annual totals above.</p>
      </div>
      <div className="mt-6 overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <caption className="mb-3 text-left font-medium">What contributes to the estimated benefit</caption>
          <thead className="border-b text-xs text-muted-foreground"><tr><th className="py-2 pr-4">Category</th><th className="py-2 pr-4">Estimated value</th><th className="py-2 pr-4">Annual benefit share</th><th className="py-2">Lindström fee by category</th></tr></thead>
          <tbody>
            {[
              { label: "Water efficiency", value: v.water, share: v.shares.water, formula: "Water saved m³ × water €/m³" },
              { label: "Energy efficiency", value: v.energy, share: v.shares.energy, formula: "Energy saved kWh × energy €/kWh" },
              { label: "Replacements postponed", value: v.replacements, share: v.shares.replacements, formula: "Repairs × repair factor × garment €/each; postponed purchases, not confirmed annual cash savings" },
              { label: "Extra fleet capital", value: v.fleet, share: null, formula: "Allocated garments × extra-fleet share, rounded × garment €/each; upfront capital, excluded from annual totals" },
              { label: "Shadow carbon value", value: v.carbon, share: null, formula: "Avoided tCO₂e × shadow carbon €/t; non-cash, excluded from annual totals" },
            ].map((row) => (
              <tr key={row.label} className="border-b" title={`${row.formula}. Annual benefit share = category value ÷ (water + energy + replacements) × 100.`}>
                <th scope="row" className="py-3 pr-4 font-medium">{row.label}</th>
                <td className="py-3 pr-4 font-mono">{eur(row.value)} <StatusTag status="ESTIMATE" /></td>
                <td className="py-3 pr-4 font-mono">{row.share === null ? "Excluded" : `${n(row.share, 1)}%`}</td>
                <td className="py-3 text-muted-foreground">Not itemised</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs leading-relaxed text-muted-foreground">Benefit shares are not category savings rates. The fee is not allocated across categories without an itemised contract. Fleet capital and shadow carbon value stay separate; repair benefits may overlap with fleet assumptions. No fee, inclusion of repairs, or zero extra charges is assumed. Annual TCO must use the same period and scope, annualise garment purchases and avoid double-counting these benefits.</p>
    </div>
  );
}

export function EquivNote({ text, formula, source }: { text: string; formula: string; source?: string }) {
  return (
    <span title={formula} className="mt-3 block border-t pt-3 text-foreground/80">
      ≈ {text}
      {source && <span className="block text-[10px] text-muted-foreground">Source: {source} · see Methodology</span>}
    </span>
  );
}

export const EQUIV_SOURCES = `Everyday comparisons use public reference values: ${n(EQUIV.residentWaterM3PerYear, 1)} m³ water per Helsinki resident per year (≈130 L/day), ${EQUIV.carKgCo2PerKm} kgCO₂e per car km, ${EQUIV.personTCo2PerYear} tCO₂e per Finn per year, ${n(EQUIV.apartmentKwhPerYear)} kWh per apartment per year.`;

