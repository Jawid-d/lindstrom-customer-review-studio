import { data, TEMPLATE_COLUMNS, type Customer, type HygieneLine, type Site } from "./review";

/**
 * Turns rows from the data import template (one row per site × product × month)
 * into a Customer the dashboard can review. Footprint columns are not in the
 * template, so they are estimated from the data pack's Lindström intensity per kg.
 */
type Cell = string | number | Date | null | undefined;
type TemplateKey = (typeof TEMPLATE_COLUMNS)[number][0];
export type ImportRow = { [K in TemplateKey]?: Cell } & { [key: string]: Cell };
export type ImportResult =
  | { ok: true; customer: Customer; rows: number; warnings: string[] }
  | { ok: false; errors: string[] };

const NUMERIC = [
  "active_wearers",
  "allocated_pieces",
  "active_assets_scanned",
  "washed_pieces",
  "washed_kg",
  "repairs",
  "service_requests",
  "late_cycles",
  "total_cycles",
] as const;

/** Pack-wide Lindström footprint per kg washed, used when a site's footprint is not supplied. */
export function packIntensity() {
  let kg = 0, water = 0, energy = 0, process = 0, delivery = 0, waste = 0, repairs = 0, avoided = 0;
  for (const c of data.customers)
    for (const s of c.sites) {
      kg += s.washedKg; water += s.water; energy += s.energy; process += s.process;
      delivery += s.delivery; waste += s.waste; repairs += s.repairs; avoided += s.avoidedProductKg;
    }
  return {
    water: water / kg,
    energy: energy / kg,
    process: process / kg,
    delivery: delivery / kg,
    waste: waste / kg,
    avoidedPerRepair: repairs ? avoided / repairs : 0,
  };
}

const num = (v: unknown) => {
  if (v === null || v === undefined || v === "") return NaN;
  return typeof v === "number" ? v : Number(String(v).replace(",", ".").trim());
};

/** Accepts "2025-01", Excel dates and "2025/1"; returns YYYY-MM or the original text. */
function monthKey(v: unknown): string {
  if (v instanceof Date && !Number.isNaN(v.getTime())) return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, "0")}`;
  const t = String(v ?? "").trim();
  const m = /^(\d{4})[-/.](\d{1,2})/.exec(t);
  return m ? `${m[1]}-${m[2]!.padStart(2, "0")}` : t;
}

export function buildCustomer(input: ImportRow[], industry: string): ImportResult {
  const rows: ImportRow[] = input.map((r) => ({ ...r, month: monthKey(r.month) }));
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!rows.length) return { ok: false, errors: ["The file has no data rows."] };

  const header = Object.keys(rows[0]!);
  const missing = TEMPLATE_COLUMNS.map((c) => c[0]).filter((c) => !header.includes(c));
  if (missing.length) return { ok: false, errors: [`Missing columns: ${missing.join(", ")}. Use the data import template.`] };

  const ids = new Set(rows.map((r) => String(r.customer_id ?? "").trim()).filter(Boolean));
  if (ids.size !== 1) errors.push(`The file must contain exactly one customer_id (found ${ids.size}).`);

  rows.forEach((r, i) => {
    const line = i + 2;
    if (!/^\d{4}-\d{2}$/.test(String(r.month ?? "").trim())) errors.push(`Row ${line}: month must be YYYY-MM.`);
    if (!String(r.site_id ?? "").trim()) errors.push(`Row ${line}: site_id is empty.`);
    for (const k of NUMERIC) {
      const v = num(r[k]);
      if (!Number.isFinite(v) || v < 0) errors.push(`Row ${line}: ${k} must be a number of 0 or more.`);
    }
    if (num(r.late_cycles) > num(r.total_cycles)) errors.push(`Row ${line}: late_cycles cannot exceed total_cycles.`);
  });
  if (errors.length) return { ok: false, errors: errors.slice(0, 12).concat(errors.length > 12 ? [`…and ${errors.length - 12} more.`] : []) };

  const k = packIntensity();
  const months = Array.from(new Set(rows.map((r) => String(r.month).trim()))).sort();
  const last = months[months.length - 1]!;
  const siteMap = new Map<string, Site>();

  for (const r of rows) {
    const id = String(r.site_id).trim();
    let s = siteMap.get(id);
    if (!s) {
      s = {
        id, name: String(r.site_name ?? id).trim(), country: String(r.country ?? "").trim() || "Unknown",
        city: String(r.site_name ?? "").trim(), type: "Delivery site", laundry: String(r.laundry_id ?? "").trim(),
        wearers: 0, allocated: 0, scanned: 0, washedKg: 0, washedPieces: 0, requests: 0, repairs: 0,
        avoidedProductKg: 0, cycles: 0, late: 0, avgCycleH: null, water: 0, energy: 0, process: 0,
        delivery: 0, waste: 0, lines: [], sampleGapDays: null,
      };
      siteMap.set(id, s);
    }
    const m = String(r.month).trim();
    const line: HygieneLine = {
      p: String(r.product_id ?? "").trim(), m,
      alloc: num(r.allocated_pieces), scanned: num(r.active_assets_scanned),
      washed: num(r.washed_pieces), wearers: num(r.active_wearers),
    };
    s.lines.push(line);
    // Stock figures (wearers, allocated, scanned) use the latest month, like the data pack's December snapshot.
    if (m === last) { s.wearers += line.wearers; s.allocated += line.alloc; s.scanned += line.scanned; }
    s.washedKg += num(r.washed_kg); s.washedPieces += line.washed; s.repairs += num(r.repairs);
    s.requests += num(r.service_requests); s.cycles += num(r.total_cycles); s.late += num(r.late_cycles);
  }

  const sites = Array.from(siteMap.values()).map((s) => ({
    ...s,
    water: s.washedKg * k.water,
    energy: s.washedKg * k.energy,
    process: s.washedKg * k.process,
    delivery: s.washedKg * k.delivery,
    waste: s.washedKg * k.waste,
    avoidedProductKg: s.repairs * k.avoidedPerRepair,
  }));

  const monthly = months.map((m) => {
    const rs = rows.filter((r) => String(r.month).trim() === m);
    const sum = (key: string) => rs.reduce((a, r) => a + num(r[key]), 0);
    return { month: m, washedKg: sum("washed_kg"), requests: sum("service_requests"), wearers: sum("active_wearers"), repairs: sum("repairs") };
  });

  const productIds = Array.from(new Set(rows.map((r) => String(r.product_id).trim())));
  const products = productIds.map((p) => {
    const rs = rows.filter((r) => String(r.product_id).trim() === p);
    return {
      product: p,
      washedKg: rs.reduce((a, r) => a + num(r.washed_kg), 0),
      allocatedDec: rs.filter((r) => String(r.month).trim() === last).reduce((a, r) => a + num(r.allocated_pieces), 0),
      repairs: rs.reduce((a, r) => a + num(r.repairs), 0),
    };
  });
  const unknown = productIds.filter((p) => !data.products.some((x) => x.product_id === p));
  if (unknown.length) warnings.push(`Product ids not in the product master (garment cost and weight use averages): ${unknown.join(", ")}.`);
  if (months.length < 12) warnings.push(`Only ${months.length} month(s) of data — yearly figures cover that period only.`);
  warnings.push("Water, energy and CO₂e footprint are estimated from the data pack's average Lindström intensity per kg washed.");

  const first = rows[0]!;
  const customer: Customer = {
    id: `UPLOAD-${String(first.customer_id).trim()}`,
    name: String(first.customer_name ?? first.customer_id).trim(),
    industry,
    segment: "Uploaded data",
    hq: sites[0]?.country ?? "",
    priorities: data.industryPriorities.filter((p) => p.industry === industry).map((p) => p.priority_theme),
    sites,
    monthly,
    repairTypes: [],
    products,
  };
  return { ok: true, customer, rows: rows.length, warnings };
}
