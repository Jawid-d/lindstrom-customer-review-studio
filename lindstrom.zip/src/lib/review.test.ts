import { describe, expect, it } from "vitest";
import { data, interpretPrompt, portfolioHygiene, savings, siteHygiene, siteMetrics, totals } from "./review";

const northstar = data.customers.find((c) => c.id === "CUST001")!;
const local = data.baselines.find((b) => b.baseline_id === "B_LOCAL")!;

describe("NorthStar reconciliation with the data pack", () => {
  const t = totals(northstar.sites);
  it("has 24 delivery sites", () => expect(t.sites).toBe(24));
  it("washed 502,074.7 kg", () => expect(t.washedKg).toBeCloseTo(502074.7, 0));
  it("had 15,233 repairs", () => expect(t.repairs).toBe(15233));
  it("had 515 service requests", () => expect(t.requests).toBe(515));
  it("has 28,367 December wearers", () => expect(t.wearers).toBe(28367));
  it("saves 1,406,482.6 L water vs local laundry", () => expect(savings(t, local).water).toBeCloseTo(1406482.6, -1));
  it("saves 255,073.1 kgCO2e vs local laundry", () => expect(savings(t, local).co2).toBeCloseTo(255073.1, -1));
  it("low scenario halves postponed replacements", () => expect(savings(t, local, "low").replacementsPostponed).toBe(15233 / 2));
});

describe("site rules", () => {
  it("flags a site scanning under 85% of allocation", () => {
    const m = siteMetrics({ ...northstar.sites[0]!, allocated: 100, scanned: 80 });
    expect(m.flags).toContain("Idle garments");
    expect(m.idle).toBe(12);
  });
  it("routes an allocation prompt to cost focus", () => {
    expect(interpretPrompt("Which sites have allocation optimization potential?").focus).toContain("cost");
  });
});

describe("hygiene & wash compliance", () => {
  const base = northstar.sites[0]!;
  const line = (p: string, washed: number, scanned = 100) => ({ p, m: "2025-01", alloc: 100, scanned, washed, wearers: 90 });
  it("counts a line-month under 1.5 washes per garment as under the floor", () => {
    const h = siteHygiene({ ...base, lines: [line("P1001", 140), line("P1001", 160)] }, 1.5);
    expect(h.underMonths).toBe(1);
    expect(h.underShare).toBe(0.5);
  });
  it("is High risk when a food coat line is under the floor 3 or more months", () => {
    const h = siteHygiene({ ...base, lines: [line("P1004", 100), line("P1004", 100), line("P1004", 100)] }, 1.5);
    expect(h.risk).toBe("High");
  });
  it("is Medium risk when more than 20% of garments had no scan", () => {
    const h = siteHygiene({ ...base, lines: [line("P1001", 200, 75)] }, 1.5);
    expect(h.risk).toBe("Medium");
  });
  it("is Low risk when every line meets the floor and is scanned", () => {
    expect(siteHygiene({ ...base, lines: [line("P1004", 200)] }, 1.5).risk).toBe("Low");
  });
  it("NorthStar has 864 product-line months on record", () => {
    expect(portfolioHygiene(northstar.sites).lineMonths).toBe(864);
  });
});

import { valueBridge, avgGarmentCost as _agc } from "./review";
describe("value bridge", () => {
  const c = data.customers.find((x) => x.id === "CUST001")!;
  const b = data.baselines.find((x) => x.baseline_id === "B_LOCAL")!;
  it("repair capex = 15,233 repairs x avg garment cost", () => {
    const v = valueBridge(c, c.sites, b, "base");
    expect(v.t.repairs).toBe(15233);
    expect(v.repairCapexAvoided).toBeCloseTo(15233 * _agc(c), 2);
  });
  it("low scenario halves postponed replacements", () => {
    const v = valueBridge(c, c.sites, b, "low");
    expect(v.sv.replacementsPostponed).toBeCloseTo(7616.5, 1);
  });
});

import { applyOverride, cfoValue, equivalents, DEFAULT_COSTS, templateCsv, TEMPLATE_COLUMNS } from "./review";

describe("KAM assumptions and CFO view", () => {
  const b = data.baselines[0]!;
  it("KAM-entered water per kg replaces the baseline value only", () => {
    const o = applyOverride(b, { water_l_per_kg: 50 });
    expect(o.water_l_per_kg).toBe(50);
    expect(o.energy_kwh_per_kg).toBe(b.energy_kwh_per_kg);
    expect(o.baseline_name).toContain("KAM-entered");
  });
  it("empty override keeps the original baseline", () => {
    expect(applyOverride(b, {})).toBe(b);
  });
  it("one Helsinki resident ≈ 47.45 m³ water per year", () => {
    expect(equivalents({ water: 47_450, co2: 0, energy: 0 }).residentsWater).toBeCloseTo(1, 5);
  });
  it("170 kgCO2e ≈ 1,000 car km", () => {
    expect(equivalents({ water: 0, co2: 170, energy: 0 }).carKm).toBeCloseTo(1000, 5);
  });
  it("owning workwear needs 30% extra garments: 1,000 allocated × €10 → €3,000", () => {
    const v = cfoValue({ allocated: 1000 }, { water: 0, energy: 0, co2: 0, replacementsPostponed: 0 }, { ...DEFAULT_COSTS(10), garmentEur: 10 });
    expect(v.extraGarments).toBe(300);
    expect(v.fleet).toBe(3000);
    expect(v.net).toBeNull();
  });
  it("net value subtracts the entered Lindström fee", () => {
    const v = cfoValue({ allocated: 1000 }, { water: 0, energy: 0, co2: 0, replacementsPostponed: 0 }, { ...DEFAULT_COSTS(10), garmentEur: 10, lindstromFeeEur: 1000 });
    expect(v.net).toBe(2000);
  });
  it("template has one header column per field", () => {
    expect(templateCsv().split("\n")[0]!.split(",").length).toBe(TEMPLATE_COLUMNS.length);
  });
  it("compares €1m alternative against €500k fee: €500k difference, 100% ROI, 50% reduction", () => {
    const v = cfoValue({ allocated: 0 }, { water: 0, energy: 0, co2: 0, replacementsPostponed: 0 }, { ...DEFAULT_COSTS(10), lindstromFeeEur: 500000, alternativeAnnualEur: 1000000 });
    expect(v.annualDifference).toBe(500000);
    expect(v.roiPct).toBe(100);
    expect(v.savingsPct).toBe(50);
  });
  it("does not infer alternative TCO or ROI from partial benefit estimates", () => {
    const v = cfoValue({ allocated: 1000 }, { water: 1000, energy: 1000, co2: 1000, replacementsPostponed: 100 }, { ...DEFAULT_COSTS(10), lindstromFeeEur: 500 });
    expect(v.annualDifference).toBeNull();
    expect(v.roiPct).toBeNull();
  });
  it("keeps negative differences and does not divide by zero", () => {
    const input = { ...DEFAULT_COSTS(10), lindstromFeeEur: 1000, alternativeAnnualEur: 0 };
    const v = cfoValue({ allocated: 0 }, { water: 0, energy: 0, co2: 0, replacementsPostponed: 0 }, input);
    expect(v.annualDifference).toBe(-1000);
    expect(v.roiPct).toBe(-100);
    expect(v.savingsPct).toBeNull();
    expect(cfoValue({ allocated: 0 }, { water: 0, energy: 0, co2: 0, replacementsPostponed: 0 }, { ...input, lindstromFeeEur: 0 }).roiPct).toBeNull();
  });
  it("excludes upfront fleet and shadow carbon from annual cash benefit shares", () => {
    const v = cfoValue({ allocated: 1000 }, { water: 100000, energy: 1000, co2: 10000, replacementsPostponed: 100 }, { ...DEFAULT_COSTS(10), waterEurPerM3: 5, energyEurPerKwh: 0.5 });
    expect(v.annualCashBenefit).toBe(2000);
    expect(v.shares).toEqual({ water: 25, energy: 25, replacements: 50 });
    expect(v.fleet).toBe(3000);
    expect(v.carbon).toBe(800);
  });
});

import { talkingPointFacts } from "./review";
describe("AI talking point facts", () => {
  it("passes NorthStar's real repairs and marks savings as estimates", () => {
    const c = data.customers.find((x) => x.id === "CUST001")!;
    const b = data.baselines.find((x) => x.baseline_id === "B_LOCAL")!;
    const f = talkingPointFacts(c, c.sites, b);
    expect(f.find((x) => x.label === "Repairs")!.value).toBe("15,233");
    expect(f.filter((x) => x.label.startsWith("Water saved"))[0]!.status).toBe("ESTIMATE");
  });
});

import { siteHealth, healthTable, HEALTH_WEIGHTS } from "./review";
describe("site health score (proposed)", () => {
  const base = data.customers.find((x) => x.id === "CUST001")!.sites[0]!;
  it("weights sum to 100", () => expect(Object.values(HEALTH_WEIGHTS).reduce((a, b) => a + b, 0)).toBe(100));
  it("a perfect site scores 100", () => {
    const s = { ...base, allocated: 100, scanned: 100, late: 0, cycles: 10, requests: 0, lines: [{ p: "P1001", m: "2025-01", alloc: 100, scanned: 100, washed: 200, wearers: 90 }] };
    expect(siteHealth(s, 10).score).toBe(100);
  });
  it("NorthStar scores every site between 0 and 100", () => {
    const h = healthTable(data.customers.find((x) => x.id === "CUST001")!.sites);
    expect(h.size).toBe(24);
    for (const v of h.values()) expect(v.score).toBeGreaterThanOrEqual(0), expect(v.score).toBeLessThanOrEqual(100);
  });
});

import { textileEquivalents, workforceElasticity, benchmarkSites, repairIntensity } from "./review";
import { SCENARIO_LABEL } from "./review";
import { performanceGrade, resourceReduction, hiddenCosts, DEFAULT_PERFORMANCE } from "./review";

describe("proposed performance criteria", () => {
  it.each([
    ["delivery", 98, 95, 90], ["scan", 85, 75, 65], ["compliance", 98, 95, 90],
    ["health", 85, 70, 55], ["resource", 20, 10, 5],
  ] as const)("grades %s at exact boundaries", (metric, excellent, good, fair) => {
    expect(performanceGrade(excellent, metric)).toBe("Excellent");
    expect(performanceGrade(excellent - 0.01, metric)).toBe("Good");
    expect(performanceGrade(good, metric)).toBe("Good");
    expect(performanceGrade(good - 0.01, metric)).toBe("Fair");
    expect(performanceGrade(fair, metric)).toBe("Fair");
    expect(performanceGrade(fair - 0.01, metric)).toBe("Needs attention");
  });
  it("uses customer-adjusted criteria", () => expect(performanceGrade(98, "delivery", { ...DEFAULT_PERFORMANCE, delivery: [99, 98, 95] })).toBe("Good"));
  it("does not grade missing denominators", () => expect(performanceGrade(resourceReduction(100, 0), "resource")).toBeNull());
  it("calculates reduction against the comparison and retains negative values", () => {
    expect(resourceReduction(20, 100)).toBe(20);
    expect(resourceReduction(-10, 100)).toBe(-10);
  });
});

describe("customer-entered invisible costs", () => {
  const costs = { ...DEFAULT_COSTS(10), alternativeAdminHours: 100, serviceAdminHours: 40, loadedHourlyEur: 35, annualLostGarments: 20, alternativeAuditHours: 10 };
  it("values admin hours at the loaded hourly rate", () => expect(hiddenCosts(costs).admin).toBe(3500));
  it("retains customer admin under the service and computes only their difference", () => {
    expect(hiddenCosts(costs).serviceAdmin).toBe(1400);
    expect(hiddenCosts(costs).adminDifference).toBe(2100);
    expect(hiddenCosts({ ...costs, serviceAdminHours: 110 }).adminDifference).toBe(-350);
  });
  it("values entered annual garment losses, with no invented loss rate", () => expect(hiddenCosts(costs).loss).toBe(200));
  it("values audit preparation hours, not penalties", () => expect(hiddenCosts(costs).audit).toBe(350));
  it("keeps diagnostic subtotal separate from annual TCO", () => {
    expect(hiddenCosts(costs).total).toBe(4050);
    const v = cfoValue({ allocated: 0 }, { water: 0, energy: 0, co2: 0, replacementsPostponed: 0 }, { ...costs, alternativeAnnualEur: 10000, lindstromFeeEur: 8000 });
    expect(v.annualDifference).toBe(2000);
    expect(v.annualCashBenefit).toBe(0);
  });
  it("distinguishes unknown from explicitly entered zero", () => {
    expect(hiddenCosts(DEFAULT_COSTS(10)).total).toBeNull();
    expect(hiddenCosts({ ...DEFAULT_COSTS(10), annualLostGarments: 0 }).total).toBe(0);
  });
});
describe("extra executive KPIs", () => {
  const c = data.customers.find((x) => x.id === "CUST001")!;
  it("textile garments = avoided kg / avg garment weight", () => {
    const e = textileEquivalents(c, 1000);
    expect(e.garments * e.avgWeight).toBeCloseTo(1000, 5);
    expect(e.euResidents).toBeCloseTo(62.5, 5);
  });
  it("repair intensity: 50 repairs on 100 garments = 50 per 100", () => {
    expect(repairIntensity({ repairs: 50, allocated: 100 }).per100).toBe(50);
  });
  it("workforce swing = peak minus trough monthly wearers", () => {
    const e = workforceElasticity(c);
    const w = c.monthly.map((m) => m.wearers);
    expect(e.swing).toBe(Math.max(...w) - Math.min(...w));
  });
  it("benchmark site scores at least as high as the weakest", () => {
    const b = benchmarkSites(c.sites);
    expect(b.bestScore).toBeGreaterThanOrEqual(b.worstScore);
  });
});

describe("scenario wording is one wording everywhere", () => {
  it("names all three scenarios with the same words the header shows", () => {
    expect(SCENARIO_LABEL).toEqual({
      base: "Standard (base)",
      low: "Conservative (−15%)",
      high: "Aggressive (+15%)",
    });
  });
  it("tells the AI briefing the scenario by its user-facing name, not the raw key", () => {
    const facts = talkingPointFacts(northstar, northstar.sites, local, "low");
    const scenario = facts.find((f) => f.label === "Sensitivity scenario");
    expect(scenario?.value).toBe("Conservative (−15%)");
    expect(facts.some((f) => f.value === "low" || f.value === "base" || f.value === "high")).toBe(false);
  });
});

import { defaultCostsFor, textileImpact, avgGarmentWeight } from "./review";

describe("cross-review calculation consistency", () => {
  it("derives textile mass from 15,233 replacement equivalents, not 224,000+ kgCO₂e", () => {
    const t = totals(northstar.sites);
    const tx = textileImpact(northstar, savings(t, local).replacementsPostponed);
    expect(tx.kg).toBeCloseTo(15233 * avgGarmentWeight(northstar), 8);
    expect(tx.garments).toBeCloseTo(15233, 8);
    expect(tx.kg).toBeLessThan(t.avoidedProductKg / 10);
  });
  it("halves physical textile and manufacturing emissions in Conservative", () => {
    const t = totals(northstar.sites);
    const base = savings(t, local, "base");
    const low = savings(t, local, "low");
    expect(textileImpact(northstar, low.replacementsPostponed).kg).toBe(textileImpact(northstar, base.replacementsPostponed).kg / 2);
    expect(low.avoidedProductCo2).toBe(base.avoidedProductCo2 / 2);
  });
  it("keeps a selected site's health score tied to the full-account request reference", () => {
    const base = northstar.sites[0];
    if (!base) throw new Error("Missing fixture");
    const selected = { ...base, id: "selected", wearers: 1000, requests: 10 };
    const worst = { ...base, id: "worst", wearers: 1000, requests: 100 };
    const reference = [selected, worst];
    const score = healthTable([selected], 1.5, reference).get(selected.id);
    expect(score?.parts.requests).toBe(0.9);
    expect(score).toEqual(healthTable(reference).get(selected.id));
  });
  it("uses whole-account allocation and wearers for seasonal capital", () => {
    const c = { ...northstar, monthly: [{ month: "2025-01", wearers: 100, washedKg: 0, requests: 0, repairs: 0 }, { month: "2025-02", wearers: 80, washedKg: 0, requests: 0, repairs: 0 }] };
    const t = totals(c.sites);
    const wf = workforceElasticity(c);
    expect(wf.swing).toBe(20);
    expect(wf.perWearer).toBe(t.allocated / t.wearers);
    expect(wf.strandedGarments).toBe(Math.round(20 * t.allocated / t.wearers));
  });
  it("passes edited wash floor and financial figures to the briefing", () => {
    const facts = talkingPointFacts(northstar, northstar.sites, local, "base", { floor: 2, costs: defaultCostsFor("CUST001", 10) });
    const h = portfolioHygiene(northstar.sites, 2);
    expect(facts.find(f => f.label.includes("wash floor 2"))?.value).toBe(`${Math.round(h.underShare * 100)}%`);
    expect(facts.find(f => f.label === "Lindström annual fee")?.value).toBe("€5,100,000");
    expect(facts.find(f => f.label === "Annual cost difference")?.value).toBe("€750,000");
    expect(facts.find(f => f.label === "Net ROI")?.value).toBe("14.7%");
  });
  it("uses the dashboard's tonnes, MWh and circularity values in briefing facts", () => {
    const sv = savings(totals(northstar.sites), local);
    const facts = talkingPointFacts(northstar, northstar.sites, local);
    expect(facts.find(f => f.label === "Washed weight")?.value).toBe("502.1 tonnes");
    expect(facts.find(f => f.label.startsWith("Energy saved"))?.value).toBe(`${(sv.energy / 1000).toFixed(1)} MWh`);
    expect(facts.find(f => f.label === "New textile production avoided")?.value).toBe(`${(textileImpact(northstar, 15233).kg / 1000).toFixed(1)} t`);
    expect(facts.some(f => f.label === "Net ROI")).toBe(false);
  });
});
describe("demo contract figures", () => {
  it("pre-fills NorthStar fee and alternative so ROI shows", () => {
    const c = defaultCostsFor("CUST001", 10);
    expect(c.lindstromFeeEur).toBe(5_100_000);
    expect(c.alternativeAnnualEur).toBe(5_850_000);
  });
  it("leaves uploaded customers without contract figures", () => {
    const c = defaultCostsFor("UPLOAD-X", 10);
    expect(c.lindstromFeeEur).toBe(0);
    expect(c.alternativeAnnualEur).toBeUndefined();
  });
});
