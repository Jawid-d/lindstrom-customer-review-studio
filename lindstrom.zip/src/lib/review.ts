import raw from "@/data/review-data.json";

export type Status = "MEASURED" | "CALCULATED" | "ALLOCATED" | "ESTIMATE" | "SYNTHETIC";

export interface Site {
  id: string;
  name: string;
  country: string;
  city: string;
  type: string;
  laundry: string;
  wearers: number;
  allocated: number;
  scanned: number;
  washedKg: number;
  washedPieces: number;
  requests: number;
  repairs: number;
  /** Legacy data-pack field: avoided manufacturing emissions in kgCO₂e, NOT textile mass. */
  avoidedProductKg: number;
  cycles: number;
  late: number;
  avgCycleH: number | null;
  water: number;
  energy: number;
  process: number;
  delivery: number;
  waste: number;
  /** Monthly figures per product line (Service_Activity). */
  lines: HygieneLine[];
  /** Median days between laundry visits in the RFID cycle sample (Service_Cycles). */
  sampleGapDays: number | null;
}

export interface HygieneLine {
  p: string;
  m: string;
  alloc: number;
  scanned: number;
  washed: number;
  wearers: number;
}

export interface Customer {
  id: string;
  name: string;
  industry: string;
  segment: string;
  hq: string;
  priorities: string[];
  sites: Site[];
  monthly: { month: string; washedKg: number; requests: number; wearers: number; repairs: number }[];
  repairTypes: { type: string; count: number }[];
  products: { product: string; washedKg: number; allocatedDec: number; repairs: number }[];
}

export interface Baseline {
  baseline_id: string;
  baseline_name: string;
  selection_status: string;
  water_l_per_kg: number;
  energy_kwh_per_kg: number;
  process_kgco2e_per_kg: number;
  delivery_kgco2e_per_kg: number;
  assumption_note: string;
}

export const data = raw as unknown as {
  customers: Customer[];
  baselines: Baseline[];
  assumptions: { assumption_id: string; assumption: string; value_or_rule: string; rationale: string; confidence: string; treatment: string }[];
  dataQuality: { dataset: string; fields: string; status: string; confidence: string; note: string }[];
  industryPriorities: { industry: string; priority_rank: number; priority_theme: string; dashboard_emphasis: string }[];
  products: { product_id: string; product_name: string; synthetic_purchase_cost_eur: number; synthetic_product_footprint_kgco2e: number; avg_weight_kg: number }[];
  laundries: { laundry_id: string; laundry_name: string; country: string }[];
};

export type Scenario = "low" | "base" | "high";

/**
 * Sensitivity rules (prototype assumptions, shown in the methodology panel):
 * - Baseline intensity: low = -15%, base = as given, high = +15%.
 * - Repair handprint: low = 0.5 replacement postponed per repair, base/high = 1 (assumption A002).
 */
export const SCENARIO = {
  low: { baselineFactor: 0.85, repairFactor: 0.5 },
  base: { baselineFactor: 1, repairFactor: 1 },
  high: { baselineFactor: 1.15, repairFactor: 1 },
} as const;

/**
 * The one user-facing name per scenario. Every control, tooltip, export row and
 * AI prompt must use this so the same three words appear everywhere.
 */
export const SCENARIO_LABEL: Record<Scenario, string> = {
  base: "Standard (base)",
  low: "Conservative (−15%)",
  high: "Aggressive (+15%)",
};

/** A site holding this share or more of allocated garments unscanned is flagged. */
export const UTILISATION_TARGET = 0.85;
/** Buffer kept above actively scanned garments when right-sizing. */
export const RIGHTSIZE_BUFFER = 1.1;
export const LATE_RATE_FLAG = 0.025;

export function totals(sites: Site[]) {
  const sum = (k: keyof Site) => sites.reduce((a, s) => a + ((s[k] as number) ?? 0), 0);
  const cycles = sum("cycles");
  const late = sum("late");
  const allocated = sum("allocated");
  const scanned = sum("scanned");
  return {
    sites: sites.length,
    wearers: sum("wearers"),
    allocated,
    scanned,
    washedKg: sum("washedKg"),
    washedPieces: sum("washedPieces"),
    requests: sum("requests"),
    repairs: sum("repairs"),
    avoidedProductKg: sum("avoidedProductKg"),
    cycles,
    late,
    onTimeRate: cycles ? (cycles - late) / cycles : 0,
    utilisation: allocated ? scanned / allocated : 0,
    water: sum("water"),
    energy: sum("energy"),
    emissions: sum("process") + sum("delivery"),
    waste: sum("waste"),
  };
}
export type Totals = ReturnType<typeof totals>;

/** Savings = baseline intensity x washed kg - allocated Lindström footprint. */
export function savings(t: Totals, b: Baseline, scenario: Scenario = "base") {
  const f = SCENARIO[scenario];
  const baseWater = t.washedKg * b.water_l_per_kg * f.baselineFactor;
  const baseEnergy = t.washedKg * b.energy_kwh_per_kg * f.baselineFactor;
  const baseCo2 = t.washedKg * (b.process_kgco2e_per_kg + b.delivery_kgco2e_per_kg) * f.baselineFactor;
  return {
    baseWater,
    baseEnergy,
    baseCo2,
    water: baseWater - t.water,
    energy: baseEnergy - t.energy,
    co2: baseCo2 - t.emissions,
    replacementsPostponed: t.repairs * f.repairFactor,
    avoidedProductCo2: t.avoidedProductKg * f.repairFactor,
  };
}

export function siteMetrics(s: Site) {
  const utilisation = s.allocated ? s.scanned / s.allocated : 0;
  const idle = Math.max(0, Math.round(s.allocated - s.scanned * RIGHTSIZE_BUFFER));
  const lateRate = s.cycles ? s.late / s.cycles : 0;
  const repairsPer100 = s.allocated ? (s.repairs / s.allocated) * 100 : 0;
  const requestsPer1k = s.wearers ? (s.requests / s.wearers) * 1000 : 0;
  const flags: string[] = [];
  if (utilisation < UTILISATION_TARGET) flags.push("Idle garments");
  if (lateRate > LATE_RATE_FLAG) flags.push("Late cycles");
  return { utilisation, idle, lateRate, repairsPer100, requestsPer1k, flags };
}

export function avgGarmentCost(c: Customer) {
  let pieces = 0;
  let cost = 0;
  for (const p of c.products) {
    const prod = data.products.find((x) => x.product_id === p.product);
    if (!prod) continue;
    pieces += p.allocatedDec;
    cost += p.allocatedDec * prod.synthetic_purchase_cost_eur;
  }
  return pieces ? cost / pieces : 0;
}

export type Focus = "water" | "emissions" | "circularity" | "service" | "cost";

export const FOCUS_LABEL: Record<Focus, string> = {
  water: "Water",
  emissions: "Emissions",
  circularity: "Circularity",
  service: "Service reliability",
  cost: "Cost & allocation",
};

export function defaultFocus(industry: string): Focus[] {
  if (industry === "Food & Beverage") return ["water", "service"];
  if (industry === "Manufacturing") return ["cost", "circularity"];
  if (industry === "Healthcare") return ["service", "circularity"];
  return ["emissions"];
}

/** Rules-based prompt interpreter: maps free text to focus areas. */
export function interpretPrompt(text: string): { focus: Focus[]; sortSites?: "idle" | "late" | "repairs" | undefined } {
  const t = text.toLowerCase();
  const focus: Focus[] = [];
  if (/water|litre|liter/.test(t)) focus.push("water");
  if (/emission|co2|carbon|scope|climate|ghg/.test(t)) focus.push("emissions");
  if (/repair|circular|waste|lifetime|recycl/.test(t)) focus.push("circularity");
  if (/service|reliab|late|turnaround|hygiene|continuity|request/.test(t)) focus.push("service");
  if (/cost|allocat|optimi|idle|garment|fleet|saving money|€|eur/.test(t)) focus.push("cost");
  let sortSites: "idle" | "late" | "repairs" | undefined;
  if (/allocat|idle|optimi/.test(t)) sortSites = "idle";
  else if (/late|turnaround/.test(t)) sortSites = "late";
  else if (/repair/.test(t)) sortSites = "repairs";
  return { focus, sortSites };
}

export interface Insight {
  id: string;
  focus: Focus;
  title: string;
  evidence: string;
  action: string;
  status: Status;
  confidence: "High" | "Medium" | "Low-Medium" | "Low";
}

const fmt = (n: number, d = 0) => n.toLocaleString("en-GB", { maximumFractionDigits: d, minimumFractionDigits: d });

/** Deterministic observations, ranked by the selected focus areas. */
export function buildInsights(c: Customer, sites: Site[], b: Baseline, scenario: Scenario, focus: Focus[]): Insight[] {
  const t = totals(sites);
  const s = savings(t, b, scenario);
  const ms = sites.map((x) => ({ site: x, m: siteMetrics(x) }));
  const idleSites = ms.filter((x) => x.m.flags.includes("Idle garments")).sort((a, z) => z.m.idle - a.m.idle);
  const idleTotal = ms.reduce((a, x) => a + x.m.idle, 0);
  const cost = avgGarmentCost(c);
  const lateSites = ms.filter((x) => x.m.flags.includes("Late cycles")).sort((a, z) => z.m.lateRate - a.m.lateRate);
  const topRepair = [...c.repairTypes].sort((a, z) => z.count - a.count)[0];
  const repairShare = topRepair ? topRepair.count / Math.max(1, c.repairTypes.reduce((a, r) => a + r.count, 0)) : 0;
  const busiest = [...sites].sort((a, z) => z.washedKg - a.washedKg)[0];

  const list: Insight[] = [
    {
      id: "rightsize",
      focus: "cost",
      title: `Review about ${fmt(idleTotal)} garments with no scan activity`,
      evidence: `${idleSites.length} of ${sites.length} sites scan under ${fmt(UTILISATION_TARGET * 100)}% of allocated garments in December. ${idleSites
        .slice(0, 3)
        .map((x) => x.site.name.replace(`${c.name.split(" ")[0]} `, ""))
        .join(", ")} lead. At an average €${fmt(cost)} per garment this ties up roughly €${fmt(idleTotal * cost)}.`,
      action: "Agree a joint allocation review for the flagged sites before the next contract period.",
      status: "ESTIMATE",
      confidence: "Medium",
    },
    {
      id: "water",
      focus: "water",
      title: `${fmt(s.water / 1000, 0)} m³ less water than ${b.baseline_name.toLowerCase()}`,
      evidence: `${fmt(t.washedKg / 1000, 1)} t washed at ${fmt(t.water / t.washedKg, 1)} L/kg versus ${fmt(b.water_l_per_kg * SCENARIO[scenario].baselineFactor, 1)} L/kg in the selected comparison.`,
      action: `Use ${busiest?.name ?? "the largest site"} as the reference site for water reporting in the customer's sustainability report.`,
      status: "ALLOCATED",
      confidence: "Low-Medium",
    },
    {
      id: "emissions",
      focus: "emissions",
      title: `${fmt(s.co2 / 1000, 1)} tCO₂e lower washing and delivery footprint`,
      evidence: `Allocated process + delivery footprint is ${fmt(t.emissions / 1000, 1)} tCO₂e against ${fmt(s.baseCo2 / 1000, 1)} tCO₂e in the comparison. This is an estimate, not a verified Scope 3 figure.`,
      action: "Offer the customer a Scope 3 data annex with the method, baseline and limitations stated.",
      status: "ESTIMATE",
      confidence: "Low-Medium",
    },
    {
      id: "repairs",
      focus: "circularity",
      title: `${fmt(t.repairs)} repairs kept garments in use`,
      evidence: `Under the selected assumption this postpones ${fmt(s.replacementsPostponed)} replacements (~${fmt(s.avoidedProductCo2 / 1000, 1)} tCO₂e of new-garment production). ${topRepair ? `${topRepair.type.toLowerCase()} repairs are ${fmt(repairShare * 100)}% of all repairs.` : ""}`,
      action: topRepair
        ? `Review garment handling with site leads to reduce ${topRepair.type.toLowerCase()} repairs, and discuss more durable product options.`
        : "Review repair patterns with site leads.",
      status: "ESTIMATE",
      confidence: "Low-Medium",
    },
    {
      id: "service",
      focus: "service",
      title: `${fmt(t.onTimeRate * 100, 1)}% of service cycles on time`,
      evidence: `${fmt(t.late)} late of ${fmt(t.cycles)} tracked cycles; ${fmt(t.requests)} service requests in the year (${fmt((t.requests / Math.max(1, t.wearers)) * 1000, 1)} per 1,000 wearers).${lateSites.length ? ` Most late cycles: ${lateSites
        .slice(0, 2)
        .map((x) => x.site.name)
        .join(", ")}.` : ""}`,
      action: lateSites.length
        ? "Agree a delivery-window check for the sites with most late cycles."
        : "Keep the current delivery rhythm and report on-time rate quarterly.",
      status: "CALCULATED",
      confidence: "Medium",
    },
  ];
  const rank = (i: Insight) => {
    const idx = focus.indexOf(i.focus);
    return idx === -1 ? 99 : idx;
  };
  return list.sort((a, z) => rank(a) - rank(z));
}

export function steeringQuestions(c: Customer, insights: Insight[]): string[] {
  const q: string[] = insights.slice(0, 3).map((i): string => {
    switch (i.focus) {
      case "cost":
        return "Which sites can we review together to bring garment allocation in line with real use?";
      case "water":
        return "Would water-saving evidence by site help your own sustainability reporting this year?";
      case "emissions":
        return "Which baseline should we agree on for reporting textile-service emissions in your Scope 3 work?";
      case "circularity":
        return "Should we set a joint target for repairs and garment lifetime next year?";
      case "service":
        return "Which sites need the most predictable delivery windows, and how should we measure that?";
    }
  });
  q.push(`What are ${c.name}'s top three priorities for next year, and how should this review change to support them?`);
  q.push("Which of your own data (headcount by site, shift patterns) could we connect to make next year's review more precise?");
  return Array.from(new Set(q));
}

// ---------------------------------------------------------------------------
// Hygiene & wash compliance (proposed KPIs — thresholds are Lindström's to set)
// ---------------------------------------------------------------------------

/** Garments worn in hygiene-sensitive work: Food Industry Coat, Healthcare Tunic. */
export const HYGIENE_CRITICAL = ["P1004", "P1005"];
/** Selectable wash floors: washes per allocated garment per month. */
export const WASH_FLOORS = [1, 1.5, 2] as const;
export const DEFAULT_WASH_FLOOR = 1.5;
/** A line-month where more than this share of allocated garments had no RFID scan is "unseen". */
export const UNSEEN_FLAG = 0.2;
/** Months under the floor on a hygiene-critical line before a site is High risk. */
export const HIGH_RISK_MONTHS = 3;

export type HygieneRisk = "High" | "Medium" | "Low";

export function lineWashRate(l: HygieneLine) {
  return l.alloc ? l.washed / l.alloc : 0;
}
export function lineUnseen(l: HygieneLine) {
  return l.alloc ? Math.max(0, 1 - l.scanned / l.alloc) : 0;
}

export function siteHygiene(s: Site, floor = DEFAULT_WASH_FLOOR) {
  const lines = s.lines ?? [];
  const sum = (ls: HygieneLine[], k: "alloc" | "washed" | "scanned") => ls.reduce((a, l) => a + l[k], 0);
  const crit = lines.filter((l) => HYGIENE_CRITICAL.includes(l.p));
  const under = lines.filter((l) => lineWashRate(l) < floor);
  const critUnder = crit.filter((l) => lineWashRate(l) < floor);
  const unseenMonths = lines.filter((l) => lineUnseen(l) > UNSEEN_FLAG);
  const alloc = sum(lines, "alloc");
  const washRate = alloc ? sum(lines, "washed") / alloc : 0;
  const critAlloc = sum(crit, "alloc");
  const critWashRate = critAlloc ? sum(crit, "washed") / critAlloc : null;
  const unseen = alloc ? 1 - sum(lines, "scanned") / alloc : 0;
  const underShare = lines.length ? under.length / lines.length : 0;
  let risk: HygieneRisk = "Low";
  if (critUnder.length >= HIGH_RISK_MONTHS) risk = "High";
  else if (critUnder.length > 0 || underShare > 0.25 || unseen > UNSEEN_FLAG) risk = "Medium";
  return {
    washRate,
    critWashRate,
    unseen,
    lineMonths: lines.length,
    underMonths: under.length,
    underShare,
    critLineMonths: crit.length,
    critUnderMonths: critUnder.length,
    unseenMonths: unseenMonths.length,
    risk,
  };
}

export function portfolioHygiene(sites: Site[], floor = DEFAULT_WASH_FLOOR) {
  const rows = sites.map((s) => ({ site: s, h: siteHygiene(s, floor) }));
  const lines = sites.flatMap((s) => s.lines ?? []);
  const alloc = lines.reduce((a, l) => a + l.alloc, 0);
  const lineMonths = lines.length;
  const under = lines.filter((l) => lineWashRate(l) < floor).length;
  const crit = lines.filter((l) => HYGIENE_CRITICAL.includes(l.p));
  return {
    rows,
    washRate: alloc ? lines.reduce((a, l) => a + l.washed, 0) / alloc : 0,
    unseen: alloc ? 1 - lines.reduce((a, l) => a + l.scanned, 0) / alloc : 0,
    lineMonths,
    underMonths: under,
    underShare: lineMonths ? under / lineMonths : 0,
    critLineMonths: crit.length,
    critUnderMonths: crit.filter((l) => lineWashRate(l) < floor).length,
    high: rows.filter((r) => r.h.risk === "High").length,
    medium: rows.filter((r) => r.h.risk === "Medium").length,
    compliantShare: lineMonths ? 1 - under / lineMonths : 0,
  };
}

// ---------------------------------------------------------------------------
// Value Bridge: operational signal -> executive translation
// ---------------------------------------------------------------------------
export function valueBridge(c: Customer, sites: Site[], b: Baseline, scenario: Scenario = "base") {
  const t = totals(sites);
  const sv = savings(t, b, scenario);
  const cost = avgGarmentCost(c);
  const idle = sites.reduce((a, s) => a + siteMetrics(s).idle, 0);
  const unseen = Math.max(0, t.allocated - t.scanned);
  return {
    t,
    sv,
    garmentCost: cost,
    /** Replacements postponed x avg synthetic garment purchase cost. */
    repairCapexAvoided: sv.replacementsPostponed * cost,
    idle,
    /** Idle garments x avg garment cost: capital tied up in unused stock. */
    idleCapital: idle * cost,
    unseen,
    unseenShare: t.allocated ? unseen / t.allocated : 0,
    washesPerWearer: t.wearers ? t.washedPieces / t.wearers : 0,
  };
}

// ---------------------------------------------------------------------------
// KAM-entered assumptions, human-scale equivalents and CFO money view.
// All defaults are PROPOSED public reference values, not Lindström figures.
// ---------------------------------------------------------------------------

export interface BaselineOverride {
  water_l_per_kg?: number | undefined;
  energy_kwh_per_kg?: number | undefined;
  process_kgco2e_per_kg?: number | undefined;
  source?: string | undefined;
}

/** Replace baseline intensities with values the KAM got from the customer. */
export function applyOverride(b: Baseline, o: BaselineOverride): Baseline {
  const keys = ["water_l_per_kg", "energy_kwh_per_kg", "process_kgco2e_per_kg"] as const;
  const changed = keys.filter((k) => typeof o[k] === "number" && Number.isFinite(o[k]) && (o[k] as number) >= 0);
  if (!changed.length) return b;
  const next = { ...b };
  for (const k of changed) next[k] = o[k] as number;
  next.baseline_name = `${b.baseline_name} (KAM-entered)`;
  next.assumption_note = `KAM-entered values${o.source ? ` — source: ${o.source}` : ""}. Replaces: ${changed.join(", ")}.`;
  return next;
}

/** Public reference values used to make savings tangible. Adjustable. */
export const EQUIV = {
  /** Helsinki-region resident household water use, ~130 L/day (HSY order of magnitude). */
  residentWaterM3PerYear: (130 * 365) / 1000,
  /** Average passenger car, ~0.17 kgCO2e per km (EU fleet order of magnitude). */
  carKgCo2PerKm: 0.17,
  /** Finnish average carbon footprint per person, ~10 tCO2e per year. */
  personTCo2PerYear: 10,
  /** Typical Finnish apartment electricity, ~2,000 kWh per year. */
  apartmentKwhPerYear: 2000,
} as const;

export function equivalents(sv: { water: number; co2: number; energy: number }) {
  return {
    residentsWater: sv.water / 1000 / EQUIV.residentWaterM3PerYear,
    carKm: sv.co2 / EQUIV.carKgCo2PerKm,
    peopleCo2: sv.co2 / 1000 / EQUIV.personTCo2PerYear,
    apartmentsEnergy: sv.energy / EQUIV.apartmentKwhPerYear,
  };
}

export interface CostInputs {
  waterEurPerM3: number;
  energyEurPerKwh: number;
  carbonEurPerT: number;
  garmentEur: number;
  /** Extra garments a customer owning its own workwear would need (share of allocated). */
  ownedFleetExtra: number;
  /** Optional annual Lindström service fee to show a net figure. 0 = not entered. */
  lindstromFeeEur: number;
  /** Customer-supplied annual alternative TCO; undefined means unknown. */
  alternativeAnnualEur?: number | undefined;
  alternativeAdminHours?: number | undefined;
  serviceAdminHours?: number | undefined;
  loadedHourlyEur?: number | undefined;
  annualLostGarments?: number | undefined;
  alternativeAuditHours?: number | undefined;
  hiddenCostSource?: string;
}

export const DEFAULT_COSTS = (garmentEur: number): CostInputs => ({
  waterEurPerM3: 4.5,
  energyEurPerKwh: 0.15,
  carbonEurPerT: 80,
  garmentEur: Math.round(garmentEur * 100) / 100,
  ownedFleetExtra: 0.3,
  lindstromFeeEur: 0,
});

/**
 * Illustrative demo contract figures (SYNTHETIC — not real Lindström prices) so the
 * annual cost comparison is visible for the three demo customers. Replace in Adjust assumptions.
 */
export const DEMO_CONTRACTS: Record<string, { lindstromFeeEur: number; alternativeAnnualEur: number }> = {
  CUST001: { lindstromFeeEur: 5_100_000, alternativeAnnualEur: 5_850_000 },
  CUST002: { lindstromFeeEur: 1_650_000, alternativeAnnualEur: 1_820_000 },
  CUST003: { lindstromFeeEur: 720_000, alternativeAnnualEur: 835_000 },
};

/** Default cost inputs for a customer, including demo contract figures when available. */
export const defaultCostsFor = (customerId: string, garmentEur: number): CostInputs => ({
  ...DEFAULT_COSTS(garmentEur),
  ...(DEMO_CONTRACTS[customerId] ?? {}),
});

/** Avoided cost if the customer had done it themselves, per line. */
export function cfoValue(
  t: { allocated: number },
  sv: { water: number; energy: number; co2: number; replacementsPostponed: number },
  c: CostInputs,
) {
  const water = Math.max(0, sv.water / 1000) * c.waterEurPerM3;
  const energy = Math.max(0, sv.energy) * c.energyEurPerKwh;
  const carbon = Math.max(0, sv.co2 / 1000) * c.carbonEurPerT;
  const replacements = sv.replacementsPostponed * c.garmentEur;
  const extraGarments = Math.round(t.allocated * c.ownedFleetExtra);
  const fleet = extraGarments * c.garmentEur;
  const gross = water + energy + carbon + replacements + fleet;
  const annualCashBenefit = water + energy + replacements;
  const fee = Number.isFinite(c.lindstromFeeEur) && c.lindstromFeeEur > 0 ? c.lindstromFeeEur : null;
  const alternative = c.alternativeAnnualEur !== undefined && Number.isFinite(c.alternativeAnnualEur) && c.alternativeAnnualEur >= 0 ? c.alternativeAnnualEur : null;
  const annualDifference = fee !== null && alternative !== null ? alternative - fee : null;
  const roiPct = annualDifference !== null && fee !== null ? annualDifference / fee * 100 : null;
  const savingsPct = annualDifference !== null && alternative !== null && alternative > 0 ? annualDifference / alternative * 100 : null;
  const benefitShare = (value: number) => annualCashBenefit > 0 ? value / annualCashBenefit * 100 : null;
  return {
    water, energy, carbon, replacements, extraGarments, fleet, gross,
    net: fee !== null ? gross - fee : null,
    annualCashBenefit, fee, alternative, annualDifference, roiPct, savingsPct,
    shares: { water: benefitShare(water), energy: benefitShare(energy), replacements: benefitShare(replacements) },
  };
}

/** Columns of the import template: one row per Customer × Site × Product × Month. */
export const TEMPLATE_COLUMNS = [
  ["customer_id", "Customer key (e.g. CUST001)", "ERP / CRM"],
  ["customer_name", "Customer legal name", "ERP / CRM"],
  ["site_id", "Delivery site key", "ERP site hierarchy"],
  ["site_name", "Site name", "ERP site hierarchy"],
  ["country", "Site country", "ERP site hierarchy"],
  ["laundry_id", "Serving Lindström laundry", "Route planning"],
  ["product_id", "Product / garment line", "Product master"],
  ["month", "YYYY-MM", "—"],
  ["active_wearers", "Wearers on contract", "eLindström / ERP"],
  ["allocated_pieces", "Garments allocated", "ERP contract"],
  ["active_assets_scanned", "Distinct garments scanned this month", "RFID (Tableau scan report)"],
  ["washed_pieces", "Pieces washed", "RFID (Tableau scan report)"],
  ["washed_kg", "Kilograms washed", "Laundry production"],
  ["repairs", "Repairs done", "Tableau repair report"],
  ["service_requests", "Customer service requests", "eLindström"],
  ["late_cycles", "Cycles returned late", "RFID scan timestamps"],
  ["total_cycles", "Tracked cycles", "RFID scan timestamps"],
] as const;

export function templateCsv(): string {
  const header = TEMPLATE_COLUMNS.map((c) => c[0]).join(",");
  const example = "CUST001,NorthStar Foods Group,S001,NorthStar Helsinki Plant,Finland,L01,P1004,2025-01,120,260,231,470,410.5,12,3,1,180";
  return `${header}\n${example}\n`;
}

// ---------------------------------------------------------------------------
// AI talking points: the only figures the model may use
// ---------------------------------------------------------------------------
export type Fact = { label: string; value: string; status: Status };

export function talkingPointFacts(c: Customer, sites: Site[], b: Baseline, scenario: Scenario = "base", options: { floor?: number; costs?: CostInputs } = {}): Fact[] {
  const t = totals(sites);
  const sv = savings(t, b, scenario);
  const floor = options.floor ?? DEFAULT_WASH_FLOOR;
  const h = portfolioHygiene(sites, floor);
  const tx = textileImpact(c, sv.replacementsPostponed);
  const financial = options.costs ? cfoValue(t, sv, options.costs) : null;
  const idle = sites.reduce((a, s) => a + siteMetrics(s).idle, 0);
  const r = (x: number, d = 0) => x.toLocaleString("en-GB", { maximumFractionDigits: d, minimumFractionDigits: d });
  return [
    { label: "Customer", value: `${c.name} (${c.industry}, ${t.sites} sites)`, status: "MEASURED" },
    { label: "Washed weight", value: `${r(t.washedKg / 1000, 1)} tonnes`, status: "MEASURED" },
    { label: "Repairs", value: r(t.repairs), status: "MEASURED" },
    { label: "Service requests", value: r(t.requests), status: "MEASURED" },
    { label: "On-time service cycles", value: t.cycles ? `${r(t.onTimeRate * 100, 1)}%` : "no cycle data", status: "CALCULATED" },
    { label: "Garments in use (scanned / allocated, Dec)", value: `${r(t.utilisation * 100, 1)}%`, status: "CALCULATED" },
    { label: "Garments with no scan activity — investigation signal, not confirmed idle (allocated beyond scanned use + 10% buffer)", value: r(idle), status: "CALCULATED" },
    { label: `Water saved vs ${b.baseline_name}`, value: `${r(sv.water / 1000)} m³`, status: "ESTIMATE" },
    { label: `CO2e saved vs ${b.baseline_name}`, value: `${r(sv.co2 / 1000, 1)} tCO₂e`, status: "ESTIMATE" },
    { label: `Energy saved vs ${b.baseline_name}`, value: `${r(sv.energy / 1000, 1)} MWh`, status: "ALLOCATED" },
    { label: "Replacements postponed (repair events × scenario factor, not unique garments)", value: r(sv.replacementsPostponed), status: "ESTIMATE" },
    { label: "New textile production avoided", value: `${r(tx.kg / 1000, 1)} t`, status: "ESTIMATE" },
    { label: "New-product manufacturing emissions postponed (separate from service emissions)", value: `${r(sv.avoidedProductCo2 / 1000, 1)} tCO₂e`, status: "ESTIMATE" },
    { label: "Repairs per 100 garments", value: r(repairIntensity(t).per100, 1), status: "CALCULATED" },
    { label: "Washes per garment per month", value: r(h.washRate, 2), status: "CALCULATED" },
    { label: `[Proposed threshold] Line-months under proposed wash floor ${floor}`, value: `${r(h.underShare * 100)}%`, status: "ESTIMATE" },
    { label: "[Proposed threshold] Hygiene-critical line-months under floor", value: `${h.critUnderMonths} of ${h.critLineMonths}`, status: "ESTIMATE" },
    { label: "[Proposed threshold] Sites at proposed High / Medium hygiene risk", value: `${h.high} / ${h.medium}`, status: "ESTIMATE" },
    { label: "Sensitivity scenario", value: SCENARIO_LABEL[scenario], status: "ESTIMATE" },
    ...(financial ? [
      { label: "Annual cost scope", value: "Whole customer account; entered costs are not prorated by site filters. Demo defaults are synthetic, not real contract prices.", status: "ESTIMATE" as const },
      ...[
        ["Alternative annual TCO", financial.alternative], ["Lindström annual fee", financial.fee], ["Annual cost difference", financial.annualDifference],
      ].flatMap(([label, value]) => typeof value === "number" ? [{ label: String(label), value: `€${r(value)}`, status: "ESTIMATE" as const }] : []),
      ...(financial.roiPct !== null ? [{ label: "Net ROI", value: `${r(financial.roiPct, 1)}%`, status: "ESTIMATE" as const }] : []),
      ...(financial.savingsPct !== null ? [{ label: "Cost reduction vs alternative", value: `${r(financial.savingsPct, 1)}%`, status: "ESTIMATE" as const }] : []),
    ] : []),
  ];
}

// ---------- Site health score (proposed composite, 0–100) ----------
export const HEALTH_WEIGHTS = { wash: 35, rightsizing: 25, requests: 20, delivery: 20 } as const;
/** Late-cycle rate at which the delivery part scores 0 (proposed). */
export const HEALTH_LATE_ZERO = 0.05;

/** requestsWorst = highest service requests per 1,000 wearers among the compared sites. */
export function siteHealth(s: Site, requestsWorst: number, floor = DEFAULT_WASH_FLOOR) {
  const m = siteMetrics(s);
  const h = siteHygiene(s, floor);
  const parts = {
    wash: 1 - h.underShare,
    rightsizing: Math.min(1, m.utilisation / UTILISATION_TARGET),
    requests: requestsWorst > 0 ? 1 - m.requestsPer1k / requestsWorst : 1,
    delivery: s.cycles ? Math.max(0, 1 - m.lateRate / HEALTH_LATE_ZERO) : 1,
  };
  const score =
    parts.wash * HEALTH_WEIGHTS.wash +
    parts.rightsizing * HEALTH_WEIGHTS.rightsizing +
    parts.requests * HEALTH_WEIGHTS.requests +
    parts.delivery * HEALTH_WEIGHTS.delivery;
  return { score: Math.round(score), parts };
}

export function healthTable(sites: Site[], floor = DEFAULT_WASH_FLOOR, referenceSites: Site[] = sites) {
  const worst = Math.max(0, ...referenceSites.map((s) => siteMetrics(s).requestsPer1k));
  return new Map(sites.map((s) => [s.id, siteHealth(s, worst, floor)]));
}

/** Repair mix: share of each repair type, largest first. */
export function repairMix(c: Customer) {
  const total = c.repairTypes.reduce((a, r) => a + r.count, 0);
  return [...c.repairTypes]
    .sort((a, z) => z.count - a.count)
    .map((r) => ({ ...r, share: total ? r.count / total : 0 }));
}

/** EEA estimate: ~16 kg textile waste per EU resident per year (external reference, used only as a comparison). */
export const EU_TEXTILE_WASTE_KG_PER_PERSON = 16;

/** Average garment weight, weighted by December allocation per product. */
export function avgGarmentWeight(c: Customer) {
  let pieces = 0;
  let kg = 0;
  for (const p of c.products) {
    const prod = data.products.find((x) => x.product_id === p.product);
    if (!prod) continue;
    pieces += p.allocatedDec;
    kg += p.allocatedDec * prod.avg_weight_kg;
  }
  return pieces ? kg / pieces : 0;
}

/** Textile equivalences for avoided new production. */
export function textileEquivalents(c: Customer, avoidedKg: number) {
  const w = avgGarmentWeight(c);
  return {
    avgWeight: w,
    garments: w ? avoidedKg / w : 0,
    euResidents: avoidedKg / EU_TEXTILE_WASTE_KG_PER_PERSON,
  };
}

/** Estimated physical textile mass from postponed replacements, never from product CO₂e. */
export function textileImpact(c: Customer, replacementsPostponed: number) {
  const kg = replacementsPostponed * avgGarmentWeight(c);
  return { kg, ...textileEquivalents(c, kg) };
}

/** Repair intensity: how much of the fleet the repairs kept in use (no lifespan claim). */
export function repairIntensity(t: { repairs: number; allocated: number }) {
  return {
    per100: t.allocated ? (t.repairs / t.allocated) * 100 : 0,
    share: t.allocated ? Math.min(1, t.repairs / t.allocated) : 0,
  };
}

/** Seasonal workforce swing and garment capital an owner would have had to hold for the peak. */
export function workforceElasticity(c: Customer) {
  const { allocated, wearers: decWearers } = totals(c.sites);
  const w = c.monthly.map((m) => m.wearers);
  const peak = w.length ? Math.max(...w) : 0;
  const trough = w.length ? Math.min(...w) : 0;
  const swing = peak - trough;
  const perWearer = decWearers ? allocated / decWearers : 0;
  const peakMonth = c.monthly.find((m) => m.wearers === peak)?.month ?? "—";
  const troughMonth = c.monthly.find((m) => m.wearers === trough)?.month ?? "—";
  return {
    peak, trough, swing, peakMonth, troughMonth,
    swingShare: peak ? swing / peak : 0,
    perWearer,
    strandedGarments: Math.round(swing * perWearer),
    strandedEur: swing * perWearer * avgGarmentCost(c),
  };
}

/** Best and weakest site by health score. */
export function benchmarkSites(sites: Site[], floor = DEFAULT_WASH_FLOOR, referenceSites: Site[] = sites) {
  const h = healthTable(sites, floor, referenceSites);
  const ranked = [...sites].sort((a, b) => h.get(b.id)!.score - h.get(a.id)!.score);
  const best = ranked[0]!;
  const worst = ranked[ranked.length - 1]!;
  return { best, worst, bestScore: h.get(best.id)!.score, worstScore: h.get(worst.id)!.score, gap: h.get(best.id)!.score - h.get(worst.id)!.score };
}

// Proposed evaluation targets; quantity alone is never a performance score.
export type PerformanceMetric = "delivery" | "scan" | "compliance" | "health" | "resource";
export type PerformanceGrade = "Excellent" | "Good" | "Fair" | "Needs attention";
export type PerformanceRules = Record<PerformanceMetric, [number, number, number]>;
export const DEFAULT_PERFORMANCE: PerformanceRules = {
  delivery: [98, 95, 90], scan: [85, 75, 65], compliance: [98, 95, 90],
  health: [85, 70, 55], resource: [20, 10, 5],
};
export const PERFORMANCE_NAMES: Record<PerformanceMetric, string> = {
  delivery: "On-time service cycles", scan: "Scanned share of allocation",
  compliance: "Line-months meeting wash floor", health: "Site health score", resource: "Resource reduction vs comparison",
};
export function performanceGrade(value: number | null, metric: PerformanceMetric, rules = DEFAULT_PERFORMANCE): PerformanceGrade | null {
  if (value === null || !Number.isFinite(value)) return null;
  const [excellent, good, fair] = rules[metric];
  if (value >= excellent) return "Excellent";
  if (value >= good) return "Good";
  if (value >= fair) return "Fair";
  return "Needs attention";
}
export function resourceReduction(saved: number, baseline: number): number | null {
  return baseline > 0 ? saved / baseline * 100 : null;
}

/** Diagnostic alternative costs, never added to annual TCO or benefit shares. */
export function hiddenCosts(c: CostInputs) {
  const valid = (v: number | undefined) => v !== undefined && Number.isFinite(v) && v >= 0;
  const multiply = (a: number | undefined, b: number | undefined) => valid(a) && valid(b) ? Number(a) * Number(b) : null;
  const admin = multiply(c.alternativeAdminHours, c.loadedHourlyEur);
  const serviceAdmin = multiply(c.serviceAdminHours, c.loadedHourlyEur);
  const loss = multiply(c.annualLostGarments, c.garmentEur);
  const audit = multiply(c.alternativeAuditHours, c.loadedHourlyEur);
  const entered = [admin, loss, audit].filter((v): v is number => v !== null);
  return { admin, serviceAdmin, loss, audit,
    total: entered.length ? entered.reduce((a, b) => a + b, 0) : null,
    adminDifference: admin !== null && serviceAdmin !== null ? admin - serviceAdmin : null,
  };
}
