import { describe, expect, it } from "vitest";
import { buildCustomer } from "./import";
import { TEMPLATE_COLUMNS } from "./review";

const row = (o: Record<string, string> = {}) => {
  const base: Record<string, string> = {};
  const ex = "CUST9,Acme Oy,S1,Acme Espoo,Finland,L01,P1004,2025-01,120,260,231,470,410.5,12,3,1,180".split(",");
  TEMPLATE_COLUMNS.forEach((c, i) => (base[c[0]] = ex[i]!));
  return { ...base, ...o };
};

describe("customer data upload", () => {
  it("builds one site per site_id and sums washed kg across months", () => {
    const r = buildCustomer([row(), row({ month: "2025-02", washed_kg: "100" })], "Manufacturing");
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.customer.name).toBe("Acme Oy");
    expect(r.customer.sites).toHaveLength(1);
    expect(r.customer.sites[0]!.washedKg).toBeCloseTo(510.5);
    expect(r.customer.sites[0]!.allocated).toBe(260); // latest month only
  });
  it("rejects files missing template columns", () => {
    const { repairs: _r, ...bad } = row();
    expect(buildCustomer([bad], "Manufacturing").ok).toBe(false);
  });
  it("rejects more late cycles than total cycles", () => {
    expect(buildCustomer([row({ late_cycles: "500" })], "Manufacturing").ok).toBe(false);
  });
});
