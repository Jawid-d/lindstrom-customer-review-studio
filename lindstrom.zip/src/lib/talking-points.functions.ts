import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  audience: z.string().min(2).max(300),
  context: z.string().max(800).default(""),
  facts: z
    .array(z.object({ label: z.string().max(200), value: z.string().max(200), status: z.string().max(20) }))
    .min(1)
    .max(40),
});

export type TalkingPoints = {
  hook: string;
  outcomes: { text: string; figures: string[] }[];
  watch: { text: string; figures: string[] };
  decision: string;
  answer: string;
  caveats: string[];
};

const SYSTEM = `You write a short meeting briefing for a Lindström key account manager presenting the annual review to a customer. Plain, friendly business English for non-technical readers.
Rules:
- Use ONLY the figures in FACTS. Never invent, round differently or combine numbers into new ones.
- Say "estimate" for figures tagged ESTIMATE. Figures labelled [Proposed threshold] use thresholds suggested by the review tool, NOT Lindström policy or the customer's SLA — say so.
- Focus on the TOPIC. Each sentence short; each item at most 2 sentences.
- If a QUESTION is given, answer it in "answer" (max 3 sentences) using only FACTS; otherwise "answer" is "".
- The data is a synthetic hackathon data pack.
Return JSON only, exactly this shape:
{"hook": string (opening line the KAM can say aloud), "outcomes": [{"text": string, "figures": [string]}] (exactly 3; figures = FACTS labels used), "watch": {"text": string, "figures": [string]} (one item to address proactively), "decision": string (the concrete next step to propose), "answer": string, "caveats": [string] (max 2)}`;

export const generateTalkingPoints = createServerFn({ method: "POST" })
  .validator((d: unknown) => Input.parse(d))
  .handler(async ({ data }): Promise<{ ok: true; result: TalkingPoints } | { ok: false; error: string }> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return { ok: false, error: "AI is not configured for this app." };
    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText } = await import("ai");
    const provider = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });
    const facts = data.facts.map((f) => `- ${f.label}: ${f.value} [${f.status}]`).join("\n");
    try {
      const result = streamText({
        model: provider.responses("openai/gpt-6-astra"),
        system: SYSTEM,
        maxRetries: 0,
        messages: [
          {
            role: "user",
            content: `TOPIC: ${data.audience}\nQUESTION: ${data.context || "none"}\n\nFACTS:\n${facts}\n\nReply in json.`,
          },
        ],
        providerOptions: {
          openai: {
            store: false,
            forceReasoning: true,
            reasoningEffort: "low",
            reasoningSummary: "auto",
            include: ["reasoning.encrypted_content"],
          },
        },
      });
      const text = await result.text;
      const json = text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
      const parsed = JSON.parse(json) as TalkingPoints;
      return { ok: true, result: parsed };
    } catch (e) {
      console.error("talking points failed", e);
      const msg = String((e as { statusCode?: number }).statusCode ?? "");
      if (msg === "429") return { ok: false, error: "Too many requests right now — try again in a minute." };
      if (msg === "402") return { ok: false, error: "AI credits have run out for this workspace." };
      return { ok: false, error: "Could not generate talking points. Please try again." };
    }
  });
