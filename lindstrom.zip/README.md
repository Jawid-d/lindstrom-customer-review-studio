# Lindström Customer Review Studio

A working hackathon application for Lindström key account managers preparing annual customer reviews. It turns workwear-service data into a single, evidence-led view of customer value, sustainability, service performance and next steps.

**Live application:** https://lindstrom.lovable.app

## What judges can try

The app opens directly on a customer review, without a separate home page or portfolio workflow.

1. **Switch customers** between NorthStar Foods, Apex Industrial and Mediora Health using the customer selector.
2. **Explore value delivered:** resource savings estimates, repairs, physical textile production avoided, service performance and account scale. Click linked KPI boxes to reach supporting evidence.
3. **Inspect sites and hygiene:** compare site performance, scan activity, proposed health scores and wash-risk criteria. Use the filters and meeting-focus controls to tailor the review.
4. **Adjust assumptions:** change comparison intensities, financial inputs and proposed performance criteria. Inspect customer-entered invisible costs and the estimated-benefit breakdown inside the same dialog.
5. **Compare annual costs:** view alternative annual TCO, Lindström service fee, annual difference and ROI. Built-in customers have synthetic demo contract values.
6. **Open AI briefing:** generate a structured meeting brief, change topic in one tap, or ask a follow-up question about the selected customer.
7. **Present and export:** switch to customer presentation mode, save a PDF through the browser print dialog, or download an Excel workbook with executive summary, sites and cost comparison sheets.
8. **Upload a customer file:** download the CSV template, supply compatible CSV or Excel data, and review the imported customer in the same dashboard.

## Data and methodology

This is a **hackathon prototype, not an audited customer report**. The bundled operational dataset is pre-aggregated from the synthetic Lindström Excel data pack. Contract fees and alternative annual costs are made-up demo values, not real Lindström prices.

- Figures use data-status labels and formula tooltips; **Methodology** explains definitions, sources, assumptions and limitations.
- Wash floors, risk rules, health weights and performance grades are **proposed review criteria**, not official Lindström policy or contractual SLAs.
- Resource savings compare service intensities against the selected alternative and sensitivity scenario; they are estimates rather than verified avoided impacts.
- Physical textile avoided = postponed replacement equivalents × allocation-weighted garment mass. The legacy `avoidedProductKg` field represents manufacturing emissions in **kgCO₂e**, not fabric mass.
- Annual difference = alternative annual cost − Lindström annual fee. ROI = annual difference ÷ service fee × 100. Comparable annual period and scope are required.
- Upfront fleet capital, shadow carbon value and diagnostic invisible costs stay separate from annual TCO and benefit shares to avoid double-counting.
- Site health uses the full customer's site network as its request-rate reference. Seasonal workforce figures are account-wide.
- Uploaded customers and edits are held in current-session browser state only; refreshing does not preserve them. Some imported metrics are estimated from data-pack average intensities.

## Architecture

Built with **TanStack Start, TanStack Router, React 19, TypeScript, Tailwind CSS, Recharts and Radix UI**, using Vite and Vitest. Excel imports and exports use SheetJS (`xlsx`).

| Location | Responsibility |
| --- | --- |
| `src/data/review-data.json` | Bundled customer data and comparison baselines |
| `src/lib/review.ts` | Shared calculations, recommendation rules and briefing facts |
| `src/lib/import.ts` | Customer-file validation and conversion to the common data shape |
| `src/components/review/` | Dashboard, evidence sections, assumptions, presentation and exports |
| `src/components/review/MethodologyDetails.tsx` | Explanations using the current review context |
| `src/lib/talking-points.functions.ts` | Server-side briefing through Lovable AI Gateway |
| `src/routes/index.tsx` | Single customer-review entry point |
| `src/lib/*.test.ts`, `src/test/` | Calculation, import and routing tests |

Calculation rules are separate from presentation so the data source can change without rewriting the dashboard. Customer selection and uploads use local React state; there is no persistent customer database in this version.

### AI boundaries

The briefing receives only the formatted `talkingPointFacts()` list, not raw customer files. Its instructions restrict it to those facts and require estimated figures to be described as estimates. **This is an instruction-based safeguard, not a guarantee that generated text is error-free:** the account manager should review it before presenting.

AI runs server-side through Lovable AI Gateway and requires a valid `LOVABLE_API_KEY`, gateway access and available credits. The non-AI review works without that key; the briefing shows an unavailable message when it is missing. Never commit secrets or expose this key in browser code.

## Run locally

Use a recent Node.js release supported by Vite (Node 22.12+ is a suitable choice) and [Bun](https://bun.sh/) for the included lockfile.

From the downloaded or cloned project folder:

```sh
bun install --frozen-lockfile
bun run dev
```

Open the local address printed by Vite. For AI functionality outside Lovable, provide `LOVABLE_API_KEY` as a server environment variable through your local secret configuration; do not include its value in the source archive. AI requires network access.

## Verify and build

```sh
# Calculation, import and routing tests
bun run test

# Individual calculation suite
bunx vitest run src/lib/review.test.ts

# Production build
bun run build

# Other available development commands
bun run lint
bun run test:watch
```

The deployment configuration uses the Lovable TanStack Vite integration with a Cloudflare-targeted server build. Moving to another host requires its compatible server runtime and server-side secret configuration; this is not a static-only HTML application.

## Hackathon source submission

Submit the repository URL in the **Repository** field. If it is private, also attach the source-code ZIP so judges can inspect it without repository access.

- In Lovable, open **Project settings → Git → Download codebase** (available on paid plans), or use **Download codebase** at the bottom of the Code editor's file tree.
- If using GitHub, open the synced repository and choose **Code → Download ZIP**.
- Include source, configuration, `package.json`, `bun.lock`, bundled data and this README. Exclude secret files, repository metadata, `node_modules` and generated build output when assembling an archive manually.

Database export is not needed for this version: the demo dataset is bundled in the source. Gateway secrets and AI credits are not included in a source ZIP.
