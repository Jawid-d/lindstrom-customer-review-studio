# Dashboard refinements
- [x] Correct textile mass, briefing facts/settings, site benchmarks, workforce scope and shared units; verify calculations and review flow.
- [x] Clarify sensitivity labels and company versus customer footprint.
- [x] Replace bulky personalization controls with a compact meeting agenda.
- [x] Move customer assumptions into a closed-by-default dialog.
- [x] Verify meeting controls and layout across screen sizes.

# Performance and invisible costs
- [x] Add defensible, adjustable performance badges and clarify volume KPIs.
- [x] Add customer-entered hidden costs without double-counting annual TCO.
- [x] Explain grading and cost formulas in Methodology and verify the workflow.

# Methodology completeness
- [x] Document all displayed calculations, current assumptions, risk rules and data limitations.
- [x] Verify Methodology reflects saved customer adjustments and works in client mode.

# Dashboard cleanup
- [x] Remove the duplicate import-template section and correct the visible scan-activity signal.
- [x] Consolidate empty financial results while preserving entered costs and calculation rules.
- [x] Normalize section numbering and verify the assumption-to-results flow.
- [x] Move invisible costs and benefit breakdown into Adjust assumptions and verify live editing.

# Review tools panel
- [x] Move All customers, Present review, AI briefing, Methodology, Upload, Adjust assumptions and Export out of the top header into a side panel.
- [x] Verify every tool still opens from the panel on desktop, tablet and mobile.

# Executive dashboard design
- [x] Simplify the title and separate navigation, filters and meeting tools.
- [x] Rebalance KPI hierarchy, spacing, section boundaries and semantic colours.
- [x] Verify customer selection, assumptions, briefing, export and layouts across screen sizes.

# All-customers overview
- [x] Simplify Home to company selection, separate customer reviews, and verify collapsible tools and presenter flow.
- [x] Make the starting page show the customer portfolio and verify selection opens an individual review.
- [x] Add combined account KPIs, searchable customer comparison and customer-review navigation.
- [x] Keep uploaded customers available when moving between overview and reviews.
- [x] Verify overview totals, filtering and customer drill-down on desktop and mobile.

# Shared navigation
- [x] Add one sidebar across Home, portfolio and customer reviews with persistent session toggle and customer selection.
- [x] Keep review tools and presenter mode available, including tablet and mobile navigation.
- [x] Verify Home → customer review → presenter → portfolio → return, and sidebar reopening across screen sizes.

# Restore streamlined review
- [x] Restore the single review screen and top tools from the pre-Home design.
- [x] Remove separate company selection and sidebar navigation, preserving review features.
- [x] Verify customer switching, dialogs, presentation and export across screen sizes.