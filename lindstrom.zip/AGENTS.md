<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules
- Dashboard figures come from `src/data/review-data.json`, pre-aggregated from the Lindström Excel data pack; all calculation and recommendation rules live in `src/lib/review.ts` (tested in `review.test.ts`) so data sources can be swapped without touching the UI.
- Every displayed figure carries a data-status tag and a formula tooltip — credibility is a judging criterion.
- Value-summary KPI components share one parent grid; textile equivalents stay within the textile KPI to avoid duplicate impact cards and incomplete rows.
- Executive review layout separates the app toolbar, customer title and filter ribbon; shared KPI variants and full-width chapter bands establish hierarchy without changing calculation logic.
- Meeting agenda selections reuse deterministic focus ranking and navigate to existing review sections; assumption editing stays in a header dialog so preparation tools do not crowd the executive review.
- The header and financial empty states open the same controlled assumption dialog so edits retain identical save and cancel behavior.
- CostDetails renders live review and account-wide diagnostic values inside the assumption dialog, reusing review.ts calculations without duplicating them.
- AI talking points (`src/lib/talking-points.functions.ts`) receive only the `talkingPointFacts()` list from `review.ts`, never raw data — so the model cannot cite figures the dashboard does not show.
- Physical textile estimates use postponed replacements × allocation-weighted garment mass; legacy avoidedProductKg remains manufacturing kgCO₂e to preserve data-pack compatibility.
- Health scores use the full account as their request-rate reference, seasonal capital uses account totals, and briefing/export inputs carry the current wash floor; briefing caches include the facts to prevent stale results after edits.
- Annual TCO comparisons require separately entered alternative annual cost and customer-paid service fee; keep upfront capital and non-cash carbon separate from annual benefit shares so partial benefit estimates cannot masquerade as full TCO.
- Uploaded customer files are converted to the same Customer shape by `src/lib/import.ts` (tested in `import.test.ts`) and kept in browser state only, so every dashboard section works unchanged on uploaded data.
- Performance rubrics and hidden-cost arithmetic live in review.ts; shared badges and criteria expose the same proposed rules, while diagnostic hidden costs never auto-increase TCO or ROI to prevent double-counting.
- MethodologyDetails receives live review context and documents existing calculations and their limitations without recalculating business figures, so explanations follow customer edits without changing dashboard logic.
- The root route renders a single Dashboard with local customer selection and current-session uploads; review tools live in its top toolbar to keep the KAM workflow direct without separate Home, portfolio or sidebar navigation.
