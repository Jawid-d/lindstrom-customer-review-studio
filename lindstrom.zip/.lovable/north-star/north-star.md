<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Lindström customers see the concrete value their workwear service delivers them

## Metric

Customer value reviews shown in presentation mode or exported as PDF each month
